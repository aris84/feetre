# -*- coding: utf-8 -*-
from linepy import *
from datetime import datetime
from time import sleep
from bs4 import BeautifulSoup
import threading
from humanfriendly import format_timespan, format_size, format_number, format_length
import time, random, asyncio, sys, json, codecs, glob, re, string, os, requests, subprocess, six, ast, pytz, urllib, urllib.parse, timeago, traceback
from gtts import gTTS
from collections import OrderedDict
from googletrans import Translator
from wikiapi import WikiApi


botStart = time.time()

#shield = LINE()
shield = LINE("EvsYWAEXWCqlKu2Xit05.lOOarxPpAG43SXqgcCX6Lq.GZQpsFxmLi1Z341SZpGO0G/7OB4QxxXtRH1TT/vD7U0=")#7
shield.log("Auth Token : " + str(shield.authToken))
shield.log("Timeline Token : " + str(shield.tl.channelAccessToken))
#shield.log("CC Token : " + str(shield.jpang.channelAccessToken))


#shield1 = LINE()
shield1 = LINE("EvEiqLjGVtZZlP6XtZjc.gKNmfN4Xb4jMn6sGbsZUZa.Q8yQ5WFcEXUMCMDnhrE/LrnDWVdiwyza+jaI5woAyPA=")#7
shield1.log("Auth Token : " + str(shield1.authToken))
#channel = Channel(shield1, shield1.server.CHANNEL_ID['LINE_JUNGGLEPANG'])
#channelToken = channel.getChannelResult()
#print(channelToken)

#shield2 = LINE()
shield2 = LINE("EwebKwjoyGAtt3Wr54Kf.pcpLjE5wDo7uav7VPidrtW.K7BzJvf+4sLnhEsqoOH2a0iudAbn+kwszASzhJ0j/4U=")#8
shield2.log("Auth Token : " + str(shield2.authToken))

#shield3 = LINE()
shield3 = LINE("EwZI8QPLYVXWfoRzwbdd.psJD9o1i3h6Uv4u3LyhPpq.GRoTvXp4Cu3xbrv4EnxEGOvuegujcSQRgk2WSFJPu3o=")#9
shield3.log("Auth Token : " + str(shield3.authToken))

#shield4 = LINE()
shield4 = LINE("EwZI8QPLYVXWfoRzwbdd.psJD9o1i3h6Uv4u3LyhPpq.GRoTvXp4Cu3xbrv4EnxEGOvuegujcSQRgk2WSFJPu3o=")#9

#shield4 = LINE("EvUu8yURSi4DKTWCeohd.BG2e7yuB5BPMhPDcRfzztq.k1CzBS6w4AuhyFhmlhaMNKpm0IwEK5N8hbRxqtCzD5k=")#10
shield4.log("Auth Token : " + str(shield4.authToken))

#shield5 = LINE()
shield5 = LINE("EwZI8QPLYVXWfoRzwbdd.psJD9o1i3h6Uv4u3LyhPpq.GRoTvXp4Cu3xbrv4EnxEGOvuegujcSQRgk2WSFJPu3o=")#9

#shield5 = LINE("Ev7IamWBSfMCbOGTRZb9.SzoDq+GhouyCF3YKDEVdwq.WiXieFb/SiellQrXrLKQS9KatfHO4k3+OqxMaYpvG/s=")#11
shield5.log("Auth Token : " + str(shield5.authToken))

#ghost = LINE()
ghost = LINE("EwxjkrMVLegifFbr1lAf.Him52O9nEswVtT75cFWhxW.lgywMy77e9EbtAlFCDz33hdllojkbK1ujsnnn5UP2Yc=")#12
ghost.log("Auth Token : " + str(ghost.authToken))

#js = LINE()
js = LINE("EwwmXJOTjlBaseDp6Fwa.eNeK42Htvw7YX9Yfr4bAIG.H/EANbw2OSSvBQP3KmMUjt8W1tP5hALgysvsBMhx6Wc=")#13
js.log("Auth Token : " + str(js.authToken))

shieldProfile = shield.getProfile()
aProfile = shield1.getProfile()
bProfile = shield2.getProfile()
cProfile = shield3.getProfile()
dProfile = shield4.getProfile()
eProfile = shield5.getProfile()

lineSettings = shield.getSettings()
oepoll = OEPoll(shield)

shieldMID = shield.profile.mid
aMID = shield1.profile.mid
bMID = shield2.profile.mid
cMID = shield3.profile.mid
dMID = shield4.profile.mid
eMID = shield5.profile.mid
gMID = ghost.profile.mid
jMID = js.profile.mid

with open('public.json', 'r') as fp:
    wait = json.load(fp)
with open('publicRead.json', 'r') as fp:
    wait2 = json.load(fp)
with open('publicLimit.json', 'r') as fp:
    prevents = json.load(fp)
with open('media.json', 'r') as fp:
    media = json.load(fp)
    
master = ["u17ce7606c05a31e55cfccb35487cfbf3"]
owner = wait['shieldCreator'] + wait["shieldBots"] + wait['shieldOwner']
owner1 = wait['shieldCreator'] + wait['shieldOwner']
bots = wait['shieldCreator'] + wait['shieldBots']
blacklist = wait['shieldBlacklist']
carousel = "SKPD+S7v7ZLYT9bG9KLWPYSq8up/o+PQTrtBlvCcbF8Qp58deaV/nUxkXlV8oTWOKshMpRer48irga4lIuHNOxZ2IO5m+RsOl+38NfS7aSKffom5awn/Zt0OywoMnSYU2Whzk28JZhs2WKjdq8XLDjByPVVAinuGCHWQI5kQvQalh4u9Arp9S7X9sw20RDOmQxBju/U2NqiNJwBIN+riSnKR/dA2U1ysTvQ9/qq9UV0ht22W6S4/Ku9YeZMqvz5/HA3PNnObgr6xeUnqZuBRB6ookxI4/Oh+Iu+tjT0VtP238JELZ0qrVCAZCCSfTsw+Efo4/tqILXj7C/0DfNcjJ8RFnSljswa7FxJJjNSNAW8"
read = {
    "readPoint": {},
    "readMember": {},
    "readTime": {},
    "ROM": {}
}

Add = "autoAdd"
Join = "autoJoin"
Leave = "autoLeave"
Read = "autoRead"

botStart = time.time()
msg_dict = {}
myProfile = {"shieldName": "","shieldmsgStat": "","shieldpictStat": ""}
a = {"shieldName": "","shieldmsgStat": "","shieldpictStat": ""}
b = {"shieldName": "","shieldmsgStat": "","shieldpictStat": ""}
c = {"shieldName": "","shieldmsgStat": "","shieldpictStat": ""}
d = {"shieldName": "","shieldmsgStat": "","shieldpictStat": ""}
e = {"shieldName": "","shieldmsgStat": "","shieldpictStat": ""}
try:
    wait["shieldBots"] = []
    wait["shieldBots"].append(shieldMID)
    wait["shieldBots"].append(aMID)
    wait["shieldBots"].append(bMID)
    wait["shieldBots"].append(cMID)
    wait["shieldBots"].append(dMID)
    wait["shieldBots"].append(eMID)
    wait["shieldBots"].append(gMID)
    wait["shieldBots"].append(jMID)
    print ("Bot Sukses di Add ")
except Exception as error:
    print (error)
myProfile["shieldName"] = shieldProfile.shieldName
myProfile["shieldmsgStat"] = shieldProfile.shieldmsgStat
myProfile["shieldpictStat"] = shieldProfile.shieldpictStat

a["shieldName"] = aProfile.shieldName
a["shieldmsgStat"] = aProfile.shieldmsgStat
a["shieldpictStat"] = aProfile.shieldpictStat

b["shieldName"] = bProfile.shieldName
b["shieldmsgStat"] = bProfile.shieldmsgStat
b["shieldpictStat"] = bProfile.shieldpictStat

c["shieldName"] = cProfile.shieldName
c["shieldmsgStat"] = cProfile.shieldmsgStat
c["shieldpictStat"] = cProfile.shieldpictStat

d["shieldName"] = dProfile.shieldName
d["shieldmsgStat"] = dProfile.shieldmsgStat
d["shieldpictStat"] = dProfile.shieldpictStat

e["shieldName"] = eProfile.shieldName
e["shieldmsgStat"] = eProfile.shieldmsgStat
e["shieldpictStat"] = eProfile.shieldpictStat

if wait["rebort"] == True:
    shield.sendMessage(wait["restartPoint"], "Bot Diaktifkan Kembali...!!!!")
    wait["rebort"] = False
    wait["restartPoint"] = ""
    with open('public.json', 'w') as fp:
        json.dump(wait, fp, sort_keys=True, indent=4)
try:
    with open("Log_data.json","r",encoding="utf_8_sig") as f:
        msg_dict = json.loads(f.read())
except:
    print("Couldn't read Log data")

### KUMPULAN DEF ###
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')
def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)

def restartBot():
    print (">BOTSHIELD SELFBOT TELAH DI RESTART<")
    backupData()
    time.sleep(1)
    python = sys.executable
    os.execl(python, python, *sys.argv)
    
def backupData():
    with open('public.json', 'w') as fp:
        json.dump(wait, fp, sort_keys=True, indent=4)
        
def backupRead():
    with open('publicRead.json', 'w') as fp:
        json.dump(wait2, fp, sort_keys=True, indent=4)
        
def backupLimit():
    with open('publicLimit.json', 'w') as fp:
        json.dump(prevents, fp, sort_keys=True, indent=4)

def backupMedia():
    with open('media.json', 'w') as fp:
        json.dump(media, fp, sort_keys=True, indent=4)

def logError(text):
    shield.log("TERJADI ERROR : " + str(text))
    time_ = datetime.now()
    with open("error.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
    
def command(text):
    pesan = text.lower()
    if wait["setkey"] == True:
        if pesan.startswith(wait["setkey"]):
            cmd = pesan.replace(wait["setkey"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
    
def removeCmd(text, key=""):
    setKey = key
    text_ = text[len(setKey):]
    sep = text_.split(" ")
    return text_.replace(sep[0] + " ", "")

def BotShield(op):
    print("[ {} ] {}".format(str(op.type), OpType._VALUES_TO_NAMES[op.type]))
    try:
        if op.type == 55:
            try:
                if op.param1 in wait2["readPoint"]:
                    wait2['ROM'][op.param1][op.param2] = op.param2
                    wait2['setTime'][op.param1][op.param2] = op.createdTime
                    backupRead()
                else:
                   pass
            except:
                pass
             
        if op.type == 0:
            return
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if 'MENTION' in msg.contentMetadata.keys() != None:
                if receiver in wait["shieldDetectMention"]:
                    master = "u17ce7606c05a31e55cfccb35487cfbf3"
                    mention = eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in wait["shieldBots"]:
                          data ={"cc": carousel,"to": receiver,
                            "messages":[{"type":"template","altText":"MEMEK LOE.!",
                                "template":{"type":"carousel","imageAspectRatio": "square","imageSize": "cover",
                                  "columns": [{"thumbnailImageUrl": "https://obs.line-scdn.net/{}".format(shield.getContact(sender).shieldpictStat),"title":"{}".format(shield.getContact(sender).shieldName),"text":"Jones Loe Tag mulu..!!",
                                      "defaultAction": {"type": "uri","label": "View detail","uri": "https://obs.line-scdn.net/{}".format(shield.getContact(sender).shieldpictStat)},
                                      "actions":[{"type": "uri","label": "Contact Creator","uri": "line://ti/p/~aries_jabrik"},{
                                        "type": "uri","label": "Leave Chat","uri": "line://nv/chat"}]},{
                                      "thumbnailImageUrl": "https://obs.line-scdn.net/{}".format(shield.getContact(master).shieldpictStat),"title":"{}".format(shield.getContact(master).shieldName),"text":"This is My Creator.",
                                      "defaultAction": {"type": "uri","label": "View detail","uri": "line://ti/p/~aries_jabrik"},
                                      "actions":[{"type": "uri","label": "Contact Creator","uri": "line://ti/p/~aries_jabrik"},{
                                          "type": "uri","label": "Chat With Creator","uri": "line://ti/p/M8k6NlQ_1J"}]}]}},{
                                "type": "template","altText": "Sticker",
                                  "baseSize": {"height": 1040,"width": 1040}, 
                                    "template": {"type": "image_carousel",
                                      "columns": [{"imageUrl": "https://4.bp.blogspot.com/-J0yVohdH6-E/W1kphnE7lzI/AAAAAAALjko/4N5P8rXrao0vZAweSLaN7A42ugUnidS9wCLcBGAs/s1600/AS0004251_13.gif",
                                        "action": {"type": "uri","uri": "http://line.me/ti/p/M8k6NlQ_1J",
                                          "area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}]}      
                          shield.template(carousel,data)

        if op.type == 26 or op.type == 25:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
                if msg.toType == 0:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if msg.contentType == 0:
                    if text is None:
                        return
                    else:
                        text = command(text)
                        if receiver in prevents["temp_flood"]:
                            if prevents["temp_flood"][receiver]["expire"] == True:
                                if text.lower() == "open":
                                    prevents["temp_flood"][receiver]["expire"] = False
                                    prevents["temp_flood"][receiver]["time"] = time.time()
                                    backupLimit()
                                    shield. sendMessage(to,"Bot Active Again 🍁")
                                return
                            elif time.time() - prevents["temp_flood"][receiver]["time"] <= 5:
                                prevents["temp_flood"][receiver]["flood"] += 1
                                if prevents["temp_flood"][receiver]["flood"] >= 15:
                                    prevents["temp_flood"][receiver]["flood"] = 0
                                    prevents["temp_flood"][receiver]["expire"] = True
                                    backupLimit()
                                    ma = shield. getProfile()
                                    text = "Selfbot Silent On 30 seconds 🍁\nFor Activated Use 'Open' Command! 🍁"
                                    name = "==[ Spam Detected ]=="
                                    url = "https://line.me/ti/p/~" + shield.profile.userid
                                    iconlink = 'http://dl.profile.line-cdn.net/{}'.format(str(ma.shieldpictStat))
                                  #  sendMentionV10(msg.to, str(text), str(name), str(url), str(iconlink))
                                    shield. sendMessage(to,text)
                            else:
                                prevents["temp_flood"][receiver]["flood"] = 0
                                prevents["temp_flood"][receiver]["time"] = time.time()
                                backupLimit()
                        else:
                            prevents["temp_flood"][receiver] = {
    	                        "time": time.time(),
    	                        "flood": 0,
    	                        "expire": False
                            }
                            backupLimit()
                                          
                              
#Taruh di op 26
                if msg.contentType == 0 and sender not in shieldMID and msg.toType == 2:
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if shieldMID in mention["M"]:
                                if to not in wait["Mentioned"]:
                                    wait["Mentioned"][to] = {}
                                    backupData()
                                if sender not in wait["Mentioned"][to]:
                                    wait["Mentioned"][to][sender] = 1
                                    backupData()
                                else:
                                    wait["Mentioned"][to][sender] = wait["Mentioned"][to][sender] + 1
                                    backupData()
                                break
                                
                if msg.contentType == 0:
                    if msg.text is None:
                        return
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if shield.getProfile().mid in mention["M"]:
                                if to not in wait['ROM']:
                                    wait['ROM'][to] = {}
                                if msg._from not in wait['ROM'][to]:
                                    wait['ROM'][to][msg._from] = {}
                                if 'msg.id' not in wait['ROM'][to][msg._from]:
                                    wait['ROM'][to][msg._from]['msg.id'] = []
                                if 'waktu' not in wait['ROM'][to][msg._from]:
                                    wait['ROM'][to][msg._from]['waktu'] = []
                                wait['ROM'][to][msg._from]['msg.id'].append(msg.id)
                                wait['ROM'][to][msg._from]['waktu'].append(msg.createdTime)
                              #  self.autoresponuy(msg,wait)
                                break


        if op.type == 5:
            if Add in wait['shieldStatus']:
                roman = shield.getContact(op.param1)
                shield.findAndAddContactsByMid(roman.mid)
                contact = shield.getContact(master)
                name = '  < AUTO ADD >'
                link = 'http://line.me/ti/p/M8k6NlQ_1J'
                icon = "http://dl.profile.line-cdn.net/" + contact.shieldpictStat
                shield.roman(op.param1, op.param1,"Hai","\n\n{}".format(str(wait["messageAdd"])),name,link,icon)
                
        if op.type == 13:
            if shieldMID in op.param3:
              if op.param2 not in bots:
                if Join in wait['shieldStatus']:
                    if wait["limits"]["on"] == True:
                        contact = shield.getContact(op.param2)
                        name = ' <Click My Creator>'
                        link = 'http://line.me/ti/p/M8k6NlQ_1J'
                        icon = "http://dl.profile.line-cdn.net/" + contact.shieldpictStat
                        G = shield.getGroup(op.param1)
                        if len(G.shieldMemb) <= wait["limits"]["members"]:
                            shield.acceptGroupInvitation(op.param1)
                            shield.roman(op.param1,op.param2,"I'm sorry,..","\nNumber of members " + str(G.shieldName) + " is less than " + str(wait["limits"]["members"]) + "\nPlease contact Creator Below ... !!!",name,link,icon)
                            shield.leaveGroup(op.param1)
                        else:
                            shield.acceptGroupInvitation(op.param1)
                            shield.roman(op.param1, op.param2,"Hi ",",\nthank you for inviting me.\nType <help> to use this bot..!!",name,link,icon)
                            if op.param1 not in wait['shieldAdmin']:
                                wait['shieldAdmin'][op.param1] = {}
                            if op.param1 not in wait['shieldBanlist']:
                                wait['shieldBanlist'][op.param1] = {}
                                backupData()
                            if op.param2 not in wait['shieldAdmin'][op.param1]:
                                wait['shieldAdmin'][op.param1][op.param2] = op.param2
                                backupData()
                                shield.roman(op.param1,op.param2,"Congrats ",",\nYou have become Admin Bots,\nYou have the right to add a new Admin, and can use all the Admin commands.",name,link,icon)
                                
              if op.param2 in bots:
                  group = shield.getGroup(op.param1)
                  name = ' <Click My Creator>'
                  link = 'http://line.me/ti/p/M8k6NlQ_1J'
                  icon = "http://dl.profile.line-cdn.net/" + group.shieldpictStat
                  shield.acceptGroupInvitation(op.param1)
                  if op.param1 not in wait['shieldAdmin']:
                      wait['shieldAdmin'][op.param1] = {}
                      backupData()
                  if op.param1 not in wait['shieldBanlist']:
                      wait['shieldBanlist'][op.param1] = {}
                      backupData()
                  
                  if group.shieldCreat.mid not in wait['shieldAdmin'][op.param1]:
                      wait['shieldAdmin'][op.param1][group.shieldCreat.mid] = group.shieldCreat.mid
                      backupData()
                      shield.roman(op.param1,group.shieldCreat.mid,"Congrats ",",\nYou have become Admin Bots,\nYou have the right to add a new Admin, and can use all the Admin commands.",name,link,icon)
                  elif group.shieldMemb[0].mid not in wait['shieldAdmin'][op.param1]:
                      wait['shieldAdmin'][op.param1][group.shieldMemb[0].mid] = group.shieldMemb[0].mid
                      backupData()
                      shield.roman(op.param1,group.shieldMemb[0].mid,"Congrats ",",\nYou have become Admin Bots,\nYou have the right to add a new Admin, and can use all the Admin commands.",name,link,icon)                   
                
        if op.type == 17:
            kick = [shield2,shield5,shield3,shield1,shield4,shield]
            kick1 = [ghost,js]
            kicker = random.choice(kick)
            kicker1 = random.choice(kick1)
            G = kicker.getGroup(op.param1)
            if op.param1 in wait['shieldWelcome']:
                if op.param2 in wait["shieldBots"]:
                    pass
                contact = shield.getContact(op.param2)
                name = ' <Add My Creator>'
                link = 'http://line.me/ti/p/M8k6NlQ_1J'
                icon = "http://dl.profile.line-cdn.net/" + contact.shieldpictStat
                ginfo = shield.getGroup(op.param1)
                contact = shield.getContact(op.param2)
                shield.roman(op.param1,op.param2,'Hi.., ',"\n"+wait["messageWelcome"][op.param1]+'\n\nGroup : '+ginfo.shieldName,name,link,icon)
            if op.param2 in wait["shieldBlacklist"]:
                join(op.param1,kicker,mid1=[kicker1])
                kicker1.kickoutFromGroup(op.param1,[op.param2])
                kicker1.leaveGroup(op.param1)
            if op.param2 in wait["shieldBanlist"][op.param1]:kicker.kickoutFromGroup(op.param1,[op.param2])
            if op.param1 in wait['shieldJoin']:
                if op.param2 not in owner:kicker.kickoutFromGroup(op.param1,[op.param2])
        if op.type == 19:
            if shieldMID in op.param3:
                if op.param2 in owner:join(op.param1,shield1,mid1=[shield])
                if op.param2 not in owner:
                    try:
                        kick_url(op.param1,shield1,op.param2,mid1=[shield,shield2,shield3,shield4,shield5])
                    except:
                        kick_add(op.param1,shield2,op.param2,op.param3,shield)
                        try:
                            kick_url(op.param1,shield2,op.param2,mid1=[shield,shield1,shield3,shield4,shield5])
                        except:
                            kick_add(op.param1,shield3,op.param2,op.param3,shield)
                            try:
                                kick_url(op.param1,shield3,op.param2,mid1=[shield,shield2,shield1,shield4,shield5])
                            except:
                                kick_add(op.param1,shield4,op.param2,op.param3,shield)
                                try:
                                    kick_url(op.param1,shield4,op.param2,mid1=[shield,shield2,shield3,shield1,shield5])
                                except:
                                    kick_add(op.param1,shield5,op.param2,op.param3,shield)
                                    try:
                                        kick_url(op.param1,shield5,op.param2,mid1=[shield,shield2,shield3,shield4,shield1])
                                    except:
                                        kick_add(op.param1,shield1,op.param2,op.param3,shield)
             
            if aMID in op.param3:
                if op.param2 in owner:join(op.param1,shield2,mid1=[shield1])
                if op.param2 not in owner:
                    try:
                        kick_url(op.param1,shield2,op.param2,mid1=[shield1,shield,shield3,shield4,shield5])
                    except:
                        kick_add(op.param1,shield3,op.param2,op.param3,shield1)
                        try:
                            kick_url(op.param1,shield3,op.param2,mid1=[shield1,shield,shield2,shield4,shield5])
                        except:
                            kick_add(op.param1,shield4,op.param2,op.param3,shield1)
                            try:
                                kick_url(op.param1,shield4,op.param2,mid1=[shield1,shield,shield2,shield3,shield5])
                            except:
                                kick_add(op.param1,shield5,op.param2,op.param3,shield1)
                                try:
                                    kick_url(op.param1,shield5,op.param2,mid1=[shield1,shield,shield2,shield3,shield4])
                                except:
                                    kick_add(op.param1,shield,op.param2,op.param3,shield1)
                                    try:
                                        kick_url(op.param1,shield,op.param2,mid1=[shield1,shield5,shield2,shield3,shield4])
                                    except:
                                        kick_add(op.param1,shield2,op.param2,op.param3,shield1)
            if bMID in op.param3:
                if op.param2 in owner:join(op.param1,shield3,mid1=[shield2])
                if op.param2 not in owner:
                    try:
                        kick_url(op.param1,shield3,op.param2,mid1=[shield2,shield,shield1,shield4,shield5])
                    except:
                        kick_add(op.param1,shield4,op.param2,op.param3,shield2)
                        try:
                            kick_url(op.param1,shield4,op.param2,mid1=[shield2,shield,shield1,shield3,shield5])
                        except:
                            kick_add(op.param1,shield5,op.param2,op.param3,shield2)
                            try:
                                kick_url(op.param1,shield5,op.param2,mid1=[shield2,shield,shield1,shield3,shield4])
                            except:
                                kick_add(op.param1,shield,op.param2,op.param3,shield2)
                                try:
                                    kick_url(op.param1,shield,op.param2,mid1=[shield2,shield5,shield3,shield1,shield4])
                                except:
                                    kick_add(op.param1,shield1,op.param2,op.param3,shield2)
                                    try:
                                        kick_url(op.param1,shield1,op.param2,mid1=[shield2,shield5,shield3,shield4,shield])
                                    except:
                                        kick_add(op.param1,shield3,op.param2,op.param3,shield2)
            if cMID in op.param3:
                if op.param2 in owner:join(op.param1,shield4,mid1=[shield3])
                if op.param2 not in owner:
                    try:
                        kick_url(op.param1,shield4,op.param2,mid1=[shield3,shield,shield2,shield1,shield5])
                    except:
                        kick_add(op.param1,shield5,op.param2,op.param3,shield3)
                        try:
                            kick_url(op.param1,shield5,op.param2,mid1=[shield3,shield,shield1,shield4,shield2])
                        except:
                            kick_add(op.param1,shield,op.param2,op.param3,shield3)
                            try:
                                kick_url(op.param1,shield,op.param2,mid1=[shield3,shield2,shield1,shield4,shield5])
                            except:
                                kick_add(op.param1,shield1,op.param2,op.param3,shield3)
                                try:
                                    kick_url(op.param1,shield1,op.param2,mid1=[shield3,shield,shield2,shield4,shield5])
                                except:
                                    kick_add(op.param1,shield2,op.param2,op.param3,shield3)
                                    try:
                                        kick_url(op.param1,shield2,op.param2,mid1=[shield3,shield,shield5,shield4,shield1])
                                    except:
                                        kick_add(op.param1,shield4,op.param2,op.param3,shield3)
            if dMID in op.param3:
                if op.param2 in owner:join(op.param1,shield5,mid1=[shield4])
                if op.param2 not in owner:
                    try:
                        kick_url(op.param1,shield5,op.param2,mid1=[shield4,shield,shield2,shield3,shield1])
                    except:
                        kick_add(op.param1,shield,op.param2,op.param3,shield4)
                        try:
                            kick_url(op.param1,shield,op.param2,mid1=[shield4,shield2,shield1,shield3,shield5])
                        except:
                            kick_add(op.param1,shield1,op.param2,op.param3,shield4)
                            try:
                                kick_url(op.param1,shield1,op.param2,mid1=[shield4,shield,shield2,shield3,shield5])
                            except:
                                kick_add(op.param1,shield2,op.param2,op.param3,shield4)
                                try:
                                    kick_url(op.param1,shield2,op.param2,mid1=[shield4,shield,shield3,shield1,shield5])
                                except:
                                    kick_add(op.param1,shield3,op.param2,op.param3,shield4)
                                    try:
                                        kick_url(op.param1,shield3,op.param2,mid1=[shield4,shield,shield2,shield5,shield1])
                                    except:
                                        kick_add(op.param1,shield5,op.param2,op.param3,shield4)
            if eMID in op.param3:
                if op.param2 in owner:join(op.param1,shield,mid1=[shield5])
                if op.param2 not in owner:
                    try:
                        kick_url(op.param1,shield,op.param2,mid1=[shield5,shield1,shield2,shield3,shield4])
                    except:
                        kick_add(op.param1,shield1,op.param2,op.param3,shield5)
                        try:
                            kick_url(op.param1,shield1,op.param2,mid1=[shield5shield,shield2,shield3,shield4])
                        except:
                            kick_add(op.param1,shield2,op.param2,op.param3,shield5)
                            try:
                                kick_url(op.param1,shield2,op.param2,mid1=[shield5shield,shield3,shield1,shield4])
                            except:
                                kick_add(op.param1,shield3,op.param2,op.param3,shield5)
                                try:
                                    kick_url(op.param1,shield3,op.param2,mid1=[shield5,shield,shield2,shield4,shield1])
                                except:
                                    kick_add(op.param1,shield4,op.param2,op.param3,shield5)
                                    try:
                                        kick_url(op.param1,shield4,op.param2,mid1=[shield5,shield,shield2,shield3,shield1])
                                    except:
                                        kick_add(op.param1,shield,op.param2,op.param3,shield5)


        if op.type == 24:
            if Leave in wait['shieldStatus']:
                shield.leaveRoom(op.param1)
                
        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            #dits = shield.mycmd(msg.text,wait).lower()
            if msg.toType == 0:
                if sender != shield.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 16:
                mid = msg._from
                url = msg.contentMetadata["postEndUrl"]
                shield.suka(url[25:58], url[66:], likeType=1001)
                shield.ngomong(url[25:58], url[66:],wait['messageComment'])
                shield.roman(receiver,sender,'Hi..,','\nIm already like it..!｡^‿^｡','Clik to add','http://line.me/ti/p/M8k6NlQ_1J','http://goo.gl/3T9HJg')
                
            elif msg.contentType == 7:
 #               sid = msg.contentMetadata['STKID']
  #              data = {
   #               "cc":carousel,"to": to,
    #              "messages": [{"type": "template",
     #               "altText": "Sticker",
      #                "baseSize": {"height": 1040,"width": 1040}, 
       #             "template": {"type": "image_carousel",
        #              "columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/ANDROID/sticker.png".format(sid),
         #               "action": {"type": "uri","uri": "http://line.me/ti/p/M8k6NlQ_1J",
          #                "area": {"x": 520,"y": 0,"width": 520,"height": 1040}
          #              }
#                      }]
 #                   }
  #                }]
   #             }
    #            shield.template(carousel,data)
                
                if sender in owner1:addmedia1(msg,to,media["STICKER"],wait["Addsticker"],wait["Addmedia"],"STICKER","Berhasil menambahkan sticker")
                if sender in owner1:
                    if 'stiker' in wait['Addmedia']:
                        for ls in wait["Addstickerchat"]:
                            anu = ls
                        media['CHATPLUS'][to]['stiker'][anu] = {"STKID":msg.contentMetadata["STKID"],"STKPKGID":msg.contentMetadata["STKPKGID"]}
                        backupMedia()
                        shield.sendText(to,"Berhasil menambahkan sticker")
                        wait['Addmedia'].remove('stiker')
                        wait["Addstickerchat"].remove(ls)
                        backupData()
                if to in wait["stickerOn"]:
                    stk_id = msg.contentMetadata['STKID']
                    stk_ver = msg.contentMetadata['STKVER']
                    pkg_id = msg.contentMetadata['STKPKGID']
                    with requests.session() as s:
                        s.headers['user-agent'] = 'Mozilla/5.0'
                        r = s.get("https://store.line.me/stickershop/product/{}/id".format(urllib.parse.quote(pkg_id)))
                        soup = BeautifulSoup(r.content, 'html5lib')
                        data = soup.select("[class~=mdBtn01Txt]")[0].text
                        if data == 'Lihat Produk Lain':
                            ret_ = "「 Sticker Info 」"
                            ret_ += "\n• STICKER ID : {}".format(stk_id)
                            ret_ += "\n• STICKER PACKAGES ID : {}".format(pkg_id)
                            ret_ += "\n• STICKER VERSION : {}".format(stk_ver)
                            ret_ += "\n• STICKER URL : line://shop/detail/{}".format(pkg_id)
                            shield.sendMessage(msg.to, str(ret_))
                            query = int(stk_id)
                            if type(query) == int:
                                data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                                path = shield.downloadFileURL(data)
                                shield.sendImage(msg.to,path)
                        else:
                            ret_ = "「 Sticker Info 」"
                            ret_ += "\n• PRICE : "+soup.findAll('p', attrs={'class':'mdCMN08Price'})[0].text
                            ret_ += "\n• AUTHOR : "+soup.select("a[href*=/stickershop/author]")[0].text
                            ret_ += "\n• STICKER ID : {}".format(str(stk_id))
                            ret_ += "\n• STICKER PACKAGES ID : {}".format(str(pkg_id))
                            ret_ += "\n• STICKER VERSION : {}".format(str(stk_ver))
                            ret_ += "\n• STICKER URL : line://shop/detail/{}".format(str(pkg_id))
                            ret_ += "\n• DESCRIPTION :\n"+soup.findAll('p', attrs={'class':'mdCMN08Desc'})[0].text
                            shield.sendMessage(msg.to, str(ret_))
                            query = int(stk_id)
                            if type(query) == int:
                                data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                                path = shield.downloadFileURL(data)
                                shield.sendImage(msg.to,path)

            elif msg.contentType == 7:
                stk_id = msg.contentMetadata['STKID']
                stk_ver = msg.contentMetadata['STKVER']
                pkg_id = msg.contentMetadata['STKPKGID']
                number = str(stk_id) + str(pkg_id)
                if sender not in owner:
                  if sender in prevents['limit']:
                    if number in prevents['limit'][sender]['stick']:
                        if prevents ['limit'][sender]['stick'][number] >= 3:
                            prevents ['limit'][sender]['stick']['react'] = False
                            shield.sendMessage(to,'[ Detect Spam Sticker ]')
                        else:
                            prevents ['limit'][sender]['stick'][number] += 1
                            prevents ['limit'][sender]['stick']['react'] = True
                    else:
                        try:
                            del prevents['limit'][sender]['stick']
                        except:
                            pass
                        prevents['limit'][sender]['stick'] = {}
                        prevents['limit'][sender]['stick'][number] = 1
                        prevents['limit'][sender]['stick']['react'] = True
                else:
                    prevents['limit'][sender] = {}
                    prevents['limit'][sender]['stick'] = {}
                    prevents['limit'][sender]['text'] = {}
                    prevents['limit'][sender]['stick'][number] = 1
                    prevents['limit'][sender]['stick']['react'] = True
                    backupLimit()
                if prevents['limit'][sender]['stick']['react'] == False:
                    return
                text = msg.contentMetadata
                shield.addsticker(to,text)
                
            if msg.contentType == 2:
                if sender in owner1:addmedia1(msg,to,media["VIDEO"],wait["Addvideo"],wait["Addmedia"],"VIDEO","Berhasil menambahkan video")

                if sender in wait['shieldCreator']:
                    contact = shield.getProfile()
                    pict = 'http://dl.profile.line-cdn.net/'+ contact.shieldpictStat
                    path = shield.downloadFileURL(pict)
                    if wait["ChangeVP"] == True:
                        path1 = shield.downloadObjectMsg(msg_id)
                        wait["ChangeVP"] =False
                        shield.changeVideoAndPictureProfile(path, path1)
                        shield.sendMessage(to, "╭⸻⟬ GET PROFILE ⟭⸻\n│TYPE ⵓ Changed Video Profile ♪˳\n│STATUS ⵓ Success\n╰⸻ㅡ⟬ FINISH ⟭⸻")

            if msg.contentType == 1:
                if sender in owner1:addmedia1(msg,to,media["IMAGE"],wait["Addimage"],wait["Addmedia"],"IMAGE","Berhasil menambahkan gambar")
                if sender in owner1:#addmedia1(msg,to,media["IMAGE"],wait["Addimage"],wait["Addmedia"],"image","Berhasil menambahkan gambar")
                    if 'image' in wait["Addmedia"]:
                        path = shield.downloadObjectMsg(msg.id)
                        for ls in wait["Addimagechat"]:
                            anu = ls
                        media["CHATPLUS"][to]['image'][anu] = str(path)
                        backupMedia()
                        shield.sendMessage(to,"Berhasil menambahkan gambar")
                        wait["Addmedia"].remove('image')
                        wait["Addimagechat"].remove(ls)
                        backupData()

                if sender in wait["shieldAdmin"][to]:addmedia1(msg,to,media["IMAGE"],wait["Addimage"]["name"],wait["Addmedia"],"IMAGE","Berhasil menambahkan gambar")
                if sender in wait['shieldCreator']:
                    if wait["ChangePP"] == True:
                        path = shield.downloadObjectMsg(msg_id)
                        wait["ChangePP"] = False
                        shield.updateProfilePicture(path)
                        shield.sendMessage(to, "╭⸻⟬ GET PROFILE ⟭⸻\n│TYPE ⵓ Changed Image Profile ♪˳\n│STATUS ⵓ Success\n╰⸻ㅡ⟬ FINISH ⟭⸻")
                        
                if sender in owner1:
                    if wait["Addimage"] == True:
                        try:
                            shield.downloadObjectMsg(msg_id,'path','dataSeen/%s.jpg' % wait["Img"])
                            shield.sendMessage(to, "╭⸻⟬ IMAGE ⟭⸻\n│TYPE ⵓ Add Picture ♪˳\n│STATUS ⵓ Success Add Picture♪\n╰⸻ㅡ⟬ FINISH ⟭⸻")
                        except Exception as e:
                            shield.sendMessage(to,"「 Auto Respond 」\n"+str(e))
                        wait["Img"] = {}
                        wait["Addimage"] = False
                        backupData()

            if msg.contentType == 0:
                if text is None:
                    return
                if to not in wait['shieldAdmin']:
                    wait['shieldAdmin'][to] = {}
                    backupData()
                if to not in wait['shieldBanlist']:
                    wait['shieldBanlist'][to] = {}
                    backupData()
                if to not in media["CHAT"]:
                    media["CHAT"][to] = {}
                    backupMedia()
                if to not in media["CHATPLUS"]:
                    media["CHATPLUS"][to] = {}
                    if 'text' not in media["CHATPLUS"][to]:
                        media["CHATPLUS"][to]['text'] = {}
                        backupMedia()
                if to not in media['IMAGE']:
                    media['IMAGE'][to] = {}
                    backupMedia()
                if to not in media['VIDEO']:
                    media['VIDEO'][to] = {}
                    backupMedia()
                if to not in media['MUSIC']:
                    media['MUSIC'][to] = {}
                    backupMedia()
                if to not in media['STICKER']:
                    media['STICKER'][to] = {}
                    backupMedia()
                      
#===================[Command Creator]======
                      
                if sender in bots:
                    if text.lower() == 'restart':
                        shield.sendMessage(receiver,"╭⸻⟬ RESTART ⟭⸻\n│TYPE ⵓ Restart Programs ♪˳\n│\n│RESTARTING˳˳˳˳˳˳˳˳˳˳˳˳\n╰⸻⸻⸻⸻")
                        wait["restartPoint"] = msg.to
                        wait["rebort"] = True
                        backupData()
                        restart_program()

                    elif text.lower() == wait["setkey"]+'list-group':shield.listgroup(receiver,'')
                    elif text.lower() == wait["setkey"]+'cek-name':shield.name(receiver,msg,text,shieldMID)
                    elif text.lower() == wait["setkey"]+'cek-mid':shield.sendMessage(receiver,shieldMID)
                    elif text.lower() == wait["setkey"]+'cek-bio':shield.bio(receiver,msg,text,shieldMID)
                    elif text.lower() == wait["setkey"]+'cek-pp':shield.pp(receiver,msg,text,shieldMID)
                    elif text.lower() == wait["setkey"]+'cek-vp':shield.vp(receiver,msg,text,shieldMID)
                    elif text.lower() == wait["setkey"]+'cek-cover':shield.cover(receiver,msg,text,shieldMID)
                    elif wait["setkey"]+"listmember: " in msg.text:shield.listmembers(to,text,"╭─「 LIST MEMBER 」\n")
                    elif wait["setkey"]+"mentiongroup: " in msg.text:shield.mentiongrup(to,text,"╭─「 LIST MEMBER 」\n")
                    
                    elif wait["setkey"]+"infogroup: " in msg.text:shield.infoGroup(to,text) 
                    elif text.lower().startswith("autoadd"):settingBots(to,text,Add,wait['shieldStatus'],"Auto Add")
                    elif text.lower().startswith("autojoin"):settingBots(to,text,Join,wait['shieldStatus'],"Auto Join")
                    elif text.lower().startswith("autoleave"):settingBots(to,text,Leave,wait['shieldStatus'],"Auto Leave")
                    elif text.lower().startswith("autoread"):settingBots(to,text,Read,wait['shieldStatus'],"Auto Read")
                    elif text.lower() == "changepp":wait["ChangePP"] = True;shield.sendMessage(to, "Please Send Image ♪˳")
                    elif text.lower() == "changevp":wait["ChangeVP"] = True;shield.sendMessage(to, "Please Send Video ♪˳")

                    elif msg.text.lower().startswith("changevpfrom: "):
                        sep = msg.text.split(" ")
                        query = text.replace(sep[0] + " ","")
                        with requests.session() as web:
                            web.headers["user-agent"] = random.choice(wait["userAgent"])
                            r = web.get("http://207.148.109.52:5000/youtube/?apikey=wrk&url={}".format(urllib.parse.quote(query)))
                            data = r.text
                            data = json.loads(data)
                            video = data["mp4"]["720p"]
                        contact = shield.getProfile()
                        picture = "http://dl.profile.line-cdn.net/"+contact.shieldpictStat
                        path = shield.downloadFileURL(picture)
                        path1 = shield.downloadFileURL(video)
                        shield.changeVideoAndPictureProfile(path, path1)
                        shield.sendMessage(msg.to, "╭⸻⟬ GET PROFILE ⟭⸻\n│TYPE ⵓ Change Video Profile ♪˳\n│STATUS ⵓ Success\n╰⸻ㅡ⟬ FINISH ⟭⸻")

                    elif wait["setkey"]+"mention-group:" in msg.text:
                        separate = text.split(" ")
                        number = text.replace(separate[0] + " ","")
                        ambrose = shield.getGroup(to)
                        groups = shield.getGroupIdsJoined()
                        try:
                            group = groups[int(number)-1]
                            G = shield.getGroup(group)
                            roman = G.id
                            name1 = '⟬GET GROUP FROM ⵓ '+ambrose.shieldName+'⟭'
                            icon1 = 'http://dl.profile.line-cdn.net/'+ambrose.shieldpictStat
                            name = '[ᴍᴇɴᴛɪᴏɴ  ' + G.shieldName + ']'
                            link = 'http://line.me/ti/p/M8k6NlQ_1J'
                            icon = 'http://dl.profile.line-cdn.net/' + G.shieldpictStat
                            nama = [contact.mid for contact in G.shieldMemb]
                            nm1, nm2, nm3, nm4,  nm5, jml = [], [], [], [],  [], len(nama)
                            if jml <= 150:shield.mentionMembers(roman,nama,name,link,icon)
                            if jml > 150 and jml < 500:
                                for i in range(0, 150):
                                    nm1 += [nama[i]]
                                shield.mentionMembers(roman,nm1,name,link,icon)
                                for j in range(150,300):
                                     nm2 += [nama[j]]
                                shield.mentionMembers(roman,nm2,name,link,icon)
                                for k in range(298, len(nama)-2):
                                     nm3 += [nama[k]]
                                shield.mentionMembers(roman,nm3,name,link,icon)
                            shield.sendMessageWithContent(roman,"╭⸻⟬ GET GROUP ⟭⸻\n│TYPE ⵓ Mention Group By Number ♪˳\n│Command From Group ⵓ\n│  ☞ "+ambrose.shieldName+" ☜\n│STATUS ⵓ Success\n╰⸻⸺⟬FINISH⟭⸺",name1,link,icon1)
                            shield.sendMessage(to, 'Success mention all Group '+G.shieldName+' ♪˳')
                        except:
                            pass

                    elif text.lower().startswith(wait["setkey"]+'call'):
                      if msg.toType == 2:
                        separate = text.split(" ")
                        number = text.replace(separate[0] + " ","")
                        groups = shield.getGroupIdsJoined()
                        try:
                            G = groups[int(number)-1]
                            group = shield.getGroup(G)
                            members = [mem.mid for mem in group.shieldMemb]
                            jmlh = int(wait["spamcall"])
                            shield.sendMessage(msg.to, "Succes {} Spam Call Grup ♪˳".format(str(wait["spamcall"])))
                            if jmlh <= 1000:
                                for x in range(jmlh):
                                    try:
                                        shield.acquireGroupCallRoute(G)
                                        shield.inviteIntoGroupCall(G, contactIds=members)
                                    except Exception as e:
                                        shield.sendText(msg.to,str(e))
                            else:
                                shield.sendText(msg.to,"The amount exceeds the limit ♪˳")
                        except Exception as e:
                            shield.sendText(msg.to,str(e))
                    elif wait["setkey"]+"dbl" in msg.text:delbymention(shield,receiver,text,msg,wait["shieldBlacklist"])
                    elif wait["setkey"]+"down" in msg.text:delbymention(shield,receiver,text,msg,wait["shieldOwner"])
                    elif wait["setkey"]+"dbot" in msg.text:delbymention(shield,receiver,text,msg,wait["shieldBots"])
                    elif msg.text.lower().startswith("add_blacklist "):addbymention(shield,receiver,text,msg,wait["shieldBlacklist"])
                    elif msg.text.lower().startswith("del_blacklist "):delbymention(shield,receiver,text,msg,wait["shieldBlacklist"])
                    elif msg.text.lower().startswith("add_owner "):addbymention(shield,receiver,text,msg,wait["shieldOwner"])
                    elif msg.text.lower().startswith("del_owner "):delbymention(shield,receiver,text,msg,wait["shieldOwner"])
                    elif msg.text.lower().startswith("add_blacklist "):addbymention(shield,receiver,text,msg,wait["shieldBots"])
                    elif msg.text.lower().startswith("del_blacklist "):delbymention(shield,receiver,text,msg,wait["shieldBots"])

                    
#                    elif text.startswith("calling"):
 #                       if 'MENTION' in msg.contentMetadata.keys()!= None:
  #                          names = re.findall(r'@(\w+)', text)
   #                         mention = ast.literal_eval(msg.contentMetadata['MENTION'])
    #                        mentionees = mention['MENTIONEES']
     #                       lists = []
      #                      group = shield.getGroup(to)
       #                     for mention in m entionees:
        #                        if mention["M"] not in lists:
         #                           lists.append(mention["M"])
          #                      for ls in lists:
           #                         for var in range(0,50):                                        	
            #                            shield.acquireGroupCallRoute(to)                                            
             #                           members = [ls for ls in lists]
              #                          shield.inviteIntoGroupCall(to, contactIds=members)
               #                     try:
                #                        shield.sendMessage(to,"I am already video call in private chat with "+shield.getContact(ls).displayName)
                 #                       break
                  #                  except Exception as error:
                   #                     logError(error)  

#==================[Command Creator & Owner]=========
                        
                if sender in owner:
                    if text.lower() == wait["setkey"]+' mute' or text.lower() == wait["setkey"]+'mute':mute(receiver,"")
                    elif text.lower() == wait["setkey"]+' unmute' or text.lower() == wait["setkey"]+'unmute':unmute(receiver,"")
                    elif text.lower() == wait["setkey"]+'myticket':shield.myticket(receiver)
                    elif text.lower() == wait["setkey"]+'cekmid':shield.sendMessage(receiver,"[MID]\n" +  shieldMID)
                    elif text.lower() == 'key':shield.mykey(receiver,wait)
                    elif text.lower() == 'key off':shield.mykeyoff(receiver,wait,'public.json')
                    elif text.lower() == 'key reset':shield.mykeyreset(receiver,wait,'public.json')
                    elif text.lower().startswith('key:'):shield.keyset(receiver,text,wait,'public.json')
                    elif text.lower().startswith(wait["setkey"]+"likestatus "):
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for ls in lists:
                                typel = [1001,1002,1003,1004,1005,1006]
                                hasil = shield.getHomeProfile(mid=ls)
                                st = hasil['result']['feeds']
                                for i in range(len(st)):
                                    test = st[i]
                                    result = test['post']['postInfo']['postId']
                                    shield.suka(mid=ls, postId=result, likeType=random.choice(typel))
                                    shield.ngomong(str(ls), str(result),wait['messageComment'])
                                shield.sendMessage(to, 'Like & Comment '+str(len(st))+'\nPost From {}'.format(shield.getContact(ls).shieldName))
                        
                            
                    elif text.lower() == wait["setkey"]+"likeme":
                        me = msg._from
                        typel = [1001,1002,1003,1004,1005,1006]
                        hasil = shield.getHomeProfile(mid=me)
                        st = hasil['result']['feeds']
                        for i in range(len(st)):
                            test = st[i]
                            result = test['post']['postInfo']['postId']
                            shield.suka(mid=me, postId=result, likeType=random.choice(typel))
                            shield.ngomong(str(sender), str(result), 'Auto Like Tes')
                        shield.sendMessage(to, 'Like & Comment '+str(len(st))+'\nPost From {}'.format(shield.getContact(me).shieldName))
                    elif text.lower() == 'spamcall':
                        if msg.toType == 2:
                            group = shield.getGroup(msg.to)
                            members = [mem.mid for mem in group.shieldMemb]
                            jmlh = int(wait["spamcall"])
                            shield.sendMessage(msg.to, "Succes {} Spam Call Grup ♪˳".format(str(wait["spamcall"])))
                            if jmlh <= 1000:
                                for x in range(jmlh):
                                    try:
                                        shield.acquireGroupCallRoute(msg.to)
                                        shield.inviteIntoGroupCall(msg.to, contactIds=members)
                                    except Exception as e:
                                        shield.sendText(msg.to,str(e))
                            else:
                                shield.sendText(msg.to,"The amount exceeds the limit ♪˳")
                                
                    elif text.lower().startswith(wait["setkey"]+'setcall '):
                        proses = text.split(" ")
                        strnum = text.replace(proses[0] + " ","")
                        num =  int(strnum)
                        wait["spamcall"] = num
                        backupData()
                        shield.sendText(msg.to,"Number of Spam Call Changed To " +strnum+' ♪˳')
                        
                    elif msg.text.lower() == 'protectpict on':
                        G = shield.getGroup(to)
                        URL = 'http://dl.profile.line-cdn.net/'+G.shieldpictStat
                        if to not in wait['pictureGroup']:
                            wait['pictureGroup'][to] = URL
                        elif to in wait['pictureGroup']:
                            del wait['pictureGroup'][to]
                            wait['pictureGroup'][to] = URL
                            backupData
                                      
                    elif msg.text.lower() == 'protectpict off':
                        if to not in wait['pictureGroup']:
                            wait['pictureGroup'][to] = ""
                        elif to in wait['pictureGroup']:
                            del wait['pictureGroup'][to]
                            wait['pictureGroup'][to] = ""
                            backupData()
                            
                    elif msg.text.lower() == 'cekpict':
                        if wait['pictureGroup'][to] == "":
                            shield.sendText(to,"picture empty")
                        else:
                            URL = shield.downloadFileURL(wait['pictureGroup'][to])
                            shield.sendImage(to,URL)
                            
                    elif msg.text.lower().startswith("add_react"):
                        list_ = msg.text.split(":")
                        if to not in media['CHAT']:
                            media['CHAT'][to] = {}                            
                        if list_[1] not in media['CHAT'][to]:
                            media['CHAT'][to][list_[1]] = list_[2]
                            backupMedia()
                            shield.sendMessage(to, "[Add new response]\n" + "Keywords: " + list_[1] + "\n response: " + list_[2])
                        else:
                            shield.sendMessage(to, "[ERROR]\n" + "Keyword already exists")
                            
                    elif msg.text.lower().startswith("reactplus"):
                        list_ = msg.text.split(":")
                        if to not in media['CHATPLUS']:
                            media['CHATPLUS'][to] = {}
                        if 'text' not in media['CHATPLUS'][to]:
                            media['CHATPLUS'][to]['text'] = {}
                        if list_[1] not in media['CHATPLUS'][to]['text']:
                            media['CHATPLUS'][to]['text'][list_[1]] = list_[2]
                            if 'stiker' not in media['CHATPLUS'][to]:
                                media['CHATPLUS'][to]['stiker'] = {}
                            if list_[1] not in media['CHATPLUS'][to]['stiker']:
                                wait["Addstickerchat"].append(list_[1])
                                media['CHATPLUS'][to]['stiker'][list_[1]] = ''
                                if 'stiker' not in wait["Addmedia"]:
                                    wait["Addmedia"].append('stiker')
                                backupData()
                            if 'image' not in media['CHATPLUS'][to]:
                                media['CHATPLUS'][to]['image'] = {}
                            if list_[1] not in media['CHATPLUS'][to]['image']:
                                wait["Addimagechat"].append(list_[1])
                                media['CHATPLUS'][to]['image'][list_[1]] = ''
                                if 'image' not in wait["Addmedia"]:
                                    wait["Addmedia"].append('image')
                                backupData()
                                backupMedia()
                                shield.sendText(to,"Silahkan kirim stiker dan gambar nya...!")
                        else:
                            shield.sendMessage(to, "[ERROR]\n" + "Keyword already exists")
                            
                            

                    elif msg.text.lower().startswith("del_react"):
                        list_ = msg.text.split(":")
                        if list_[1] in media['CHAT'][to]:
                            del media['CHAT'][to][list_[1]]
                            backupMedia()
                            shield.sendText(to, "Berhasil menghapus Keyword {}".format(list_[1]))
                        else:
                            shield.sendText(to, "Keyword itu tidak ada dalam list")
                            
                    elif msg.text.lower().startswith("del_allreact"):
                        if to in media['CHAT']:
                            del media['CHAT'][to]
                            media['CHAT'][to] = {}
                            backupMedia()
                            shield.sendText(to, "Berhasil menghapus semua list React")

                    elif msg.text.lower() == "list_react":
                        if media['CHAT'][to] == {}:
                            shield.sendMessage(msg.to, " 「 React List 」\nNo Keyword")
                        else:
                            num=1
                            msgs=" 「 React List 」\nKeyword:"
                            for a in media['CHAT'][to]:
                                msgs+="\n%i. %s" % (num, a)
                                num=(num+1)
                            msgs+="\n\nTotal Reaction List: %i" % len(media['CHAT'][to])
                            shield.sendMessage(msg.to, msgs)

                    elif msg.text.lower().startswith("add_wc"):
                        list_ = msg.text.split(":")
                        if to not in wait['messageWelcome']:
                            try:
                                wait['messageWelcome'][to] = list_[1]
                                backupData()
                                shield.sendMessage(to, "[Success]\Welcome Message successfully in settings ♪˳\n  Wellcome message:   " + list_[1])
                            except:
                                shield.sendMessage(to, "[ERROR]\nSetting Welcome Message Error ♪˳")
                        else:
                            shield.sendMessage(to, "[ERROR]\nWelcome Message already in Settings!!!\nTo change message..,\nPlease type renew_wc:[message]")
                    elif msg.text.lower().startswith("renew_wc"):
                        list_ = msg.text.split(":")
                        if to in wait['messageWelcome']:
                            try:
                                del wait['messageWelcome'][to]
                                wait['messageWelcome'][to] = list_[1]
                                backupData()
                                shield.sendMessage(to, "[Success]\nSuccessfully changed message ♪˳\n  Welcome message: " + list_[1])
                            except:
                                shield.sendMessage(to, "[ERROR]\nMessages Failed in Replace!!!")
                        else:
                            shield.sendMessage(to, "[ERROR]\nMessage is still empty.\nPlease type add_wc:[message]")
                    elif text.lower() == ("del_wc"):
                        if to in wait['messageWelcome']:
                            try:
                                del wait['messageWelcome'][to]
                                backupData()
                                shield.sendMessage(to, "[Success]\nSuccessfully deleted message ♪˳")
                            except:
                                shield.sendMessage(to, "[ERROR]\nMessage Failed Deleted!!!")
                        else:
                            shield.sendMessage(to, "[ERROR]\nEmpty Messages!!!")
                    elif text.lower() == 'wc':
                        if to in wait['messageWelcome']:
                            shield.sendMessage(to, wait['messageWelcome'][to])
                        else:
                            shield.sendMessage(to, "[Tips]\n Please type add_wc:[message]")
                            
                    elif msg.text.lower() == 'resetgroup':
                        group = shield.getGroup(to)
                        shield.sendMessage(to, "[Warning]\nStart resetting groups ♪˳")
                        try:
                            if to in wait['shieldProtect']:
                                wait['shieldProtect'].remove(to)
                            if to in wait['shieldInvite']:
                                wait['shieldInvite'].remove(to)
                            if to in wait['shieldUrl']:
                                wait['shieldUrl'].remove(to)
                            if to in wait['shieldName']:
                                wait['shieldName'].remove(to)
                            if to in wait['stickerOn']:
                                wait['stickerOn'].remove(to)
                            backupData()
                            shield.sendMessage(to, "[WARNING]\nDelete group settings successfully ♪˳")
                        except:
                            shield.sendMessage(to, "[ERROR]\n Failed to delete group settings")
                        try:
                            if to in wait['shieldAdmin']:
                                del wait['shieldAdmin'][to]
                                wait['shieldAdmin'][to] = {}
                                backupData()
                            shield.sendMessage(to, "[WARNING]\nDelete Admin group successfully ♪˳")
                        except:
                            shield.sendMessage(to, "[ERROR]\n Failed to delete Admin group ♪˳")
                    elif text.lower() == 'bot1join':join(to,shield,mid1=[shield1])
                    elif text.lower() == 'bot2join':join(to,shield,mid1=[shield2])
                    elif text.lower() == 'bot3join':join(to,shield,mid1=[shield3])
                    elif text.lower() == 'bot4join':join(to,shield,mid1=[shield4])
                    elif text.lower() == 'bot5join':join(to,shield,mid1=[shield5])
                    elif text.lower() == 'assistjoin':join(to,shield,mid1=[shield1,shield2,shield3,shield4,shield5])
                    elif text.lower() == 'botleave':leave(to,mid=[shield])
                    elif text.lower() == 'bot1leave':leave(to,mid=[shield1])
                    elif text.lower() == 'bot2leave':leave(to,mid=[shield2])
                    elif text.lower() == 'bot3leave':leave(to,mid=[shield3])
                    elif text.lower() == 'bot4leave':leave(to,mid=[shield4])
                    elif text.lower() == 'bot5leave':leave(to,mid=[shield5])
                    elif text.lower() == 'assistleave':leave(to,mid=[shield1,shield2,shield3,shield4,shield5])
                    elif text.lower().startswith("protectkick"):addOnGroup(to,text,wait['shieldProtect'],"Protect Kick")
                    elif text.lower().startswith("protectinvite"):addOnGroup(to,text,wait['shieldInvite'],"Protect Invite")
                    elif text.lower().startswith("protecturl"):addOnGroup(to,text,wait['shieldUrl'],"Protect URL")
                    elif text.lower().startswith("protectname"):addOnGroup(to,text,wait['shieldName'],"Protect Name")
                    elif text.lower().startswith("protectpict"):addOnGroup(to,text,wait['shieldPict'],"Protect Picture")
                    elif text.lower().startswith("protectjoin"):addOnGroup(to,text,wait['shieldJoin'],"Protect Join")
                    elif text.lower().startswith("autochat"):addOnGroup(to,text,wait['autochat'],"Auto Chat")
                    elif text.lower().startswith("mention"):addOnGroup(to,text,wait['shieldMentionGroup'],"Mention")
                    elif text.lower().startswith("sticker"):addOnGroup(to,text,wait['stickerOn'],"Sticker")
                    elif text.lower().startswith("detectmention"):addOnGroup(to,text,wait['shieldDetectMention'],"DetectMention")

                    elif text.startswith("/addimg "):addmedia(to,text,media["IMAGE"],wait["Addimage"],wait["Addmedia"],"IMAGE"," Silahkan kirim fotonya...","Foto itu sudah dalam list")
                                                    
                    elif text.startswith("/delimg "):dellmedia(to,text,media["IMAGE"],"IMAGE")
                                                    
                    elif text.lower() == "/listimage":listmedia(to,media["IMAGE"],"「 Daftar Image 」\n\n","Images")
                    
                    elif text.startswith("/addvideo "):addmedia(to,text,media["VIDEO"],wait["Addvideo"],wait["Addmedia"],"VIDEO"," Silahkan kirim videonya...","Video itu sudah dalam list")
                                                    
                    elif text.startswith("/delvideo "):dellmedia(to,text,media["VIDEO"],"VIDEO")
                                                    
                    elif text.lower() == "/listvideo":listmedia(to,media["VIDEO"],"「 Daftar Video 」\n\n","Video")
                      
                    elif text.startswith("/addmusik "):addmedia(to,text,media["MUSIC"],wait["Addaudio"],wait["Addmedia"],"AUDIO"," Silahkan kirim audionya...","Musik itu sudah dalam list")
                                                    
                    elif text.startswith("/delmusik "):dellmedia(to,text,media["MUSIC"],"AUDIO")
                                                    
                    elif text.lower() == "/listmusik":listmedia(to,media["MUSIC"],"「 Daftar Lagu 」\n\n","Lagu")

                    elif text.startswith("/addstiker "):addmedia(to,text,media["STICKER"],wait["Addsticker"],wait["Addmedia"],"STICKER"," Silahkan kirim stikernya...","Sticker itu sudah dalam list")
                                                    
                    elif text.startswith("/delstiker "):dellmediasticker(to,text,media["STICKER"],"STICKER")
                                                    
                    elif text.lower() == "/liststiker":listmedia(to,media["STICKER"],"「 Daftar Lagu 」\n\n","Lagu")

                    elif msg.text.lower() == 'kick blacklist':
                        if msg.toType == 2:
                            group = shield.getGroup(msg.to)
                            gMembMids = [contact.mid for contact in group.shieldMemb]
                            black_list = []
                            for tag in wait["shieldBlacklist"]:
                                black_list+=filter(lambda str: str == tag, gMembMids)
                            if black_list == []:
                                shield.sendText(msg.to,"Empty Blacklist")
                                return
                            for jj in black_list:
                                try:
                                    shield.kickoutFromGroup(msg.to,[jj])
                                except:
                                    shield.sendText(to,"Member Blacklist not in Group.")
                    elif text.lower() == 'welcome on':welcome(msg.to)
                    elif text.lower() == 'welcome off':welcomeoff(msg.to)
                    elif msg.text.lower().startswith("add_admin "):
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for ls in lists:addAdmin(msg.to,ls)
                        
                    elif text.lower().startswith('create note '):a = shield.createPost(shield.adityasplittext(msg.text,'s'),'TALKROOM')

#====================[Command Creator & Owner & Admin]========
                if sender in wait['shieldAdmin'][to]:
                    if text.lower() == wait["setkey"]+' stickeron' or text.lower() == wait["setkey"]+'stickeron':stickeron(receiver,"")
                    elif text.lower() == wait["setkey"]+' stickeroff' or text.lower() == wait["setkey"]+'stickeroff':stickeroff(receiver,"")
                    elif text.lower() == wait["setkey"]+'list-member':shield.listmember(receiver)
                    elif text.lower() == wait["setkey"]+'info-group':shield.infogroup(receiver)
                    elif text.lower().startswith(wait["setkey"]+'add_sticker'):
                        roman = text.split(" ")
                        ambrose = text.replace(roman[0]+" ","")
                        wait["Sticker"][ambrose] = ambrose
                        wait["Img"] = ambrose
                        wait["Addsticker"] = True
                        backupData()
                        shield.sendMessage(to, " 「 STICKER 」\nSend the sticker")
                    elif text.lower().startswith(wait["setkey"]+'del sti'):
                        separate = text.split("cker ")
                        text = text.replace(separate[0]+"cker ","")
                        del wait["Sticker"][text]
                        backupData()
                        shield.sendMessage(to," 「 IMAGE 」\nSukses Delete Stiker %s ♪˳" % str(text))

                    elif text.lower().startswith(wait["setkey"]+'add pi'):
                        separate = text.split("ct ")
                        text = text.replace(separate[0]+"ct ","")
                        wait["Images"][text] = 'dataSeen/%s.jpg' % text
                        wait["Img"] = '%s' % text
                        wait["Addimage"] = True
                        backupData()
                        shield.sendMessage(to, " 「 IMAGE 」\nSend a Picture to save ♪˳")
                    elif text.lower().startswith(wait["setkey"]+'del pic'):
                        separate = text.split("t ")
                        text = text.replace(separate[0]+"t ","")
                        del wait["Images"][text]
                        backupData()
                        path = os.remove("dataSeen/%s.jpg" % str(text))
                        shield.sendMessage(to," 「 IMAGE 」\nSuccess Delete dataSeen/%s.jpg" % str(text))
                        
                    elif text.lower().startswith(wait["setkey"]+'get-not'):
                        sep = msg.text.split("e")
                        roman = msg.text.replace(sep[0] + "e","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.GroupPost(to)
                        if len(ambrose) == 2:shield.getGroupPostdetail(msg.to,seth,int(ambrose[1]))

                    elif text.lower().startswith(wait["setkey"]+'my-timeli'):
                        sep = text.split("ne")
                        roman = text.replace(sep[0] + "ne","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.mytimeline(receiver, sender)
                        if len(ambrose) == 2:shield.getTimeLine(receiver, sender,seth,int(ambrose[1]))
                    elif text.lower().startswith(wait["setkey"]+'get-timeline'):
                        if 'MENTION' in msg.contentMetadata.keys()!=None:
                            key = eval(msg.contentMetadata["MENTION"])
                            key1 = key["MENTIONEES"][0]["M"]
                            sep = text.split(" ")
                            roman = text.replace(sep[0] + " ","")
                            ambrose = roman.split("|")
                            seth = str(ambrose[0])
                            if len(ambrose) == 1:shield.gettimeline(to, key1)
                            if len(ambrose) == 2:shield.getTimeLine(to, key1,seth,int(ambrose[1]))
                    elif text.lower() == wait["setkey"]+'lurk on' or text.lower() == wait["setkey"]+' lurk on':
                        tz = pytz.timezone("Asia/Jakarta")
                        timeNow = datetime.now(tz=tz)
                        day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                        hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                        bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                        hr = timeNow.strftime("%A")
                        bln = timeNow.strftime("%m")
                        for i in range(len(day)):
                            if hr == day[i]: hasil = hari[i]
                        for k in range(0, len(bulan)):
                            if bln == str(k): bln = bulan[k-1]
                        readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                        if msg.to in wait2['readPoint']:
                            shield.sendMessage(to, " 「 Lurk 」\nLurk already set♪")
                        else:
                            try:
                                del wait2['ROM'][msg.to]
                                del wait2['readPoint'][msg.to]
                                del wait2['setTime'][msg.to]
                            except:
                                pass
                            wait2['readPoint'][msg.to] = msg.id
                            wait2['setTime'][to]  = {}
                            wait2['ROM'][to] = {}
                            backupRead()
                            shield.sendMessage(to, " 「 Lurk 」\nLurk point set on ♪\n" +readTime)
                    elif text.lower() == wait["setkey"]+'lurk off' or text.lower() == wait["setkey"]+' lurk off':
                        if msg.to not in wait2['readPoint']:
                            shield.sendMessage(to, " 「 Lurk 」\nLurk already off ♪")
                        else:
                            try:
                                del wait2['ROM'][msg.to]
                                del wait2['readPoint'][msg.to]
                                del wait2['setTime'][msg.to]
                                backupRead()
                            except:
                                pass
                            shield.sendMessage(to, " 「 Lurk 」\nLurk point off ♪")
                            
                    elif text.lower() == wait["setkey"]+'contactbot':shield.sendContact(to,shieldMID);shield.sendContact(to,aMID);shield.sendContact(to,bMID);shield.sendContact(to,cMID);shield.sendContact(to,dMID);shield.sendContact(to,eMID);shield.sendContact(to,gMID);shield.sendContact(to,jMID)
                    elif text.lower() == 'bot':
                        shield.sendText(to,shieldProfile.shieldName)
                        shield1.sendText(to,aProfile.shieldName)
                        shield2.sendText(to,bProfile.shieldName)
                        shield3.sendText(to,cProfile.shieldName)
                        shield4.sendText(to,dProfile.shieldName)
                        shield5.sendText(to,eProfile.shieldName)
                        
                    elif text.lower() == 'welcome on':welcome(msg.to)
                    elif text.lower() == 'welcome off':welcomeoff(msg.to)
                    elif text.lower() == 'mentionall on':mentionall(msg.to)
                    elif text.lower() == 'mentionall off':mentionalloff(msg.to)                        
                    elif msg.text.lower().startswith("add_admin "):
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for ls in lists:addAdmin(msg.to,ls)

#========================[Command Public]========

                if text.lower() == "/cekmention":cekmention(to,wait)
                if text.lower() == wait["setkey"]+'gcreator' or text.lower() == wait["setkey"]+' gc':shield.gcreator(receiver)
                elif text.lower() == wait["setkey"]+' list sticker' or text.lower() == wait["setkey"]+'list sticker':shield.liststicker(to,'')
                elif text.lower() == wait["setkey"]+' list pict' or text.lower() == wait["setkey"]+'list pict':shield.listpict(to,'')
                elif text.lower() == 'help':shield.help(receiver,'')
                elif text.lower() == wait["setkey"]+'get profile':shield.getprofile(receiver,'')
                elif text.lower() == wait["setkey"]+'primbon':shield.primbon(receiver)
                elif text.lower() == wait["setkey"]+'speed':shield.speed(receiver,'')
                elif text.lower() == wait["setkey"]+'my-pp':shield.pp(receiver,msg,text,sender)
                elif text.lower() == wait["setkey"]+'my-mid':shield.sendMessage(receiver, sender)
                elif text.lower() == wait["setkey"]+'my-name':shield.name(receiver, msg, text, sender)
                elif text.lower() == wait["setkey"]+'my-bio':shield.bio(receiver,msg,text,sender)
                elif text.lower() == wait["setkey"]+'my-cover':shield.cover(receiver, msg, text, sender)
                elif text.lower() == wait["setkey"]+'pict-group':shield.pg(receiver, receiver)
                elif text.lower() == wait["setkey"]+'my-vp':shield.vp(receiver, msg, text, sender)

                elif text.lower() == 'status':
                    contact = shield.getContact(sender)
                    ret_ = "[User status]\n"
                    ret_ += 'Username => ' + contact.shieldName + "\n"
                    if sender in wait['shieldCreator']:
                        ret_ += 'User rights => ' + 'Creator Bots\n'
                        ret_ += 'User restrictions => ' + 'Unlimited\n'
                        ret_ += 'Instruction authority => ' + 'All usefull'
                    elif sender in wait['shieldOwner']:
                        ret_ += 'User rights => ' + 'Owner Bots\n'
                        ret_ += 'User restrictions => ' + 'Unlimited\n'
                        ret_ += 'Instruction authority => ' + 'All without revoke'
                    elif sender in wait['shieldBlacklist']:
                        ret_ += 'User rights => ' + 'Blacklist\n'
                        ret_ += 'User restrictions => ' + 'Full-function limit\n'
                        ret_ += 'Instruction authority => ' + 'All useless\n'
                    elif sender in wait['shieldAdmin'][msg.to]:
                        ret_ += 'User rights => ' + 'Admin Bot\n'
                        ret_ += 'User restrictions => ' + 'Unlimited groups\n'
                        ret_ += 'Instruction authority => ' + 'From Admin to normal\n'
                    else:
                        ret_ += 'User rights => ' + 'Normal\n'
                        ret_ += 'User restrictions => ' + 'General restrictions\n'
                        ret_ += 'Instruction authority => ' + 'Only normal\n'
                    shield.sendMessage(to, ret_)

                elif text.lower().startswith(wait["setkey"]+'stealpp '):shield.pp(receiver,msg,text,sender)
                elif text.lower().startswith(wait["setkey"]+'stealbio '):shield.bio(receiver,msg,text,sender)
                elif text.lower().startswith(wait["setkey"]+'stealname '):shield.name(receiver,msg,text,sender)
                elif text.lower().startswith(wait["setkey"]+'stealvp '):shield.vp(receiver,msg,text,sender)
                elif text.lower().startswith(wait["setkey"]+'stealcover '):shield.cover(receiver,msg,text,sender)

                elif text.lower().startswith(wait["setkey"]+'stealmid '):
                    if 'MENTION' in msg.contentMetadata.keys()!=None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        for ls in lists:shield.sendMessage(receiver,ls)
          
                elif text.lower() == 'sp':
                    start = time.time()
                    shield.sendMessage(to, "processing......")
                    elapsed_time = time.time() - start
                    shield.sendMessage(to,format(str(elapsed_time)) + "second")
                elif text.lower().startswith(wait["setkey"]+'stealbio '):
                    if 'MENTION' in msg.contentMetadata.keys()!=None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        for ls in lists:shield.bio(receiver,ls)
                
                elif text.lower() == 'me':
                    a = shield.getContact(sender)
                    shield.sendContact(to,msg._from)
                    shield.sendMessage(to,a.shieldName,shield.templatemusic("http://dl.profile.line-cdn.net/"+a.shieldpictStat,a.shieldName if a.shieldName != '' else a.userid,a.shieldmsgStat if a.shieldmsgStat != '' else 'THIS MY CONTACT'),19)
                    data ={
                        "cc": carousel,
                        "to": to,
                        "messages":[
                          {
                            "type":"template",
                            "altText": "DETAIL CONTACT",
                            "template":{
                              "imageAspectRatio": "square",
                              "imageSize": "cover",
                              "type": "buttons",
                              "thumbnailImageUrl": "https://obs.line-scdn.net/{}".format(shield.getContact(sender).shieldpictStat),
                              "title":"{}".format(shield.getContact(sender).shieldName),
                              "text":"{}".format(shield.getContact(sender).shieldmsgStat),
                              "actions":[
                                {
                                  "type": "uri",
                                  "label": "COVER IMAGE",
                                  "uri": "https://obs-sg.line-apps.com/myhome/c/download.nhn?oid=122e5b696910bffc98a3b906ff25c7ed&userid="+msg._from,
                                },
                                {
                                  "type": "uri",
                                  "label": "CREATOR",
                                  "uri": "line://ti/p/~aries_jabrik"
                              #    "type":"message",
                               #   "label":"Buy",
                                #  "text":[{'aGFsbG8='}]
                                },
                                {
                                  "type": "uri",
                                  "label": "CITL DESIGN",
                                  "uri": "https://line.me/R/ti/p/%40inp9841n"
                                }
                              ]
                            }
                          }
                        ]
                      }
                    shield.template(carousel,data)
                    
                elif text.lower() == 'tesfm':
                    data = {
                      "cc":carousel,
                      "to": to,
                      "messages": [{"type": "flex","altText": "tes aja","contents":{"type": "bubble",
                            "styles": {"footer": {"separatorColor": "#0000FF","separator": True},
                               "body": {"separatorColor": "#0000FF","separator": True}},
                            "footer": {"type": "box","layout": "vertical",
                              "contents": [{"type": "box","layout": "vertical",
                                  "contents": [{"type": "box","layout": "baseline",
                                      "contents": [{"type": "icon","size": "xl","url": "https://obs.line-scdn.net/{}".format(shield.getContact(sender).shieldpictStat)},{
                                          "type": "text","size": "sm","text": "< Chat With Creator >","color": "#aaaaaa","margin": "xxl","align": "start",
                                          "action": {"type": "uri","label": "Chat With Creator","uri": "http://line.me/ti/p/M8k6NlQ_1J"}}]}]}]},
                            "body": {"type": "box","layout": "vertical", 
                              "contents": [{"type": "text","text": "--Instagram--","color": "#000080","size": "xl","weight": "bold"},{
                                  "type": "text","text": "-Note:\n  *Untuk Staff Bot,Nego Via Pm\nCITL DESIGN:\nKreasi Tanpa Batas","wrap": True,"color": "#000000","size": "sm"}]},
                            "hero": {"type": "image","url": "https://image.ibb.co/b9JR5p/20180811_194145.png","size": "full","aspectMode": "fit"}}}]}
                    shield.template(carousel,data)
                      
                      
                      
                elif text.lower() == 'tes2':
                    link = "https://obs.line-scdn.net/{}".format(shield.getContact(sender).shieldpictStat)
                    shield.flexMessage(to,carousel,"kata","my profile","bhjnbbhjjjhhhhhbbhhh\nhjajjjj\nuwjjjjj\nhjuuuu",link,link,link)
                      
                elif text.lower() == 'tes about':
                    data = {
                      "cc":carousel,
                      "to": to,
                      "messages": [{"type": "flex","altText": "ORDER WOY...!!!","contents": {"type":"carousel","contents": [{
                                "type": "bubble",
                                "header": {"type": "box","layout": "horizontal","contents": [{
                                      "type": "text","text": "OPEN","wrap": True,"weight": "bold","color": "#aaaaaa","size": "xl"}]},
                                "hero": {"type": "image","url": "https://image.ibb.co/b9JR5p/20180811_194145.png","size": "full","aspectMode": "cover","action": {"type": "uri","uri": "http://line.me/ti/p/M8k6NlQ_1J"}},
                                "body": {"type": "box","layout": "vertical","spacing": "xs","contents": [{
                                      "type": "text","text": "SELFTBOT PROTECT\n BY CITL DESIGN","wrap": True,"size": "lg","weight": "bold"},{
                                      "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                          "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                              "type": "text","text": "SelfBot Only","weight": "bold","margin": "none","flex": 0}]}]},{
                                      "type": "text","text": "Rp120k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                      "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                          "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                              "type": "text","text": "SelfBot 2 assist","weight": "bold","margin": "none","flex": 0}]}]},{
                                      "type": "text","text": "Rp170k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                      "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                          "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                              "type": "text","text": "SelfBot 5 assist","weight": "bold","margin": "none","flex": 0}]}]},{
                                      "type": "text","text": "Rp300k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                      "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                          "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                              "type": "text","text": "SelfBot 10 assist","weight": "bold","margin": "none","flex": 0}]}]},{
                                      "type": "text","text": "Rp400k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                  
                                      "type": "text","text": "-Note:\n  *Tambah Anti Js,Nego Via Pm\nCITL DESIGN:\nKreasi Tanpa Batas","wrap": True,"color": "#aaaaaa","size": "md"}]},
                                "footer": {"type": "box","layout": "horizontal","contents": [{
                                      "type": "button","action": {"type": "uri","label": "Clik To Order","uri": "http://line.me/ti/p/M8k6NlQ_1J"}}]}},{
                                "type": "bubble",
                                "header": {"type": "box","layout": "horizontal","contents": [{
                                      "type": "text","text": "ORDER","wrap": True,"weight": "bold","color": "#aaaaaa","size": "xl"}]},
                                "hero": {"type": "image","url": "https://image.ibb.co/b9JR5p/20180811_194145.png","size": "full","aspectMode": "cover","action": {"type": "uri","uri": "http://line.me/ti/p/M8k6NlQ_1J"}},
                                "body": {"type": "box","layout": "vertical","spacing": "xs","contents": [{
                                      "type": "text","text": "BOT PROTECT\n BY CITL DESIGN","wrap": True,"size": "lg","weight": "bold"},{
                                      "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                          "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                              "type": "text","text": "Owner 5 Bot","weight": "bold","margin": "none","flex": 0}]}]},{
                                      "type": "text","text": "Rp250k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                      "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                          "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                              "type": "text","text": "Owner 10 Bot","weight": "bold","margin": "none","flex": 0}]}]},{
                                      "type": "text","text": "Rp450k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                      "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                          "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                              "type": "text","text": "Admin 5 Bot","weight": "bold","margin": "none","flex": 0}]}]},{
                                      "type": "text","text": "Rp200k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                      "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                          "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                              "type": "text","text": "Admin 10 Bot","weight": "bold","margin": "none","flex": 0}]}]},{
                                      "type": "text","text": "Rp350k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                  
                                      "type": "text","text": "-Note:\n  *Untuk Staff Bot,Nego Via Pm\nCITL DESIGN:\nKreasi Tanpa Batas","wrap": True,"color": "#aaaaaa","size": "md"}]},
                                "footer": {"type": "box","layout": "horizontal","contents": [{
                                      "type": "button","action": {"type": "uri","label": "Clik To Order","uri": "http://line.me/ti/p/M8k6NlQ_1J"}}]}},{
                                "type": "bubble",
                                "header": {"type": "box","layout": "horizontal","contents": [{
                                      "type": "text","text": "BOT LINE","wrap": True,"weight": "bold","color": "#aaaaaa","size": "xl"}]},
                                "hero": {"type": "image","url": "https://image.ibb.co/b9JR5p/20180811_194145.png","size": "full","aspectMode": "cover","action": {"type": "uri","uri": "http://line.me/ti/p/M8k6NlQ_1J"}},
                                "body": {"type": "box","layout": "vertical","spacing": "xs","contents": [{
                                      "type": "text","text": "BOT PROTECT WITH ANTI JS\n BY CITL DESIGN","wrap": True,"size": "lg","weight": "bold"},{
                                      "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                          "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                              "type": "text","text": "Owner 5 Bot","weight": "bold","margin": "none","flex": 0}]}]},{
                                      "type": "text","text": "Rp450k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                      "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                          "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                              "type": "text","text": "Owner 10 Bot","weight": "bold","margin": "none","flex": 0}]}]},{
                                      "type": "text","text": "Rp700k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                      "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                          "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                              "type": "text","text": "Admin 5 Bot","weight": "bold","margin": "none","flex": 0}]}]},{
                                      "type": "text","text": "Rp300k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                      "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                          "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                              "type": "text","text": "Admin 10 Bot","weight": "bold","margin": "none","flex": 0}]}]},{
                                      "type": "text","text": "Rp400k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                  
                                      "type": "text","text": "-Note:\n  *Untuk Staff Bot,Nego Via Pm\nCITL DESIGN:\nKreasi Tanpa Batas","wrap": True,"color": "#aaaaaa","size": "md"}]},
                                "footer": {"type": "box","layout": "horizontal","contents": [{
                                      "type": "button","action": {"type": "uri","label": "Clik To Order","uri": "http://line.me/ti/p/M8k6NlQ_1J"}}]}}
                            ]
                          }
                        }
                      ]
                    }
                    shield.template(carousel,data)
                        
                elif text.lower() in media["CHATPLUS"][msg.to]['text']:
                    try:
                        group = shield.getGroup(to)
                        icon = 'http://dl.profile.line-cdn.net/' + group.shieldpictStat
                        sid = media["CHATPLUS"][msg.to]['stiker'][text.lower()]["STKID"]
                        shield.sendText(to, media["CHATPLUS"][msg.to]['text'][text])
                        shield.sendImage(to, media["CHATPLUS"][msg.to]['image'][text],icon)
                        data = {
                            "cc":carousel,
                            "to": to,
                            "messages": [{
                                "type": "template",
                                "altText": "Sticker",
                                "baseSize": { #
                                    "height": 1040, #
                                    "width": 1040 #
                                }, #
                                "template": {
                                    "type": "image_carousel",
                                    "columns": [{
                                        "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/ANDROID/sticker.png".format(sid),
                                        "action": {
                                            "type": "uri",
                                            "uri": "http://line.me/ti/p/M8k6NlQ_1J",
                                            "area": {
                                                "x": 520,
                                                "y": 0,
                                                "width": 520,
                                                "height": 1040
                                            }
                                        }
                                    }]
                                }
                            }]
                        }
                        shield.template(carousel,data)
                    except Exception as e:
                        shield.sendMessage(to,"「 Auto Respond 」\n"+str(e))

                          
                elif text.lower() in media["CHAT"][msg.to]:
                    try:
                        group = shield.getGroup(to)
                        shield.sendText(to, media["CHAT"][msg.to][text.lower()])
                    except Exception as e:
                        shield.sendMessage(to,"「 Auto Respond 」\n"+str(e))

                elif text.lower() in media["STICKER"][msg.to]:
                #    try:
                    if msg.to not in media["STICKER"]:
                        media["STICKER"][msg.to] = {}
                    sid = media["STICKER"][msg.to][text.lower()]["STKID"]
                    spkg = media["STICKER"][msg.to][text.lower()]["STKPKGID"]
                    data = {
                        "cc":carousel,
                        "to": to,
                        "messages": [{
                            "type": "template",
                            "altText": "Sticker",
                            "baseSize": { #
                                "height": 1040, #
                                "width": 1040 #
                            }, #
                            "template": {
                                "type": "image_carousel",
                                "columns": [{
                                    "imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/ANDROID/sticker.png".format(sid),
                                    "action": {
                                        "type": "uri",
                                        "uri": "http://line.me/ti/p/M8k6NlQ_1J",
                                        "area": {
                                            "x": 520,
                                            "y": 0,
                                            "width": 520,
                                            "height": 1040
                                        }
                                    }
                                }]
                            }
                        }]
                    }
                    shield.template(carousel,data)
            #        except Exception as e:
             #           shield.sendMessage(to,"「 Auto Respond 」\n"+str(e))
                        
                

                elif text.lower() in media["IMAGE"]:
                    try:
                        group = shield.getGroup(to)
                        icon = 'http://dl.profile.line-cdn.net/' + group.shieldpictStat
                        shield.sendImage(to, media["IMAGE"][text.lower()],icon)
                    except Exception as e:
                        shield.sendMessage(to,"「 Auto Respond 」\n"+str(e))
                                 
                elif text.lower() in media["VIDEO"]:
                    try:
                        group = shield.getGroup(to)
                        shield.sendVideo(to, media["VIDEO"][text.lower()])
                    except Exception as e:
                        shield.sendMessage(to,"「 Auto Respond 」\n"+str(e))
                        
                elif text.lower() == wait["setkey"]+' list protect' or text.lower() == wait["setkey"]+'list protect':
                    gid = shield.getGroupIdsJoined()
                    ret = " 「 Groups 」\nList Protection groups:"
                    no = 0
                    total = len(gid)
                    for group in gid:
                        G = shield.getGroup(group)
                        member = len(G.shieldMemb)
                        no += 1
                        if group in wait["shieldprotect"]:
                            md="  「✭」 PROTECT KICK : ON\n"
                        else:
                            md="  「✭」 PROTECT KICK : OFF\n"
                        if group in wait["shieldurl"]:
                            md+="  「✭」 PROTECT URL : ON\n"
                        else:
                            md+="  「✭」 PROTECT URL : OFF\n"
                        if group in wait["autoCancel"]:
                            md+="  「✭」 PROTECT CANCEL : ON\n"
                        else:
                            md+="  「✭」 PROTECT CANCEL : OFF\n"
                        if group in wait["shieldmute"]:
                            md+="  「✭」 MUTE"
                        else:
                            md+="  「✭」 UN~MUTE"
                        ret += "\n" + str(no) + ". " + G.shieldName +"\n"+md
                    shield.sendMessage(receiver,ret)#"\n[Kick] [Link] [Invitation] [Mute] [1|ON] [0|OFF]")
                        

                elif text.lower() == wait["setkey"]+"listprotect":
                    ma = ""
                    mb = ""
                    mc = ""
                    md = ""
                    me = ""
                    a = 0
                    gid = wait['shieldprotect']
                    if group in gid:
                        a = a + 1
                        end = '\n'
                        ma += str(a) + ". " +shield.getGroup(group).shieldName + "\n"
                    gid = wait["shieldurl"]
                    if group in gid:
                        a = a + 1
                        end = '\n'
                        mb += str(a) + ". " +shield.getGroup(group).shieldName + "\n"
                    gid = wait["autoCancel"]
                    if group in gid:
                        a = a + 1
                        end = '\n'
                        md += str(a) + ". " +shield.getGroup(group).shieldName + "\n"
                    gid = wait["shieldmute"]
                    if group in gid:
                        a = a + 1
                        end = '\n'
                        mc += str(a) + ". " +shield.getGroup(group).shieldName + "\n"
                    shield.sendMessage(msg.to,"「 List Protect 」\n\n「✭」 PROTECT KICK :\n"+ma+"\n「✭」 PROTECT URL :\n"+mb+"\n「✭」 PROTECT JOIN :\n"+md+"\n「✭」 MUTE GROUP :\n"+mc)#+"\nTotal「%s」Grup diamankan" %(str(len(wait['shieldprotect'])+len(wait['shieldurl'])+len(wait['autoCancel'])+len(wait['shieldmute']))))
                    
                elif text.lower() == 'set':
                    try:
                        ret_ = "  💻[Configuration]💻\n\n┏━━━━━━━━━━━━"
                        if Add in wait["shieldStatus"]: ret_ += "\n┃ 🔐 Auto Add ➮ 「✓」"
                        else: ret_ += "\n┃ 🚨 Auto Add ➮ 「✖」"
                        if Join in wait["shieldStatus"]: ret_ += "\n┃ 🔐 Auto Join ➮ 「✓」"
                        else: ret_ += "\n┃ 🚨 Auto Join ➮ 「✖」"
                        if Leave in wait["shieldStatus"]: ret_ += "\n┃ 🔐 Auto Leave ➮ 「✓」"
                        else: ret_ += "\n┃ 🚨 Auto Leave ➮ 「✖」"
                        if Read in wait["shieldStatus"]: ret_ += "\n┃ 🔐 Auto Read ➮ 「✓」"
                        else: ret_ += "\n┃ 🚨 Auto Read ➮ 「✖」"
                        if to in wait["shieldProtect"]: ret_ += "\n┃ 🔐 Protect Group ➮ 「✓」"
                        else: ret_ += "\n┃ 🚨 Protect Group ➮ 「✖」"
                        if to in wait["shieldInvite"]: ret_ += "\n┃ 🔐 Protect Invite ➮ 「✓」"
                        else: ret_ += "\n┃ 🚨 Protect Invite ➮ 「✖」"
                        if to in wait["shieldUrl"]: ret_ += "\n┃ 🔐 Protect QR ➮ 「✓」"
                        else: ret_ += "\n┃ 🚨 Protect QR ➮ 「✖」"
                        if to in wait["shieldJoin"]: ret_ += "\n┃ 🔐 Protect Join ➮ 「✓」"
                        else: ret_ += "\n┃ 🚨 Protect Join ➮ 「✖」"
                        if to in wait["shieldContact"]: ret_ += "\n┃ 🔐 Detail Contact ➮ 「✓」"
                        else: ret_ += "\n┃ 🚨 Detail Contact ➮ 「✖」"
                        if to in wait["shieldDetectMention"]: ret_ += "\n┃ 🔐 Respon Tag ➮ 「✓」"
                        else: ret_ += "\n┃ 🚨 Respon Tag ➮ 「✖」"
                        if to in wait["shieldWelcome"]: ret_ += "\n┃ 🔐 Welcome ➮ 「✓」"
                        else: ret_ += "\n┃ 🚨 Welcome ➮ 「✖」"
                        if to in wait["shieldMentionGroup"]: ret_ += "\n┃ 🔐 MentionAll ➮ 「✓」"
                        else: ret_ += "\n┃ 🚨 MentionAll ➮ 「✖」"
                        if to in wait["shieldDetectMention"]: ret_ += "\n┃ 🔐 Respon Tag ➮ 「✓」"
                        else: ret_ += "\n┃ 🚨 Respon Tag ➮ 「✖」\n┗━━━━━━━━━━━━\n"
        #                if to in wait["autochat"]: ret_ += "\n┃ 🔐 Auto Chat ➮ 「✓」"
         #               else: ret_ += "\n┃ 🚨 Auto Chat ➮ 「✖」"
          #              if to in  wait["stickerOn"]: ret_ += "\n┃ 🔐 Cek Sticker ➮ 「✓」"
           #             else: ret_ += "\n┃ 🚨 Cek Sticker ➮ 「✖」\n┗━━━━━━━━━━━━\n"
                        shield.sendMessage(to, str(ret_))
                    except Exception as e:
                        shield.sendMessage(msg.to, str(e))

                elif msg.text.lower().startswith(wait["setkey"]+"tr-en "):
                    sep = text.split(" ")
                    isi = text.replace(sep[0] + " ","")
                    translator = Translator()
                    hasil = translator.translate(isi, dest='en')
                    A = hasil.text
                    shield.sendMessage(msg.to, A)

                elif text.lower() == wait["setkey"]+'lurk result' or text.lower() == wait["setkey"]+' lurk result':
                    if msg.to in wait2['readPoint']:
                        chiya = []
                        for rom in wait2["ROM"][to].items():
                            chiya.append(rom[1])
                        sidertag(to,'',chiya)
                        wait2['setTime'][to]  = {}
                        wait2['ROM'][to] = {}
                        backupRead()
                    else:
                        shield.sendMessage(to, " 「 Lurk 」\nLurk point not on♪")
                                               
                elif text.lower() == 'adminlist':list(msg.to,wait['shieldAdmin'][to], "╭───「 List Admin 」──\n│TYPE ⵓ AdminList\n│  1˳ "," < List Admin >")
                elif text.lower() == 'memlistban':list(msg.to,wait['shieldBanlist'][to], "╭───「 List Mem Ban 」──\n│TYPE ⵓ MemListBan\n│  1˳ "," < List Mem Ban >")                            
                elif text.lower() == 'banlist':list(msg.to,wait['shieldBlacklist'], "╭───「 Black List 」──\n│TYPE ⵓ BanList\n│  1˳ "," < BlackList >")
                elif text.lower() == 'botlist':list(msg.to,wait['shieldBots'], "╭───「 List Bots 」──\n│TYPE ⵓ BotList\n│  1˳ "," < List Bots >")
                elif text.lower() == 'ownerlist':list(msg.to,wait['shieldOwner'], "╭───「 List Owner 」──\n│TYPE ⵓ OwnerList\n│  1˳ "," < List Owner >")

#=================[[[[[[[[[[[[[[]]]]]]]]]]]]]]==================

                elif wait["setkey"]+"mention:" in msg.text:
                    if msg.to in wait['shieldMentionGroup']:
                        separate = text.split(" ")
                        number = text.replace(separate[0] + " ","")
                        group = shield.getGroup(to)
                        name = '⟬ᴍᴇɴᴛɪᴏɴ ʙʏ ɴᴜᴍʙᴇʀ⟭'
                        link = 'http://line.me/ti/p/M8k6NlQ_1J'
                        icon = 'http://dl.profile.line-cdn.net/' + group.shieldpictStat
                        nama = [contact.mid for contact in group.shieldMemb]
                        names = nama[int(number)-1]
                        zx = ''
                        zxc = ''
                        zx2 = []
                        xpesan = '╭───「 ᴍᴇɴᴛɪᴏɴ 」──\n│ᴛʏᴘᴇ ⵓ ᴍᴇɴᴛɪᴏɴ ʙʏ ɴᴜᴍʙᴇʀ\n│ᴛᴀʀɢᴇᴛ ⵓ '
                        pesan = ''
                        pesan2 = pesan+"@x \n"
                        xlen = str(len(zxc)+len(xpesan))
                        xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                        zx = {'S':xlen, 'E':xlen2, 'M':names}
                        zx2.append(zx)
                        zxc += pesan2
                        text = xpesan + zxc +"│sᴛᴀᴛᴜs ⵓ sᴜᴄᴄᴇs\n╰───「 ꜰɪɴɪsʜ 」──"
                        shield.sendMessage(to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                    else:
                        shield.sendText(to,'Mention Group is not Active .. !!!! \nContact Admin / Owner / Creator Bots to enable. ')

                elif wait["setkey"]+"mentionall" in msg.text:shield.mentionALL(to,text,"╭─「 MENTIONALL 」\n")

                elif text.lower().startswith(wait["setkey"]+'mentionname:'):
                    if msg.to in wait['shieldMentionGroup']:
                        separate = text.split(" ")
                        texxt = text.replace(separate[0]+" ","")
                        group = shield.getGroup(to)
                        name = '⟬ᴍᴇɴᴛɪᴏɴ ʙʏ ɴᴀᴍᴇ⟭'
                        link = 'http://line.me/ti/p/M8k6NlQ_1J'
                        icon = 'http://dl.profile.line-cdn.net/' + group.shieldpictStat
                        wait["rbio"] = []
                        for s in group.shieldMemb:
                            if texxt in s.shieldName:
                               wait["rbio"].append(s.mid)
                        nama = wait["rbio"]
                        nm1, nm2, nm3, nm4,  nm5, jml = [], [], [], [],  [], len(nama)
                        if jml <= 150:shield.mentionName(msg.to,nama,name,link,icon)
                        if jml > 150 and jml < 500:
                            for i in range(0, 150):
                                nm1 += [nama[i]]
                            shield.mentionName(msg.to,nm1,name,link,icon)
                            for j in range(149, len(nama)-1):
                                   nm2 += [nama[j]]
                            shield.mentionName(msg.to,nm2,name,link,icon)
                        else:
                            pass
                    else:
                        shield.sendText(to,'Mention Group is not Active .. !!!! \nContact Admin / Owner / Creator Bots to enable.')
                        
                elif text.lower().startswith("lempar"):               
                    dice = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"]
                    shield.sendMessage(msg.to, "Melempar dadu...")
                    roll = random.choice(dice)#, k=2)
                    rolltxt = " ".join(roll)
                    shield.sendMessage(msg.to,str(rolltxt))
                    
  #Bagian sc      
                elif text.lower() == "mention me":
                    if to in wait["Mentioned"]:
                        if wait["Mentioned"][to] != {}:
                            ret_ = "[ User Mention ]"
                            no = 1
                            for pler in wait["Mentioned"][to]:
                                contact = shield.getContact(pler)
                                ret_ += "\n{}. {} {}x".format(str(no), str(contact.shieldName), str(wait["Mentioned"][to][pler]))
                            ret_ += "\n[ Total {} user ]".format(str(len(wait["Mentioned"][to])))
                            shield.sendMessage(to, str(ret_))
                            wait["Mentioned"][to] = {}
                            backupData()
                        else:	
                            shield.sendMessage(to, "Nothing mention you")
                    else:
                        shield.sendMessage(to, "Nothing mention you")



#hiburan gan sist
#kalo error anuin sendiri/tambahin sndiri
###################---------------+++++***********

                          
                elif text.lower().startswith(wait["setkey"]+'linetoday'):
                    sep = msg.text.split(" ")
                    roman = msg.text.replace(sep[0] + " ","")
                    ambrose = roman.split("|")
                    seth = str(ambrose[0])
                    if len(ambrose) == 1:shield.LineToday(msg.to,seth)#,sender)
                    if len(ambrose) == 2:shield.LineTodayData(msg.to,seth,int(ambrose[1]))

                elif text.lower() == wait["setkey"]+'kode wilayah':shield.kodewilayah(to,sender)
                    
                elif text.lower().startswith(wait["setkey"]+"lihat "):
                    sep = msg.text.split(" ")
                    text = msg.text.replace(sep[0] + " ","")
                    shield.lewatmana(to,text,sender)
                
                elif text.lower().startswith(wait["setkey"]+"encode "):
                    sep = msg.text.split(" ")
                    text = msg.text.replace(sep[0] + " ","")
                    B64e(to,text)
                    
                elif text.lower().startswith(wait["setkey"]+"decode "):
                    sep = msg.text.split(" ")
                    text = msg.text.replace(sep[0] + " ","")
                    B64d(to,text)
                    
                elif text.lower().startswith(wait["setkey"]+"smule "):
                    sep = msg.text.split(" ")
                    search = msg.text.replace(sep[0] + " ","")
                    shield.smule(to,search)
                        

                elif text.lower().startswith(wait["setkey"]+'smulerecord '):
                    sep = msg.text.split(" ")
                    roman = msg.text.replace(sep[0] + " ","")
                    ambrose = roman.split("|")
                    seth = str(ambrose[0])
                    if len(ambrose) == 1:shield.smule1(msg.to,seth)#,sender)
                    if len(ambrose) == 2:shield.smule1data(msg.to,seth,int(ambrose[1]))

                    
                elif text.lower().startswith(wait["setkey"]+"getyoutube "):#pakai link youtube
                    sep = msg.text.split(" ")
                    search = msg.text.replace(sep[0] + " ","")
                    shield.youtubeMp4(to,search)

                elif text.lower().startswith(wait["setkey"]+"image "):
                    sep = msg.text.split(" ")
                    search = msg.text.replace(sep[0] + " ","")
                    shield.searchimage(to,search)
                        

                elif text.lower().startswith(wait["setkey"]+"googleimage "):
                    sep = msg.text.split(" ")
                    search = msg.text.replace(sep[0] + " ","")
                    shield.Image(to,search)
                    
                elif text.lower().startswith(wait["setkey"]+"short "):
                    sep = msg.text.split(" ")
                    search = msg.text.replace(sep[0] + " ","")
                    shield.url_shorten(to,search)

                elif text.lower().startswith(wait["setkey"]+"cooltext "):
                    sep = msg.text.split(" ")
                    search = msg.text.replace(sep[0] + " ","")
                    shield.cooltext(to,search)

                elif text.lower().startswith(wait["setkey"]+'deviantimage '):
                    sep = msg.text.split(" ")
                    roman = msg.text.replace(sep[0] + " ","")
                    ambrose = roman.split("|")
                    seth = str(ambrose[0])
                    if len(ambrose) == 1:shield.deviantlist(msg.to,seth,sender)
                    if len(ambrose) == 2:shield.deviantdata(msg.to,seth,int(ambrose[1]))
                          
                elif text.lower().startswith(wait["setkey"]+'deviant '):
                    sep = msg.text.split(" ")
                    roman = msg.text.replace(sep[0] + " ","")
                    ambrose = roman.split("|")
                    seth = str(ambrose[0])
                    if len(ambrose) == 1:shield.deviantscrap(msg.to,seth)#,sender)
                    if len(ambrose) == 2:shield.deviantscrapdata(msg.to,seth,int(ambrose[1]))
                    
                elif text.lower().startswith(wait["setkey"]+'walpaperhd '):
                    sep = msg.text.split(" ")
                    roman = msg.text.replace(sep[0] + " ","")
                    ambrose = roman.split("|")
                    seth = str(ambrose[0])
                    if len(ambrose) == 1:shield.wallp(msg.to,seth,sender)
                    if len(ambrose) == 2:shield.wallpdata(msg.to,seth,int(ambrose[1]))

                elif text.lower().startswith(wait["setkey"]+'itunespreview '):
                    sep = msg.text.split(" ")
                    roman = msg.text.replace(sep[0] + " ","")
                    ambrose = roman.split("|")
                    seth = str(ambrose[0])
                    if len(ambrose) == 1:shield.ituneslist(msg.to,seth,sender)
                    if len(ambrose) == 2:shield.itunesdata(msg.to,seth,int(ambrose[1]))


                elif text.lower().startswith(wait["setkey"]+'music '):
                    sep = msg.text.split(" ")
                    roman = msg.text.replace(sep[0] + " ","")
                    ambrose = roman.split("|")
                    seth = str(ambrose[0])
                    if len(ambrose) == 1:shield.musiclist(msg.to,seth,sender)
                    if len(ambrose) == 2:shield.musicdata(msg.to,seth,int(ambrose[1]))
                          
                          
                elif text.lower().startswith(wait["setkey"]+'msc '):
                    sep = msg.text.split(" ")
                    roman = msg.text.replace(sep[0] + " ","")
                    ambrose = roman.split("|")
                    seth = str(ambrose[0])
                    if len(ambrose) == 1:shield.lagu123(msg.to,seth)#,sender)
                    if len(ambrose) == 2:shield.lagu123data(msg.to,seth,int(ambrose[1]))
                        
                elif text.lower().startswith(wait["setkey"]+'apk: '):
                    sep = msg.text.split(" ")
                    roman = msg.text.replace(sep[0] + " ","")
                    ambrose = roman.split("|")
                    seth = str(ambrose[0])
                    if len(ambrose) == 1:shield.getapk(msg.to,seth)#,sender)
                    if len(ambrose) == 2:shield.getapkdata(msg.to,seth,int(ambrose[1]))
                          
                elif text.startswith("detailstiker"):
                    txt = msg.text.split("|")
                    lk = "http://dl.stickershop.line.naver.jp/products/0/0/"+txt[1]+"/"+txt[2]+"/WindowsPhone/productInfo.meta"
                    r = requests.get("http://dl.stickershop.line.naver.jp/products/0/0/"+txt[1]+"/"+txt[2]+"/WindowsPhone/productInfo.meta")
                        #shield.sendText(to,lk)
                    data = r.text
                    data = json.loads(data)
                    for anu in data["stickers"]:
                        b = str(anu["id"])
                        a = "http://dl.stickershop.line.naver.jp/products/0/0/"+txt[1]+"/"+txt[2]+"/WindowsPhone/stickers/"+b+".png"
                        image = shield.downloadFileURL(a)
                        shield.sendImage(to,image)

                elif text.startswith("stickerline "):shield.stickerline(to,text)
                elif text.startswith(wait["setkey"]+"temaline "):shield.temaline(to,text)
                elif text.startswith(wait["setkey"]+"porn"):shield.porn(to,text,sender)
                elif text.startswith(wait["setkey"]+"wikipedia"):shield.wikipedia(to,text,sender)
                elif text.startswith(wait["setkey"]+"instagram"):shield.instagram(to,text,carousel)
                elif text.startswith(wait["setkey"]+"snapgram"):shield.snapgram(to,text)

                  
                  
#*******************TES SC ADIT*******************
 #               elif dits.startswith('spam 1 ') or dits.startswith('spam 2 ') or dits.startswith('unsend ') or dits.startswith('spam 3 ') or dits.startswith('spam 4 ') or dits.startswith('spam 5 ') or dits.startswith('gcall '):a = threading.Thread(target=shield.AdityaSpam, args=(wait,msg)).start()


    except Exception as error:
        logError(error)
        
def sidertag(to, text='', dataMid=[]):
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    hr = timeNow.strftime("%A")
    bln = timeNow.strftime("%m")
    for i in range(len(day)):
        if hr == day[i]: hasil = day[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') +"\n"+ timeNow.strftime('%H:%M:%S') + " WIB"
    now = datetime.now()
    arr = []
    list_text=' 「 Lurk 」\nLurkers: %i member'%(len(dataMid))
    if '[list]' in text.lower():
        i=0
        for l in dataMid:
            list_text+='\n@[list-'+str(i)+']'
            i=i+1
        text=text.replace('[list]', list_text)
    elif '[list-' in text.lower():
        text=text
    else:
        i=0
        no=0
        for l in dataMid:
            z = ""
            chiya = []
        for rom in wait2["setTime"][to].items():
            chiya.append(rom[1])
        for b in chiya:
            a = str(timeago.format(now,b/1000))
            no+=1
            list_text+='\n   '+str(no)+'. @[list-'+str(i)+']\n     「 '+a+" 」"
            i=i+1
        list_text +="\n\nData Rewrite:  \n"+ readTime
        text=text+list_text
    i=0
    for l in dataMid:
        mid=l
        name='@[list-'+str(i)+']'
        ln_text=text.replace('\n',' ')
        if ln_text.find(name):
            line_s=int( ln_text.index(name) )
            line_e=(int(line_s)+int( len(name) ))
        arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
        arr.append(arrData)
        i=i+1
    contentMetadata={'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
    shield.sendMessage(to, text, contentMetadata)
    
def welcome(to):
    wait['messageWelcome'][to] = "Selamat Datang...!!!"
    wait["shieldWelcome"][to] = True
    backupData()
    shield.sendMessage(to, "Automatically Welcome member is turned on")
def welcomeoff(to):
    del wait["shieldWelcome"][to]
    backupData()
    shield.sendMessage(to, "Automatically Welcome member is turned off")
def mentionall(to):
    wait["shieldMentionGroup"][to] = True
    backupData()
    shield.sendMessage(to, "Command Mention is turned on")
def mentionalloff(to):
    del wait["shieldMentionGroup"][to]
    backupData()
    shield.sendMessage(to, "Command Mention is turned off")
    
def addmedia1(msg,to,status,status1,status2,seting,arg):
    if seting in status2:
      if seting != "STICKER":
        path = shield.downloadObjectMsg(msg.id)
        for ls in status1:
            anu = ls
        status[to][anu] = str(path)
        backupMedia()
        shield.sendMessage(to,arg+" "+anu)
        status2.remove(seting)
        status1.remove(ls)
        backupData()
      else:
  #      path = {"STKID":msg.contentMetadata["STKID"],"STKPKGID":msg.contentMetadata["STKPKGID"]}
        for ls in status1:
            anu = ls
        status[to][anu] = {"STKID":msg.contentMetadata["STKID"],"STKPKGID":msg.contentMetadata["STKPKGID"]}
        backupMedia()
        shield.sendMessage(to,arg+" "+anu)
        status2.remove(seting)
        status1.remove(ls)
        backupData()

def addmedia(to,text,status,status1,status2,seting,arg,arg1):
    sep = text.split(" ")
    name = text.replace(sep[0] + " ","")
    name = name.lower()
    if to not in status:
        status[to] = {}
    if name not in status[to]:
        status1.append(name)
        status[to][name] = ""
        backupMedia()
        if seting not in status2:
            status2.append(seting)
        backupData()
        shield.sendText(to,arg) 
    else:
        shield.sendText(to, arg1)
        
def dellmedia(to,text,status,arg):
    sep = text.split(" ")
    name = text.replace(sep[0] + " ","")
    name = name.lower()
    if name in status[to]:
        shield.deleteFile(status[to][str(name.lower())])
        del status[to][str(name.lower())]
        backupMedia()
        shield.sendText(to, "Berhasil menghapus "+arg+" {}".format( str(name.lower())))
    else:
        shield.sendText(to, arg+" itu tidak ada dalam list") 

def dellmediasticker(to,text,status,arg):
    sep = text.split(" ")
    name = text.replace(sep[0] + " ","")
    name = name.lower()
    if name in status[to]:
        del status[to][str(name.lower())]
        backupMedia()
        shield.sendText(to, "Berhasil menghapus "+arg+" {}".format( str(name.lower())))
    else:
        shield.sendText(to, arg+" itu tidak ada dalam list") 

def listmedia(to,status,arg,arg1):
    if to not in status:
        status[to] = {}
    no = 0
    ret_ = arg
    for image in status[to]:
        no += 1
        ret_ += str(no) + ". " + image.title() + "\n"
    ret_ += "\nTotal「{}」{}".format(str(len(status[to])),arg1)
    shield.sendText(to, ret_)

def list(to,status,text,text1):
    try:
        arrData = ""
        textx = text
        arr = []
        no = 1
        mid = status
        for i in mid:
            mention = "@shield \n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if int(no) < int(len(mid)):
                no += 1
                textx += "│  {}˳ ".format(str(no))
            else:
                textx += "│sᴛᴀᴛᴜs ⵓ sᴜᴄᴄᴇs\n│ᴛᴏᴛᴀʟ·ⵓ {} ᴛᴀʀɢᴇᴛ˳\n╰───「 ꜰɪɴɪsʜ 」──".format(str(len(mid)))
        contentMetadata={'MENTION':str('{"MENTIONEES":' + json.dumps(arr) + '}'),"AGENT_NAME":text1,"AGENT_LINK":'',"AGENT_ICON":''}
        shield.sendMessage(to, textx, contentMetadata)
    except:
        shield.sendMessage(to, "No Target list")
           
def dellist(mid,to,text,status):
    separate = text.split(" ")
    number = text.replace(separate[0] + " ","")
    nama = status
    names = nama[int(number)-1]
    status.remove(names)
    backupData()
    mid.sendText(to,"sukses")
    
def addbymention(mid,to,text,msg,status):
    if 'MENTION' in msg.contentMetadata.keys()!= None:
        names = re.findall(r'@(\w+)', text)
        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
        mentionees = mention['MENTIONEES']
        lists = []
        for mention in mentionees:
            if mention["M"] not in lists:
                lists.append(mention["M"])
        for ls in lists:
            if ls not in status:
                status.append(ls)
                backupData()
                mid.sendMessage(to, "Newly add Blacklist")
                mid.sendContact(to, ls)
            else:
                mid.sendMessage(to, "This person already has Blacklist")
                
def delbymention(mid,to,text,msg,status):
    if 'MENTION' in msg.contentMetadata.keys()!= None:
        names = re.findall(r'@(\w+)', text)
        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
        mentionees = mention['MENTIONEES']
        lists = []
        for mention in mentionees:
            if mention["M"] not in lists:
                lists.append(mention["M"])
        for ls in lists:
            if ls in status:
                status.remove(ls)
                backupData()
                mid.sendMessage(to, "Successfully removed member Blacklist")
                mid.sendContact(to, ls)
            else:
                mid.sendMessage(to, "This person does not member Blacklist")
    else:
        separate = text.split(" ")
        number = text.replace(separate[0] + " ","")
        nama = status
        names = nama[int(number)-1]
        status.remove(names)
        backupData()
        mid.sendText(to,"sukses")

def addOnGroup(to,text,status,arg):
    sep = text.split(" ")
    spl = text.replace(sep[0] + " ","")
    if spl == 'on':
        if to in status:
            msgs = arg+" is turned on ♪˳"
        else:
            status.append(to)
            backupData()
            ginfo = shield.getGroup(to)
            msgs = "「 "+arg+" 」\nStatus : [ ON ]\nGroup Name : " +str(ginfo.shieldName)
        shield.sendMessage(to, msgs)
    elif spl == 'off':
        if to in status:
            status.remove(to)
            backupData()
            ginfo = shield.getGroup(to)
            msgs = "「 "+arg+" 」\nStatus : [ OFF ]\nGroup Name : " +str(ginfo.shieldName)
        else:
            msgs = arg+" is turned off ♪˳"
        shield.sendMessage(to, msgs)
               
def settingBots(to,text,seting,status,arg):
    sep = text.split(" ")
    spl = text.replace(sep[0] + " ","")
    if spl == 'on':
        if seting in status:
            msgs = arg+" is already active in this group ♪˳"
        else:
            status.append(seting)
            backupData()
            ginfo = shield.getGroup(to)
            msgs = "「 "+arg+" 」\nStatus : [ ON ]\nGroup Name : " +str(ginfo.shieldName)
        shield.sendMessage(to, msgs)
    elif spl == 'off':
        if seting in status:
            status.remove(seting)
            backupData()
            ginfo = shield.getGroup(to)
            msgs = "「 "+arg+" 」\nStatus : [ OFF ]\nGroup Name : " +str(ginfo.shieldName)
        else:
            msgs = arg+" is not active in this group ♪˳"
        shield.sendMessage(to, msgs)
        
def leave(to,mid=[]):
    for ls in mid:ls.leaveGroup(to)

def join(to,mid,mid1=[]):
    G = mid.getGroup(to)
    for ls in mid1:
        if G.shieldTick == False:
            pass
        else:
            G.shieldTick = False
        mid.updateGroup(G)
        ticket = mid.reissueGroupTicket(to)
        ls.acceptGroupInvitationByTicket(to, ticket)
    G.shieldTick = True
    mid.updateGroup(G)

def kick_url(to,mid,executor,mid1=[]):
    G = mid.getGroup(to)
    for ls in mid1:
        if G.shieldTick == False:
            pass
        else:
            G.shieldTick = False
        mid.updateGroup(G)
        ticket = mid.reissueGroupTicket(to)
        ls.acceptGroupInvitationByTicket(to, ticket)
    G.shieldTick = True
    mid.updateGroup(G)
    mid.kickoutFromGroup(to,[executor])
    if executor not in wait['shieldBlacklist']:
        wait["shieldBlacklist"].append(executor)
    if executor not in wait["shieldBanlist"][to]:
        wait["shieldBanlist"][to] = executor

def kick_add(to,mid,executor,victim,mid1):
    if executor not in wait["shieldBlacklist"]:
        wait["shieldBlacklist"].append(executor)
        mid.kickoutFromGroup(to,executor)
        mid.findAndAddContactsByMid(victim)
        mid.inviteIntoGroup(to,[victim])
        mid1.acceptGroupInvitation(grup)

def B64e(to,url):
	  import base64
	  return shield.sendMessage(to,base64.b64encode(url.encode()).decode())

def B64d(to,url):
  	import base64
  	return shield.sendMessage(to,base64.b64decode(url.encode()).decode())

def delExpire():
    if prevents["temp_flood"] != {}:
        for tmp in prevents["temp_flood"]:
            if prevents["temp_flood"][tmp]["expire"] == True:
                if time.time() - prevents["temp_flood"][tmp]["time"] >= 3*10:
                    prevents["temp_flood"][tmp]["expire"] = False
                    prevents["temp_flood"][tmp]["time"] = time.time()
                    backupLimit()
                    try:
                        am = shield.getProfile()
                        text = "Bot Active Again 🍁"
                        name = "==[ Detected Flood ]=="
                        url = "https://line.me/ti/p/~" + shield.profile.userid
                        iconlink = "http://dl.profile.line-cdn.net/" + am.shieldpictStat
                        shield.sendText(to,text)
                    except Exception as error:
                        logError(error)
                        
                        

def addAdmin(to,mid):
    if to not in wait['shieldAdmin']:
        wait['shieldAdmin'][to] = {}
    if mid not in wait['shieldAdmin'][to]:
        wait['shieldAdmin'][to][mid] = mid
        backupData()
        shield.sendMessage(to, "Admin successfully added ♪˳")
        shield.sendContact(to, mid)
    else:
        shield.sendMessage(to, "Contact is already a admin ♪˳")

def cekmention(to,wait):
    if to in wait['ROM']:
        moneys = {}
        msgas = ''
        for a in wait['ROM'][to].items():
            moneys[a[0]] = [a[1]['msg.id'],a[1]['waktu']] if a[1] is not None else idnya
        sort = sorted(moneys)
        sort.reverse()
        sort = sort[0:]
        msgas = ' 「 Mention Me 」'
        h = []
        no = 0
        for m in sort:
            has = ''
            nol = -1
            for kucing in moneys[m][0]:
                nol+=1
            #    has+= '\nline://nv/chatMsg?chatId={}&messageId={} {}'.format(to,kucing,humanize.naturaltime(datetime.fromtimestamp(moneys[m][1][nol]/1000)))
                has+= '\nline://nv/chatMsg?chatId={}&messageId={} {}'.format(to,kucing,timeago.format(datetime.now(),moneys[m][1][nol]/1000))
            h.append(m)
            no+=1
            if m == sort[0]:
                msgas+= '\n{}. @!{}x{}'.format(no,len(moneys[m][0]),has)
            else:
                msgas+= '\n\n{}. @!{}x{}'.format(no,len(moneys[m][0]),has)
        shield.sendMention(to, msgas,'', h)
        del wait['ROM'][to]
    else:
        try:
            msgas = 'Sorry @!In {} nothink get a mention'.format(shield.getGroup(to).name)
            shield.sendMention(to, msgas,' 「 Mention Me 」\n', [shield.getProfile().mid])
        except:
            msgas = 'Sorry @!In Chat @!nothink get a mention'
            shield.sendMention(to, msgas,' 「 Mention Me 」\n', [shield.getProfile().mid,to])

# Import Import An #
# Def YoutubeMP4 #
def youtubeMp4(to, link):
    subprocess.getoutput('youtube-dl --format mp4 --output TeamAnuBot.mp4 {}'.format(link))
    try:
        shield.sendVideo(to, "TeamAnuBot.mp4")
        time.sleep(2)
        os.remove('TeamAnuBot.mp4')
    except Exception as e:
        shield.sendMessage(to, ' 「 ERROR 」\nMungkin Link Nya Salah GaN~', contentMetadata = {'AGENT_ICON': 'http://dl.profile.line-cdn.net/'+client.getContact(clientMID).pictureStatus, 'AGENT_NAME': '「 ERROR 」', 'AGENT_LINK': 'https://line.me/ti/p/{}'.format(client.getUserTicket().id)})
        
while True:
    delExpire()
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                BotShield(op)
                oepoll.setRevision(op.revision)
    except Exception as e:
        logError(e)
