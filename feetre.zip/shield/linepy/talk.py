# -*- coding: utf-8 -*-
from akad.ttypes import Message
from random import randint
from datetime import datetime
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
import time, random, sys, json, ntpath, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, pytz, urllib, urllib.parse, timeago
from gtts import gTTS
from googletrans import Translator
from wikiapi import WikiApi
with open('public.json', 'r') as fp:
    wait = json.load(fp)
with open('publicRead.json', 'r') as fp:
    wait2 = json.load(fp)
with open('publicLimit.json', 'r') as fp:
    prevents = json.load(fp)
with open('media.json', 'r') as fp:
    media = json.load(fp)
#import json, ntpath

def loggedIn(func):
    def checkLogin(*args, **kwargs):
        if args[0].isLogin:
            return func(*args, **kwargs)
        else:
            args[0].callback.other('You want to call the function, you must login to LINE')
    return checkLogin

class Talk(object):
    isLogin = False
    _messageReq = {}
    _unsendMessageReq = 0
    aris_jabrix = {}


    def __init__(self):
        self.isLogin = True

    """User"""
    
    def changecpvv(self,to,wait):
        try:
            path_vid = wait['talkban']['video']
            files = {'file': open(path_vid, 'rb')}
            obs_params = self.genOBSParams({'oid': self.profile.mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
            data = {'params': obs_params}
            if wait['talkban']['pict'] == '':
                return self.sendMessage(to, " 「 Profile 」\nType: Change Profile Video Picture\nStatus: Send the image....♪")
            self.sendMessage(to, " 「 Profile 」\nType: Change Profile Video Picture\nStatus: Waiting....♪")
            r_vp = self.server.postContent('{}/talk/vp/upload.nhn'.format(str(self.server.LINE_OBS_DOMAIN)), data=data, files=files)
            if r_vp.status_code != 201:return "Failed"
            path_pic = wait['talkban']['pict']
            wait['talkban']['cvp'] = False
            wait['talkban']['pict'] = ''
            self.updateProfilePicture(path_pic, 'vp')
        except Exception as e:
            self.sendMessage(to, " 「 Profile 」\nType: Change Profile Video Picture\nStatus: ERROR 404 Plese Try again")
            
    @loggedIn
    def getRecentMessagesV2(self, chatId, count=101):
        return self.talk.getRecentMessagesV2(chatId,count)
      
    @loggedIn
    def acquireEncryptedAccessToken(self, featureType=2):
        return self.talk.acquireEncryptedAccessToken(featureType)

    @loggedIn
    def getProfile(self):
        return self.talk.getProfile()
      
    @loggedIn
    def getSettings(self):
        return self.talk.getSettings()

    @loggedIn
    def getUserTicket(self):
        return self.talk.getUserTicket()

    @loggedIn
    def updateProfile(self, profileObject):
        return self.talk.updateProfile(0, profileObject)

    @loggedIn
    def updateSettings(self, settingObject):
        return self.talk.updateSettings(0, settingObject)

    @loggedIn
    def updateProfileAttribute(self, attrId, value):
        return self.talk.updateProfileAttribute(0, attrId, value)

    """Operation"""

    @loggedIn
    def fetchOperation(self, revision, count):
        return self.talk.fetchOperations(revision, count)

    @loggedIn
    def getLastOpRevision(self):
        return self.talk.getLastOpRevision()

    """Message"""
    @loggedIn
    def sendText(self, Tomid, text):
        msg = Message()
        msg.to = Tomid
        msg.text = text
        return self.talk.sendMessage(0, msg)
      
    def mycmd(self,text,wait):
        cmd = ''
        pesan = text.lower()
        if wait['setkey'] != '':
            if pesan.startswith(wait['setkey']):
                cmd = pesan.replace(wait['setkey']+' ','').replace(wait['setkey'],'')
        else:
            cmd = text
        return cmd
      
    def adityasplittext(self,text,lp=''):
        separate = text.split(" ")
        if lp == '':
          adalah = text.replace(separate[0]+" ","")
        elif lp == 's':adalah = text.replace(separate[0]+" "+separate[1]+" ","")
        else:adalah = text.replace(separate[0]+" "+separate[1]+" "+separate[2]+" ","")
        return adalah
#deff adit start
    def AdityaSpam(self,wait,msg):
        to = msg.to
        lontong = msg.text
        msg.text = self.mycmd(msg.text,wait)
        ditcmd = msg.text.lower()
        if ditcmd.startswith('spam 1 '):j = int(msg.text.split(' ')[2])
        if ditcmd.startswith('unsend '):j = int(msg.text.split(' ')[1])
        if ditcmd.startswith('spam 2 '):j = int(msg.text.split(' ')[2])
        if ditcmd.startswith('spam 3 '):j = int(msg.text.split(' ')[2])
        if ditcmd.startswith('spam 4 '):j = int(msg.text.split(' ')[2])
        if ditcmd.startswith('spam 5 '):j = int(msg.text.split(' ')[2])
        if ditcmd.startswith('gcall '):j = int(msg.text.split(' ')[1])
        a = [self.adityasplittext(msg.text,'s').replace('{} '.format(j),'')]*j
        if 'MENTION' in msg.contentMetadata.keys()!=None:
            key = eval(msg.contentMetadata["MENTION"])
            key1 = key["MENTIONEES"][0]["M"]
            nama = [key1]
            if ditcmd.startswith('spam 3 '):b = [self.sendContact(to,key1) for b in a];self.sendMention(to, '「 Spam 」\n@!has been spammed with {} amount of contact♪'.format(j),'',[key1])
            if ditcmd.startswith('spam 4 '):
                if lontong.lower().startswith(wait['setkey']+" "):gss = 7 + len(wait['setkey'])+1
                else:gss = 7 + len(wait['setkey'])
                msg.contentMetadata = {'AGENT_LINK': 'line://ti/p/~{}'.format(self.getProfile().userid),'AGENT_ICON': "http://dl.profile.line-cdn.net/" + self.getProfile().picturePath,'AGENT_NAME': ' 「 SPAM MENTION 」','MENTION': str('{"MENTIONEES":' + json.dumps([{'S':str(int(key['S'])-gss-len(msg.text.split(' ')[2])-1+13), 'E':str(int(key['E'])-gss-len(msg.text.split(' ')[2])-1+13), 'M':key['M']} for key in eval(msg.contentMetadata["MENTION"])["MENTIONEES"]]) + '}')}
                msg.text = lontong[gss+1+len(msg.text.split(' ')[2]):].replace(lontong[gss+1+len(msg.text.split(' ')[2]):],' 「 Mention 」\n{}'.format(lontong[gss+1+len(msg.text.split(' ')[2]):]))
                b = [self.sendMessages(msg) for b in a]
            if ditcmd.startswith('spam 2 '):[self.giftmessage(key1) for b in a];self.sendMention(to, '「 Spam 」\n@!has been spammed with {} amount of gift♪'.format(j),'',[key1])
            if ditcmd.startswith('gcall '):b = [self.call.inviteIntoGroupCall(to,nama,mediaType=2) for b in a];self.sendMention(to, '「 Gcall 」\n@!has been spammed with {} amount of call♪'.format(j),'',[key1])
        else:
            if ditcmd.startswith('gcall '):
                group = self.getGroup(to);nama = [contact.mid for contact in group.members];b = [self.call.inviteIntoGroupCall(to,nama,mediaType=2) for b in a]
                self.sendMention(to, ' 「 Gcall 」\n@!spammed with {} amount of call to all member♪'.format(j),'',[msg._from])
            if ditcmd.startswith('spam 3 '):
                try:group = self.getGroup(to);nama = [contact.mid for contact in group.members];b = [self.sendContact(to,random.choice(nama)) for b in a]
                except:nama = [to,to];b = [self.sendContact(to,random.choice(nama)) for b in a]
            if ditcmd.startswith('spam 2 '):b = [self.giftmessage(to) for b in a]
            if ditcmd.startswith('spam 1 '):h = [self.sendMessage(to,b) for b in a];self.sendMessage(to, '「 Spam 」\nTarget has been spammed with {} amount of messages♪'.format(j))
            if ditcmd.startswith('unsend '):
                if len(msg.text.split(' ')) == 2:
                    h = wait['Unsend'][to]['B']
                    n = len(wait['Unsend'][to]['B'])
                    for b in h[:j]:
                        try:
                            self.unsendMessage(b)
                            wait['Unsend'][to]['B'].remove(b)
                        except:pass
                    t = len(wait['Unsend'][to]['B'])
                    self.sendMessage(to," 「 Unsend 」\nUnsend {} message".format((n-t)))
                if len(msg.text.split(' ')) >= 3:h = [self.unsendMessage(self.sendMessage(to,self.adityasplittext(msg.text,'s')).id) for b in a]
                  
    @loggedIn
    def mykey(self, to,wait):
        if wait["setkey"] == '':
            self.sendMessage(to,"╭⸺⟬ᴋᴇʏ ཿ「」⟭⸺\n│ʏᴏᴜʀ ᴋᴇʏ ཿ ᴅɪsᴀʙʟᴇᴅ ♪♪\n│ ᴋᴇʏཿ ➙sᴇᴛ ʏᴏᴜʀ ᴋᴇʏ\n│ ᴋᴇʏ ᴏꜰꜰ ➙ᴅɪsᴀʙʟᴇ ʏᴏᴜʀ ᴋᴇʏ\n│ ᴋᴇʏ ʀᴇsᴇᴛ ➙ʀᴇsᴇᴛ ʏᴏᴜʀ ᴋᴇʏ\n╰⸻⸺⟬ꜰɪɴɪsʜ⟭⸻⸺")
        else:
            self.sendMessage(to,"╭⸺⟬ᴋᴇʏ ཿ「"+wait["setkey"] +"」⟭⸺\n│ʏᴏᴜʀ ᴋᴇʏ ཿ " + wait["setkey"]  + "\n│ ᴋᴇʏཿ ➙sᴇᴛ ʏᴏᴜʀ ᴋᴇʏ\n│ ᴋᴇʏ ᴏꜰꜰ ➙ᴅɪsᴀʙʟᴇ ʏᴏᴜʀ ᴋᴇʏ\n│ ᴋᴇʏ ʀᴇsᴇᴛ ➙ʀᴇsᴇᴛ ʏᴏᴜʀ ᴋᴇʏ\n╰⸻⸺⟬ꜰɪɴɪsʜ⟭⸻⸺")
            
    @loggedIn
    def mykeyoff(self,to,wait,varr):
        wait["setkey"] = ""
        self.backupData1(wait,varr)
        self.sendMessage(to,"╭⸺⟬ᴋᴇʏ ཿ「」⟭⸺\n│ᴋᴇʏ sᴇᴛ ᴅɪsᴀʙʟᴇᴅ♪♪\n╰⼀⼀⟬ ꜰɪɴɪsʜ ⟭⼀⼀")
        
    @loggedIn
    def mykeyreset(self,to,wait,varr):
        wait["setkey"] = "shield:"
        self.backupData1(wait,varr)
        self.sendMessage(to,"╭⸺⟬ᴋᴇʏ ཿ「"+wait["setkey"]+"」⟭⸺\n│ᴋᴇʏ sᴇᴛ ᴛᴏ ཿ "+wait["setkey"]+"\n╰⼀⼀⟬ ꜰɪɴɪsʜ ⟭⼀⼀")
    
    @loggedIn
    def keyset(self,to,text,wait,varr):
        separate = text.split(":")
        roman = text.replace(separate[0]+":","")
        a = wait["setkey"]
        wait["setkey"] = roman
        self.backupData1(wait,varr)
        self.sendMessage(to,"╭⸺⟬ᴋᴇʏ ཿ「"+wait["setkey"]+"」⟭⸺\n│ᴛʏᴘᴇ     ཿ ᴄʜᴀɴɢᴇ ᴋᴇʏ\n│➛ꜰʀᴏᴍ ཿ "+a+"\n│➛ᴛᴏ      ཿ "+roman+"\n│sᴛᴀᴛᴜs ཿ sᴜᴄᴄᴇss\n╰⼀⼀⟬ ꜰɪɴɪsʜ ⟭⼀⼀")

        
    def backupData1(self,var,varr):
        with open(varr, 'w') as fp:
            json.dump(var, fp, sort_keys=True, indent=4)

#def adit finish
    @loggedIn
    def roman(self, to, mid, firstmessage, lastmessage, name, link, icon):
        nama =self.getContact(mid)
        try:
            arrData = ""
            text = "%s " %(str(firstmessage))
            arr = []
            mention = "@{} ".format(str(nama.shieldName))
            slen = str(len(text))
            elen = str(len(text) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':mid}
            arr.append(arrData)
            text += mention + str(lastmessage)
            contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}'),'AGENT_NAME': name, 'AGENT_LINK': link, 'AGENT_ICON': icon}
            self.sendMessage(to,text, contentMetadata)
        except Exception as error:
            print(error)
    @loggedIn
    def jabrix(self, to, mid, firstmessage, lastmessage):
        nama =self.getContact(mid)
        try:
            arrData = ""
            text = "%s " %(str(firstmessage))
            arr = []
            mention = "@{} ".format(str(nama.shieldName))
            slen = str(len(text))
            elen = str(len(text) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':mid}
            arr.append(arrData)
            text += mention + str(lastmessage)
            self.sendMessage(to,text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        except Exception as error:
            print(error)

    @loggedIn
    def mentionMembers(self, to, mid, name, link, icon,text,anu,anu1):
        try:
            arrData = ""
            textx = "╭───「 ᴍᴇɴᴛɪᴏɴ 」──\n│ᴛʏᴘᴇ ⵓ "+text+"\n│ʟɪsᴛ ᴛᴀʀɢᴇᴛ ⵓ\n│  "+anu1+"˳ "
            arr = []
            no = 1
            for i in mid:
                contact = self.getContact(i)
                mention = "@shield \n"#.format(str(contact.shieldName))
                slen = str(len(textx))
                elen = str(len(textx) + len(mention) - 1)
                arrData = {'S':slen, 'E':elen, 'M':i}
                arr.append(arrData)
                textx += mention
                if int(no) < int(len(mid)):
                    no += anu
                    textx += "│  {}˳ ".format(str(no))
                else:
                    textx += "│sᴛᴀᴛᴜs ⵓ sᴜᴄᴄᴇs\n│ᴛᴏᴛᴀʟ·ⵓ {} ᴛᴀʀɢᴇᴛ˳\n╰───「 ꜰɪɴɪsʜ 」──".format(str(len(mid)))
            contentMetadata={'MENTION':str('{"MENTIONEES":' + json.dumps(arr) + '}'),"AGENT_NAME":name,"AGENT_LINK":link,"AGENT_ICON":icon}
            self.sendMessage(to, textx, contentMetadata)
        except Exception as e:
              return self.sendMessage(to,"⟬ʀᴇsᴘᴏɴ ᴇʀʀᴏʀ⟭\n"+str(e))
          
    @loggedIn
    def mentionall1(self,to,bots,text):
        group = self.getGroup(to)
        name = '[ᴍᴇɴᴛɪᴏɴ  ' + group.shieldName + ']'
        link = 'http://line.me/ti/p/M8k6NlQ_1J'
        icon = 'http://dl.profile.line-cdn.net/' + group.shieldpictStat
        nama = [contact.mid for contact in group.shieldMemb]
        for bot in bots:
            if bot in nama:
                nama.remove(bot)
            nm1, nm2, nm3, nm4,  nm5, jml = [], [], [], [],  [], len(nama)
        if jml <= 20:anu=20;self.mentionMembers(to,nama,name,link,icon,text,anu,"20")
        if jml > 21 and jml < 500:
            for i in range(0, 100):
                nm1 += [nama[i]]
            self.mentionMembers(to,nm1,name,link,icon,text)
            for j in range(100,300):
                nm2 += [nama[j]]
            self.mentionMembers(to,nm2,name,link,icon,text)
            for k in range(298, len(nama)-2):
                nm3 += [nama[k]]
            self.mentionMembers(to,nm3,name,link,icon,text)
            
#Update sendMentionV2 by Zero x Yuuki
#Example MentionAll
#group = client.getGroup(to)
#contact = [mem.mid for mem in group.members]
#text = "[ Mention ]"
#for mid in contact:
#    text += "\n+ @!"
#text += "\nSuccess mention %i user" %len(contact)
#sendMentionV2(to, text, contact)
    def sendMention(self,to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@ADIT GANTENG "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:
                    slen = len(textx)+h.count('U0')
                    elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        self.sendMessage(to, textx, {'AGENT_LINK': 'line://ti/p/~{}'.format(self.profile.userid),'AGENT_ICON': "http://dl.profile.line-cdn.net/" + self.getProfile().picturePath,'AGENT_NAME': ps,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

    @loggedIn
    def mentionall(self,to,name,link,icon,text="", mids=[]):
        arrData = ""
        arr = []
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            mention = "@shield "
            textx += str(texts[mids.index(mid)])
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
        contentMetadata={'MENTION':str('{"MENTIONEES":' + json.dumps(arr) + '}'),"AGENT_NAME":name,"AGENT_LINK":link,"AGENT_ICON":icon}
        self.sendMessage(to, textx, contentMetadata)
        
    @loggedIn
    def Mentionall(self,to,text="", mids=[]):
        arrData = ""
        arr = []
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            mention = "@shield "
            textx += str(texts[mids.index(mid)])
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
        contentMetadata={'MENTION':str('{"MENTIONEES":' + json.dumps(arr) + '}')}#,"AGENT_NAME":name,"AGENT_LINK":link,"AGENT_ICON":icon}
        self.sendMessage(to, textx, contentMetadata)
        
    @loggedIn
    def mentionALL(self,to,text,arg):
        group = self.getGroup(to)
        contact = [mem.mid for mem in group.shieldMemb]
        text = arg
        name = ' [ MEMBER '+group.shieldName+']'
        link = 'http://line.me/ti/p/M8k6NlQ_1J'
        icon = 'http://dl.profile.line-cdn.net/'+group.shieldpictStat
        no = 0
        for mid in contact:
            no += 1
            text += "│  {} @!\n".format(str(no))
            text2 = "│Group Name : "+group.shieldName+"\n│Member; {} member\n╰───「 FINISH 」──".format(str(len(contact)))
        self.listmention(to,name,link,icon,text,text2,contact,arg,group)

    @loggedIn
    def mentiongrup(self,to,text,arg):
        separate = text.split(" ")
        number = text.replace(separate[0] + " ","")
        groupss = self.getGroupIdsJoined()
        groups = groupss[int(number)-1]
        group = self.getGroup(groups)
        roman = group.id
        contact = [mem.mid for mem in group.shieldMemb]
        text = arg
        name = ' [ MEMBER '+group.shieldName+']'
        link = 'http://line.me/ti/p/M8k6NlQ_1J'
        icon = 'http://dl.profile.line-cdn.net/'+group.shieldpictStat
        no = 0
        for mid in contact:
            no += 1
            text += "│  {} @!\n".format(str(no))
            text2 = "│Group Name : "+group.shieldName+"\n│Member; {} member\n╰───「 FINISH 」──".format(str(len(contact)))
        self.listmention(roman,name,link,icon,text,text2,contact,arg,group)

    @loggedIn
    def listmembers(self,to,text,arg):
        separate = text.split(" ")
        number = text.replace(separate[0] + " ","")
        groupss = self.getGroupIdsJoined()
        groups = groupss[int(number)-1]
        group = self.getGroup(groups)
        contact = [mem.mid for mem in group.shieldMemb]
        text = arg
        name = ' [ MEMBER '+group.shieldName+']'
        link = 'http://line.me/ti/p/M8k6NlQ_1J'
        icon = 'http://dl.profile.line-cdn.net/'+group.shieldpictStat
        no = 0
        for mid in contact:
            no += 1
            text += "│  {} @!\n".format(str(no))
            text2 = "│Group Name : "+group.shieldName+"\n│Member; {} member\n╰───「 FINISH 」──".format(str(len(contact)))
        self.listmention(to,name,link,icon,text,text2,contact,arg,group)
           
    @loggedIn
    def listmention(self,to,name,link,icon,text,text2,contact,arg,group):
        nm1, nm2, nm3, nm4, nm5, nm6, nm7, nm8, nm9, nm10, nm11, nm12, nm13, nm14, nm15, nm16, nm17, nm18, nm19, nm20, nm21, jml = [], [], [], [],[], [], [], [],[], [], [], [],[], [], [], [], [],[], [], [], [], len(contact)
        if jml <= 20:self.mentionall(to,name,link,icon,text+text2,contact)
        if jml > 20 and jml < 40:self.listAnu(to,arg,group,contact,0,20,nm1);self.listanu(to,"",group,contact,20,len(contact),nm2,text2)
        if jml > 40 and jml < 60:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listanu(to,"",group,contact,40,len(contact),nm3,text2)
        if jml > 60 and jml < 80:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listanu(to,"",group,contact,60,len(contact),nm4,text2)
        if jml > 80 and jml < 100:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listAnu(to,"",group,contact,60,80,nm4);self.listanu(to,"",group,contact,80,len(contact),nm5,text2)
        if jml > 100 and jml < 120:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listAnu(to,"",group,contact,60,80,nm4);self.listAnu(to,"",group,contact,80,100,nm5);self.listanu(to,"",group,contact,100,len(contact),nm6,text2)
        if jml > 120 and jml < 140:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listAnu(to,"",group,contact,60,80,nm4);self.listAnu(to,"",group,contact,80,100,nm5);self.listAnu(to,"",group,contact,100,120,nm6);self.listanu(to,"",group,contact,120,len(contact),nm7,text2)
        if jml > 140 and jml < 160:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listAnu(to,"",group,contact,60,80,nm4);self.listAnu(to,"",group,contact,80,100,nm5);self.listAnu(to,"",group,contact,100,120,nm6);self.listAnu(to,"",group,contact,120,140,nm7);self.listanu(to,"",group,contact,140,len(contact),nm8,text2)
        if jml > 160 and jml < 180:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listAnu(to,"",group,contact,60,80,nm4);self.listAnu(to,"",group,contact,80,100,nm5);self.listAnu(to,"",group,contact,100,120,nm6);self.listAnu(to,"",group,contact,120,140,nm7);self.listAnu(to,"",group,contact,140,160,nm8);self.listanu(to,"",group,contact,160,len(contact),nm9,text2)
        if jml > 180 and jml < 200:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listAnu(to,"",group,contact,60,80,nm4);self.listAnu(to,"",group,contact,80,100,nm5);self.listAnu(to,"",group,contact,100,120,nm6);self.listAnu(to,"",group,contact,120,140,nm7);self.listAnu(to,"",group,contact,140,160,nm8);self.listAnu(to,"",group,contact,160,180,nm9);self.listanu(to,"",group,contact,180,len(contact),nm10,text2)
        if jml > 200 and jml < 220:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listAnu(to,"",group,contact,60,80,nm4);self.listAnu(to,"",group,contact,80,100,nm5);self.listAnu(to,"",group,contact,100,120,nm6);self.listAnu(to,"",group,contact,120,140,nm7);self.listAnu(to,"",group,contact,140,160,nm8);self.listAnu(to,"",group,contact,160,180,nm9);self.listAnu(to,"",group,contact,180,200,nm10);self.listanu(to,"",group,contact,200,len(contact),nm11,text2)
        if jml > 220 and jml < 240:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listAnu(to,"",group,contact,60,80,nm4);self.listAnu(to,"",group,contact,80,100,nm5);self.listAnu(to,"",group,contact,100,120,nm6);self.listAnu(to,"",group,contact,120,140,nm7);self.listAnu(to,"",group,contact,140,160,nm8);self.listAnu(to,"",group,contact,160,180,nm9);self.listAnu(to,"",group,contact,180,200,nm10);self.listAnu(to,"",group,contact,200,220,nm11);self.listanu(to,"",group,contact,220,len(contact),nm12,text2)
        if jml > 240 and jml < 260:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listAnu(to,"",group,contact,60,80,nm4);self.listAnu(to,"",group,contact,80,100,nm5);self.listAnu(to,"",group,contact,100,120,nm6);self.listAnu(to,"",group,contact,120,140,nm7);self.listAnu(to,"",group,contact,140,160,nm8);self.listAnu(to,"",group,contact,160,180,nm9);self.listAnu(to,"",group,contact,180,200,nm10);self.listAnu(to,"",group,contact,200,220,nm11);self.listAnu(to,"",group,contact,220,240,nm12);self.listanu(to,"",group,contact,240,len(contact),nm13,text2)
        if jml > 260 and jml < 280:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listAnu(to,"",group,contact,60,80,nm4);self.listAnu(to,"",group,contact,80,100,nm5);self.listAnu(to,"",group,contact,100,120,nm6);self.listAnu(to,"",group,contact,120,140,nm7);self.listAnu(to,"",group,contact,140,160,nm8);self.listAnu(to,"",group,contact,160,180,nm9);self.listAnu(to,"",group,contact,180,200,nm10);self.listAnu(to,"",group,contact,200,220,nm11);self.listAnu(to,"",group,contact,220,240,nm12);self.listAnu(to,"",group,contact,240,260,nm13);self.listanu(to,"",group,contact,260,len(contact),nm14,text2)
        if jml > 280 and jml < 300:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listAnu(to,"",group,contact,60,80,nm4);self.listAnu(to,"",group,contact,80,100,nm5);self.listAnu(to,"",group,contact,100,120,nm6);self.listAnu(to,"",group,contact,120,140,nm7);self.listAnu(to,"",group,contact,140,160,nm8);self.listAnu(to,"",group,contact,160,180,nm9);self.listAnu(to,"",group,contact,180,200,nm10);self.listAnu(to,"",group,contact,200,220,nm11);self.listAnu(to,"",group,contact,220,240,nm12);self.listAnu(to,"",group,contact,240,260,nm13);self.listAnu(to,"",group,contact,260,280,nm14);self.listanu(to,"",group,contact,280,len(contact),nm15,text2)
        if jml > 300 and jml < 320:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listAnu(to,"",group,contact,60,80,nm4);self.listAnu(to,"",group,contact,80,100,nm5);self.listAnu(to,"",group,contact,100,120,nm6);self.listAnu(to,"",group,contact,120,140,nm7);self.listAnu(to,"",group,contact,140,160,nm8);self.listAnu(to,"",group,contact,160,180,nm9);self.listAnu(to,"",group,contact,180,200,nm10);self.listAnu(to,"",group,contact,200,220,nm11);self.listAnu(to,"",group,contact,220,240,nm12);self.listAnu(to,"",group,contact,240,260,nm13);self.listAnu(to,"",group,contact,260,280,nm14);self.listAnu(to,"",group,contact,280,300,nm15);self.listanu(to,"",group,contact,300,len(contact),nm16,text2)
        if jml > 320 and jml < 340:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listAnu(to,"",group,contact,60,80,nm4);self.listAnu(to,"",group,contact,80,100,nm5);self.listAnu(to,"",group,contact,100,120,nm6);self.listAnu(to,"",group,contact,120,140,nm7);self.listAnu(to,"",group,contact,140,160,nm8);self.listAnu(to,"",group,contact,160,180,nm9);self.listAnu(to,"",group,contact,180,200,nm10);self.listAnu(to,"",group,contact,200,220,nm11);self.listAnu(to,"",group,contact,220,240,nm12);self.listAnu(to,"",group,contact,240,260,nm13);self.listAnu(to,"",group,contact,260,280,nm14);self.listAnu(to,"",group,contact,280,300,nm15);self.listAnu(to,"",group,contact,300,320,nm16);self.listanu(to,"",group,contact,320,len(contact),nm17,text2)
        if jml > 340 and jml < 360:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listAnu(to,"",group,contact,60,80,nm4);self.listAnu(to,"",group,contact,80,100,nm5);self.listAnu(to,"",group,contact,100,120,nm6);self.listAnu(to,"",group,contact,120,140,nm7);self.listAnu(to,"",group,contact,140,160,nm8);self.listAnu(to,"",group,contact,160,180,nm9);self.listAnu(to,"",group,contact,180,200,nm10);self.listAnu(to,"",group,contact,200,220,nm11);self.listAnu(to,"",group,contact,220,240,nm12);self.listAnu(to,"",group,contact,240,260,nm13);self.listAnu(to,"",group,contact,260,280,nm14);self.listAnu(to,"",group,contact,280,300,nm15);self.listAnu(to,"",group,contact,300,320,nm16);self.listAnu(to,"",group,contact,320,340,nm17);self.listanu(to,"",group,contact,340,len(contact),nm18,text2)
        if jml > 360 and jml < 380:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listAnu(to,"",group,contact,60,80,nm4);self.listAnu(to,"",group,contact,80,100,nm5);self.listAnu(to,"",group,contact,100,120,nm6);self.listAnu(to,"",group,contact,120,140,nm7);self.listAnu(to,"",group,contact,140,160,nm8);self.listAnu(to,"",group,contact,160,180,nm9);self.listAnu(to,"",group,contact,180,200,nm10);self.listAnu(to,"",group,contact,200,220,nm11);self.listAnu(to,"",group,contact,220,240,nm12);self.listAnu(to,"",group,contact,240,260,nm13);self.listAnu(to,"",group,contact,260,280,nm14);self.listAnu(to,"",group,contact,280,300,nm15);self.listAnu(to,"",group,contact,300,320,nm16);self.listAnu(to,"",group,contact,320,340,nm17);self.listAnu(to,"",group,contact,340,360,nm18);self.listanu(to,"",group,contact,360,len(contact),nm19,text2)
        if jml > 380 and jml < 400:self.listAnu(to,arg,group,contact,0,20,nm1);self.listAnu(to,"",group,contact,20,40,nm2);self.listAnu(to,"",group,contact,40,60,nm3);self.listAnu(to,"",group,contact,60,80,nm4);self.listAnu(to,"",group,contact,80,100,nm5);self.listAnu(to,"",group,contact,100,120,nm6);self.listAnu(to,"",group,contact,120,140,nm7);self.listAnu(to,"",group,contact,140,160,nm8);self.listAnu(to,"",group,contact,160,180,nm9);self.listAnu(to,"",group,contact,180,200,nm10);self.listAnu(to,"",group,contact,200,220,nm11);self.listAnu(to,"",group,contact,220,240,nm12);self.listAnu(to,"",group,contact,240,260,nm13);self.listAnu(to,"",group,contact,260,280,nm14);self.listAnu(to,"",group,contact,280,300,nm15);self.listAnu(to,"",group,contact,300,320,nm16);self.listAnu(to,"",group,contact,320,340,nm17);self.listAnu(to,"",group,contact,340,360,nm18);self.listAnu(to,"",group,contact,360,380,nm19);self.listanu(to,"",group,contact,380,len(contact),nm20,text2)
        elif jml>400:self.sendText(to,"jumlah melebihi batas")

    @loggedIn
    def listanu(self,to,tekt,group,mid,no1,no2,nm,text2=""):
      name = ' [ MEMBER '+group.shieldName+']'
      link = 'http://line.me/ti/p/M8k6NlQ_1J'
      icon = 'http://dl.profile.line-cdn.net/'+group.shieldpictStat
      text = tekt
      no = no1
      nm1 = nm
      for i in range(no1, no2):
          no += 1
          text += "│  {} @!\n".format(str(no))
          nm1 += [mid[i]]
      self.mentionall(to,name,link,icon,text+text2,nm)
      
    @loggedIn
    def listAnu(self,to,tekt,group,mid,no1,no2,nm,text2=""):
  #    name = ' [ MEMBER '+group.shieldName+']'
   #   link = 'http://line.me/ti/p/M8k6NlQ_1J'
    #  icon = 'http://dl.profile.line-cdn.net/'+group.shieldpictStat
      text = tekt
      no = no1
      nm1 = nm
      for i in range(no1, no2):
          no += 1
          text += "│  {} @!\n".format(str(no))
          nm1 += [mid[i]]
      self.Mentionall(to,text+text2,nm)

    @loggedIn
    def sidertag(self, to, text='', dataMid=[]):
        tz = pytz.timezone("Asia/Jakarta")
        timeNow = datetime.now(tz=tz)
        day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
        hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
        bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
        hr = timeNow.strftime("%A")
        bln = timeNow.strftime("%m")
        for i in range(len(day)):
            if hr == day[i]: hasil = day[i]
        for k in range(0, len(bulan)):
            if bln == str(k): bln = bulan[k-1]
        readTime = "  TIME : [ " + timeNow.strftime('%H:%M:%S') + " ]\n  "+hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') 
        now = datetime.now()
        arr = []
        list_text=' 「 Lurk 」\nLurkers: %i member'%(len(dataMid))
        if '[list]' in text.lower():
            i=0
            for l in dataMid:
                list_text+='\n@[list-'+str(i)+']'
                i=i+1
            text=text.replace('[list]', list_text)
        elif '[list-' in text.lower():
            text=text
        else:
            i=0
            no=0
            for l in dataMid:
                z = ""
                chiya = []
            for rom in wait2["setTime"][to].items():
                chiya.append(rom[1])
            for b in chiya:
                a = str(timeago.format(now,b/1000))
                no+=1
                list_text+='\n   '+str(no)+'. @[list-'+str(i)+']\n     「 '+a+" 」"
                i=i+1
            list_text +="\n\nData Rewrite:  \n"+ readTime
            text=text+list_text
        i=0
        for l in dataMid:
            mid=l
            name='@[list-'+str(i)+']'
            ln_text=text.replace('\n',' ')
            if ln_text.find(name):
                line_s=int( ln_text.index(name) )
                line_e=(int(line_s)+int( len(name) ))
            arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
            arr.append(arrData)
            i=i+1
        contentMetadata={'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
        self.sendMessage(to, text, contentMetadata)
        

    @loggedIn
    def sendMessage(self, to, text, contentMetadata={}, contentType=0):
        msg = Message()
        msg.to, msg._from = to, self.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in self._messageReq:
            self._messageReq[to] = -1
        self._messageReq[to] += 1
        return self.talk.sendMessage(self._messageReq[to], msg)

    @loggedIn
    def sendMessageWithContent(self, to, text, name, link, icon):
        contentMetadata = {'AGENT_NAME': name,'AGENT_LINK': link,'AGENT_ICON': icon}
        return self.sendMessage(to, text, contentMetadata, 0)

#taruh ditalk.py
    """ Usage:
        @to Integer
        @text String
        @dataMid List of user Mid
    """
#        self.sendMessage(to,".")

    @loggedIn
    def speed(self,to,text):
        start = time.time()
        #  self.sendMessage(to, "╭⸺⸻⟬ sᴘᴇᴇᴅ ⟭⸺\n│ᴛʏᴘᴇ ⵓ sᴘᴇᴇᴅ♪\n│ʟᴏᴀᴅɪɴɢ˳˳˳˳\n╰⸻⸺⸺⸻⸺")
        elapsed_time = time.time() - start
        self.sendMessage(to,'sᴘᴇᴇᴅ: % sᴇᴄᴏɴᴅ'% (elapsed_time))

    @loggedIn
    def sendMessageWithMention(self, to, text='', dataMid=[]):
        arr = []
        list_text=''
        if '[list]' in text.lower():
            i=0
            for l in dataMid:
                list_text+='\n@[list-'+str(i)+']'
                i=i+1
            text=text.replace('[list]', list_text)
        elif '[list-' in text.lower():
            text=text
        else:
            i=0
            for l in dataMid:
                list_text+=' @[list-'+str(i)+']'
                i=i+1
            text=text+list_text
        i=0
        for l in dataMid:
            mid=l
            name='@[list-'+str(i)+']'
            ln_text=text.replace('\n',' ')
            if ln_text.find(name):
                line_s=int(ln_text.index(name))
                line_e=(int(line_s)+int(len(name)))
            arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
            arr.append(arrData)
            i=i+1
        contentMetadata={'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
        return self.sendMessage(to, text, contentMetadata)
      
    @loggedIn
    def infoGroup(self,to,text):
        separate = text.split(" ")
        number = text.replace(separate[0] + " ","")
        groups = self.getGroupIdsJoined()
        ret_ = ""
        try:
            group = groups[int(number)-1]
            G = self.getGroup(group)
            try:gCreator = G.shieldCreat.shieldName
            except:gCreator = "No file"
            if G.invitee is None:gPending = "0"
            else:gPending = str(len(G.invitee))
            if G.shieldTick == True:
                gQr = "Tertutup"
                gTicket = "Tidak ada"
            else:
                gQr = "Terbuka"
                gTicket = "https://line.me/R/ti/g/{}".format(str(shield.reissueGroupTicket(G.id)))
            timeCreated = []
            timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
            ret_ += "┌━━━「Group Info」━━━━\n├"
            ret_ += "\n├🎖Nama Group : {}".format(G.shieldName)
            ret_ += "\n├🎖ID Group : {}".format(G.id)
            ret_ += "\n├🎖Pembuat : {}".format(gCreator)
            ret_ += "\n├🎖Waktu Dibuat : {}".format(str(timeCreated))
            ret_ += "\n├🎖Jumlah Member : {}".format(str(len(G.shieldMemb)))
            ret_ += "\n├🎖Jumlah Pending : {}".format(gPending)
            ret_ += "\n├🎖Group Qr : {}".format(gQr)
            ret_ += "\n├🎖Group Ticket : {}".format(gTicket)
            ret_ += "\n└━━━━「Done」━━━━"
            self.sendMessage(to, str(ret_))
        except:
            pass
          
    @loggedIn
    def infogroup(self,to):
        ret_ = ""
        try:
            G = self.getGroup(to)
            try:gCreator = G.shieldCreat.shieldName
            except:gCreator = "No file"
            if G.invitee is None:gPending = "0"
            else:gPending = str(len(G.invitee))
            if G.shieldTick == True:
                gQr = "Tertutup"
                gTicket = "Tidak ada"
            else:
                gQr = "Terbuka"
                gTicket = "https://line.me/R/ti/g/{}".format(str(shield.reissueGroupTicket(G.id)))
            timeCreated = []
            timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
            ret_ += "┌━━━「Group Info」━━━━\n├"
            ret_ += "\n├🎖Nama Group : {}".format(G.shieldName)
            ret_ += "\n├🎖ID Group : {}".format(G.id)
            ret_ += "\n├🎖Pembuat : {}".format(gCreator)
            ret_ += "\n├🎖Waktu Dibuat : {}".format(str(timeCreated))
            ret_ += "\n├🎖Jumlah Member : {}".format(str(len(G.shieldMemb)))
            ret_ += "\n├🎖Jumlah Pending : {}".format(gPending)
            ret_ += "\n├🎖Group Qr : {}".format(gQr)
            ret_ += "\n├🎖Group Ticket : {}".format(gTicket)
            ret_ += "\n└━━━━「Done」━━━━"
            self.sendMessage(to, ret_)
        except Exception as e:
              return self.sendMessage(to,"⟬ʀᴇsᴘᴏɴ ᴇʀʀᴏʀ⟭\n"+str(e))


    def sendMentionV2(self,to, text="", mids=[]):
        arrData = ""
        arr = []
      #  contact = self.getContact(mids)
        mention = "@zeroxyuuki "#.format(str(contact.shieldName))
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ""
            for mid in mids:
                textx += str(texts[mids.index(mid)])
                slen = len(textx)
                elen = len(textx)# + 15
                #arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
                arrData = {'S':str(slen), 'E':str(elen), 'M':mid}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ""
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        self.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

      
    @loggedIn
    def listmember(self,to):
        group = self.getGroup(to)
        name = '⟬ ʟɪsᴛ ᴍᴇᴍʙᴇʀ ⟭'
        link = 'http://line.me/ti/p/M8k6NlQ_1J'
        icon = 'http://dl.profile.line-cdn.net/' + group.shieldpictStat
        zxc = "╭⸺⟬ ɢᴇᴛ ɢʀᴏᴜᴘ ⟭⸺\n│ᴛʏᴘᴇ ⵓ ʟɪsᴛ ᴍᴇᴍʙᴇʀ ♪\n│ɢɴᴀᴍᴇ ⵓ "+group.shieldName+"\n│ᴍᴇᴍʙᴇʀs ⵓ"
        total = "\n│\n│ɢɪᴅ ⵓ\n│"+to+"\n│sᴛᴀᴛᴜs ⵓ sᴜᴄᴄᴇs\n╰⸻⟬ ꜰɪɴɪsʜ ⟭⸻"
        no = 0
        if len(group.shieldMemb) > 0:
            for a in group.shieldMemb:
                no += 1
                zxc += "\n│  " + str(no) + ". " + a.shieldName
        return self.sendMessageWithContent(to,zxc+total,name,link,icon)

    @loggedIn
    def listgroup(self,to,text):
        group = self.getGroup(to)
        name = '⟬  ɢʀᴏᴜᴘ ʟɪsᴛ ⟭'
        link = 'http://line.me/ti/p/M8k6NlQ_1J'
        icon = 'http://dl.profile.line-cdn.net/' + group.shieldpictStat
        ma = ""
        a = 0
        gid = self.getGroupIdsJoined()
        for i in gid:
            G = self.getGroup(i)
            a = a + 1
            end = "\n"
            ma += "│ " + str(a) + ". " +G.shieldName+ "\n"
        return self.sendMessageWithContent(to,"╭⸺⟬ɢᴇᴛ ɢʀᴏᴜᴘ⟭⸺\n│ᴛʏᴘᴇ     ཿ ʟɪsᴛ ɢʀᴏᴜᴘ\n│\n"+ma+"\n│ᴛᴏᴛᴀʟ   ⵓ「"+str(len(gid))+"」ɢʀᴏᴜᴘs\n╰⼀⼀⟬ ꜰɪɴɪsʜ ⟭⼀⼀",name,link,icon)
      
    @loggedIn
    def gcreator(self,to):
        try:
            group = self.getGroup(to)
            GS = group.shieldCreat.mid
            self.sendContact(to, GS)
        except:
            GS = group.shieldMemb[0].mid
            self.sendContact(to, GS)
            self.sendMessage(to,"Karena Creator GROUP tidak ada saat ini, saya menunjukkan pengguna yang pertama kali masuk ke GROUP yang ada")

    @loggedIn
    def name(self,to,msg,text,mid):
        if 'MENTION' in msg.contentMetadata.keys()!=None:
            names = re.findall(r'@(\w+)', text)
            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            mentionees = mention['MENTIONEES']
            lists = []
            for mention in mentionees:
                if mention["M"] not in lists:
                    lists.append(mention["M"])
            for ls in lists:
                contact = self.getContact(ls)
                name = '⟬ɪᴍᴀɢᴇ ᴘʀᴏꜰɪʟᴇ '+contact.shieldName+'⟭'
                cu = "http://dl.profile.line-cdn.net/" + contact.shieldpictStat
                self.roman(to, ls, "╭────〔ɢ̲̅ᴇ̲̅ᴛ̲̅ ᴘ̲̅ʀ̲̅ᴏ̲̅ꜰ̲̅ɪ̲̅ʟ̲̅ᴇ̲̅ 〕────\n│ᴛʏᴘᴇ ⵓ ᴘʀᴏꜰɪʟᴇ ɴᴀᴍᴇ ♪˳\n│ᴛᴀʀɢᴇᴛ  ཿ  ","\n│═════════════════\n│   ᴅɪsᴘʟᴀʏ ɴᴀᴍᴇ ⵓ "+contact.shieldName+"\n│   sᴛᴀᴛᴜs  ཿ sᴜᴄᴄᴇs\n╰─────〔 ꜰɪɴɪsʜ 〕──────", name, cu, cu)
        else:
            contact = self.getContact(mid)
            name = '⟬ɪᴍᴀɢᴇ ᴘʀᴏꜰɪʟᴇ '+contact.shieldName+'⟭'
            cu = "http://dl.profile.line-cdn.net/" + contact.shieldpictStat
            self.roman(to, mid, "╭────〔ɢ̲̅ᴇ̲̅ᴛ̲̅ ᴘ̲̅ʀ̲̅ᴏ̲̅ꜰ̲̅ɪ̲̅ʟ̲̅ᴇ̲̅ 〕────\n│ᴛʏᴘᴇ ⵓ ᴘʀᴏꜰɪʟᴇ ɴᴀᴍᴇ ♪˳\n│ᴛᴀʀɢᴇᴛ  ཿ  ","\n│═════════════════\n│   ᴅɪsᴘʟᴀʏ ɴᴀᴍᴇ ⵓ "+contact.shieldName+"\n│   sᴛᴀᴛᴜs  ཿ sᴜᴄᴄᴇs\n╰─────〔 ꜰɪɴɪsʜ 〕──────", name, cu, cu)

    @loggedIn
    def bio(self,to,msg,text,mid):
        if 'MENTION' in msg.contentMetadata.keys()!=None:
            names = re.findall(r'@(\w+)', text)
            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            mentionees = mention['MENTIONEES']
            lists = []
            for mention in mentionees:
                if mention["M"] not in lists:
                    lists.append(mention["M"])
            for ls in lists:
                contact = self.getContact(ls)
                name = '⟬ɪᴍᴀɢᴇ ᴘʀᴏꜰɪʟᴇ '+contact.shieldName+'⟭'
                cu = "http://dl.profile.line-cdn.net/" + contact.shieldpictStat
                self.roman(to, ls, "╭────〔ɢ̲̅ᴇ̲̅ᴛ̲̅ ᴘ̲̅ʀ̲̅ᴏ̲̅ꜰ̲̅ɪ̲̅ʟ̲̅ᴇ̲̅ 〕────\n│ᴛʏᴘᴇ ⵓ sᴛᴀᴛᴜs ᴍᴇssᴀɢᴇ ♪˳\n│ᴛᴀʀɢᴇᴛ  ཿ  ","\n│═════════════════\n│   sᴛᴀᴛᴜs ᴍᴇssᴀɢᴇ ⵓ "+contact.shieldmsgStat+"\n│   sᴛᴀᴛᴜs  ཿ sᴜᴄᴄᴇs\n╰─────〔 ꜰɪɴɪsʜ 〕──────", name, cu, cu)
        else:
            contact = self.getContact(mid)
            name = '⟬ɪᴍᴀɢᴇ ᴘʀᴏꜰɪʟᴇ '+contact.shieldName+'⟭'
            cu = "http://dl.profile.line-cdn.net/" + contact.shieldpictStat
            self.roman(to, mid, "╭────〔ɢ̲̅ᴇ̲̅ᴛ̲̅ ᴘ̲̅ʀ̲̅ᴏ̲̅ꜰ̲̅ɪ̲̅ʟ̲̅ᴇ̲̅ 〕────\n│ᴛʏᴘᴇ ⵓ sᴛᴀᴛᴜs ᴍᴇssᴀɢᴇ ♪˳\n│ᴛᴀʀɢᴇᴛ  ཿ  ","\n│═════════════════\n│   sᴛᴀᴛᴜs ᴍᴇssᴀɢᴇ ⵓ "+contact.shieldmsgStat+"\n│   sᴛᴀᴛᴜs  ཿ sᴜᴄᴄᴇs\n╰─────〔 ꜰɪɴɪsʜ 〕──────", name, cu, cu)
                    
    @loggedIn
    def pp(self,to,msg,text,mid):
        if 'MENTION' in msg.contentMetadata.keys()!=None:
            names = re.findall(r'@(\w+)', text)
            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            mentionees = mention['MENTIONEES']
            lists = []
            for mention in mentionees:
                if mention["M"] not in lists:
                    lists.append(mention["M"])
            for ls in lists:
                contact = self.getContact(ls)
                name = '⟬ɪᴍᴀɢᴇ ᴘʀᴏꜰɪʟᴇ '+contact.shieldName+'⟭'
                cu = "http://dl.profile.line-cdn.net/" + contact.shieldpictStat
                self.sendImageWithURL1(to, cu, name, cu, cu)
                self.roman(to, ls, "╭⸻⟬ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ⟭⸻\n│ᴛʏᴘᴇ      ཿ ɪᴍᴀɢᴇ ᴘʀᴏꜰɪʟᴇ\n│ᴛᴀʀɢᴇᴛ  ཿ  ","\n│sᴛᴀᴛᴜs  ཿ sᴜᴄᴄᴇs\n╰⸺⸺⟬ ꜰɪɴɪsʜ ⟭⸺⸻", name, cu, cu)
        else:
            contact = self.getContact(mid)
            name = '⟬ɪᴍᴀɢᴇ ᴘʀᴏꜰɪʟᴇ '+contact.shieldName+'⟭'
            cu = "http://dl.profile.line-cdn.net/" + contact.shieldpictStat
            self.sendImageWithURL1(to, cu, name, cu, cu)
            self.roman(to, mid, "╭⸻⟬ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ⟭⸻\n│ᴛʏᴘᴇ      ཿ ɪᴍᴀɢᴇ ᴘʀᴏꜰɪʟᴇ\n│ᴛᴀʀɢᴇᴛ  ཿ  ","\n│sᴛᴀᴛᴜs  ཿ sᴜᴄᴄᴇs\n╰⸺⸺⟬ ꜰɪɴɪsʜ ⟭⸺⸻", name, cu, cu)

    @loggedIn
    def cover(self,to,msg,text,mid):
        if 'MENTION' in msg.contentMetadata.keys()!=None:
            names = re.findall(r'@(\w+)', text)
            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            mentionees = mention['MENTIONEES']
            lists = []
            for mention in mentionees:
                if mention["M"] not in lists:
                    lists.append(mention["M"])
            for ls in lists:
                contact = self.getContact(ls)
                name = '⟬ɪᴍᴀɢᴇ ᴘʀᴏꜰɪʟᴇ '+contact.shieldName+'⟭'
                cu = self.getProfileCoverURL(ls)
                self.sendImageWithURL1(to, cu, name, cu, cu)
                self.roman(to, ls, "╭⸻⟬ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ⟭⸻\n│ᴛʏᴘᴇ      ཿ ɪᴍᴀɢᴇ ᴘʀᴏꜰɪʟᴇ\n│ᴛᴀʀɢᴇᴛ  ཿ  ","\n│sᴛᴀᴛᴜs  ཿ sᴜᴄᴄᴇs\n╰⸺⸺⟬ ꜰɪɴɪsʜ ⟭⸺⸻", name, cu, cu)
        else:
            contact = self.getContact(mid)
            name = '⟬ɪᴍᴀɢᴇ ᴘʀᴏꜰɪʟᴇ '+contact.shieldName+'⟭'
            cu = self.getProfileCoverURL(mid)
            self.sendImageWithURL1(to, cu, name, cu, cu)
            self.sendMessage(to,cu)
            self.roman(to, mid, "╭⸻⟬ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ⟭⸻\n│ᴛʏᴘᴇ      ཿ ɪᴍᴀɢᴇ ᴘʀᴏꜰɪʟᴇ\n│ᴛᴀʀɢᴇᴛ  ཿ  ","\n│sᴛᴀᴛᴜs  ཿ sᴜᴄᴄᴇs\n╰⸺⸺⟬ ꜰɪɴɪsʜ ⟭⸺⸻", name, cu, cu)

    @loggedIn
    def vp(self,to,msg,text,mid):
        if 'MENTION' in msg.contentMetadata.keys()!=None:
            names = re.findall(r'@(\w+)', text)
            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            mentionees = mention['MENTIONEES']
            lists = []
            for mention in mentionees:
                if mention["M"] not in lists:
                    lists.append(mention["M"])
            for ls in lists:
                contact = self.getContact(ls)
                name = '⟬ɪᴍᴀɢᴇ ᴘʀᴏꜰɪʟᴇ '+contact.shieldName+'⟭'
                icon = "http://dl.profile.line-cdn.net/" + contact.shieldpictStat
                cu = "http://dl.profile.line-cdn.net/" + contact.shieldpictStat + "/vp.small"
            self.sendVideoWithURL(to, cu)
            self.roman(to, ls, "╭⸻⟬ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ⟭⸻\n│ᴛʏᴘᴇ      ཿ ᴠɪᴅᴇᴏ ᴘʀᴏꜰɪʟᴇ\n│ᴛᴀʀɢᴇᴛ  ཿ ","\n│sᴛᴀᴛᴜs  ཿ sᴜᴄᴄᴇs\n╰⸺⸺⟬ ꜰɪɴɪsʜ ⟭⸺⸻", name, cu, icon)
        else:
            contact = self.getContact(mid)
            name = '⟬ɪᴍᴀɢᴇ ᴘʀᴏꜰɪʟᴇ '+contact.shieldName+'⟭'
            icon = "http://dl.profile.line-cdn.net/" + contact.shieldpictStat
            cu = "http://dl.profile.line-cdn.net/" + contact.shieldpictStat + "/vp.small"
            self.sendVideoWithURL(to, cu)
            self.roman(to, mid, "╭⸻⟬ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ⟭⸻\n│ᴛʏᴘᴇ      ཿ ᴠɪᴅᴇᴏ ᴘʀᴏꜰɪʟᴇ\n│ᴛᴀʀɢᴇᴛ  ཿ ","\n│sᴛᴀᴛᴜs  ཿ sᴜᴄᴄᴇs\n╰⸺⸺⟬ ꜰɪɴɪsʜ ⟭⸺⸻", name, cu, icon)

    @loggedIn
    def pg(self,to,mid):
        contact = self.getGroup(mid)
        try:
            name = '⟬ ᴘʀᴏꜰɪʟᴇ '+contact.shieldName+'⟭'
            cu = "http://dl.profile.line-cdn.net/" + contact.shieldpictStat
            self.sendImageWithURL1(to, cu, name, cu, cu)
            self.sendMessageWithContent(to, "╭⸻⟬ɢᴇᴛ ɢʀᴏᴜᴘ⟭⸻\n│ᴛʏᴘᴇ      ཿ ɢʀᴏᴜᴘ ɪᴍᴀɢᴇ\n│ᴛᴀʀɢᴇᴛ  ཿ  "+contact.shieldName+"\n│sᴛᴀᴛᴜs  ཿ sᴜᴄᴄᴇs\n╰⸺⸺⟬ ꜰɪɴɪsʜ ⟭⸺⸻", name, cu, cu)#link, iconlink)
        except Exception as e:
              return self.sendMessage(to,"⟬ʀᴇsᴘᴏɴ ᴇʀʀᴏʀ⟭\n"+str(e))

    @loggedIn
    def help(self,to,text):
        creator = 'u17ce7606c05a31e55cfccb35487cfbf3'
        contact = self.getContact(creator)
        try:
            name = '⟬ ʜᴇʟᴘ ᴄᴏᴍᴍᴀɴᴅ ⟭'
            link = 'http://line.me/ti/p/M8k6NlQ_1J'
            icon = ''
            a ="╭⸻⟬ ʜᴇʟᴘ ⟭\n" \
            +"│ᴄᴏᴍᴍᴀɴᴅ ꜰᴏʀ sᴇʟꜰʙᴏᴛ ⵓ\n" \
            +"│  1˳ ʜᴇʟᴘ \n"\
            +"│  2˳ "+wait["setkey"]+" ᴋᴇʏ\n" \
            +"│  3˳ "+wait["setkey"]+" ʀᴇsᴛᴀʀᴛ\n" \
            +"│  4˳ "+wait["setkey"]+" sᴘᴇᴇᴅ\n" \
            +"│  5˳ "+wait["setkey"]+" ʀᴜɴᴛɪᴍᴇ\n" \
            +"│  6˳ "+wait["setkey"]+" ᴀʙᴏᴜᴛ\n" \
            +"│  7˳ "+wait["setkey"]+" ᴍᴇɴᴛɪᴏɴ\n" \
            +"│  8˳ "+wait["setkey"]+" ᴛɪᴍᴇʟɪɴᴇ\n" \
            +"│  9˳ "+wait["setkey"]+" ɢᴇᴛ ᴘʀᴏꜰɪʟ\n" \
            +"│  10˳ "+wait["setkey"]+" ɢᴇᴛ ɢʀᴏᴜᴘ\n" \
            +"│ᴄʀᴇᴀᴛᴏʀ ⵓ " 
            b = "\n╰⸻⟬ ꜰɪɴɪsʜ ⟭⸺"
            self.roman(to, creator,''+a,''+b, name, link, icon)
        except Exception as e:
              return self.sendMessage(to,"⟬ʀᴇsᴘᴏɴ ᴇʀʀᴏʀ⟭\n"+str(e))

    @loggedIn
    def getprofile(self,to,text):
        try:
            name = '⟬ ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ ⟭'
            link = 'http://line.me/ti/p/M8k6NlQ_1J'
            icon = ''
            a ="╭⸻⟬ ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ ⟭\n" \
            +"│ᴄᴏᴍᴍᴀɴᴅ ꜰᴏʀ ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ ⵓ\n" \
            +"│  1˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇᴘᴘ\n"\
            +"│  2˳ "+wait["setkey"]+" ᴄᴇᴋ-ᴘᴘ\n" \
            +"│  3˳ "+wait["setkey"]+" ᴍʏ-ᴘᴘ\n" \
            +"│  4˳ "+wait["setkey"]+" sᴛᴇᴀʟᴘᴘ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"│  5˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇᴄᴏᴠᴇʀ\n" \
            +"│  6˳ "+wait["setkey"]+" ᴄᴇᴋ-ᴄᴏᴠᴇʀ\n" \
            +"│  7˳ "+wait["setkey"]+" ᴍʏ-ᴄᴏᴠᴇʀ\n" \
            +"│  8˳ "+wait["setkey"]+" sᴛᴇᴀʟᴄᴏᴠᴇʀ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"│  9˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇᴠᴘ\n" \
            +"│  10˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇᴠᴘꜰʀᴏᴍ: ⌜ʟɪɴᴋ ʏᴏᴜᴛᴜʙᴇ⌟\n" \
            +"│  11˳ "+wait["setkey"]+" ᴄᴇᴋ-ᴠᴘ\n"\
            +"│  12˳ "+wait["setkey"]+" ᴍʏ-ᴠᴘ\n" \
            +"│  13˳ "+wait["setkey"]+" sᴛᴇᴀʟᴠᴘ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"│  14˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇɴᴀᴍᴇ\n" \
            +"│  15˳ "+wait["setkey"]+" ᴄᴇᴋ-ɴᴀᴍᴇ\n" \
            +"│  16˳ "+wait["setkey"]+" ᴍʏ-ɴᴀᴍᴇ\n" \
            +"│  17˳ "+wait["setkey"]+" sᴛᴇᴀʟɴᴀᴍᴇ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"│  18˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇʙɪᴏ\n" \
            +"│  19˳ "+wait["setkey"]+" ᴄᴇᴋ-ʙɪᴏ\n" \
            +"│  20˳ "+wait["setkey"]+" sᴛᴇᴀʟʙɪᴏ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"╰⸻⟬ ꜰɪɴɪsʜ ⟭⸺"
            self.sendMessageWithContent(to, a, name, link, icon)
        except Exception as e:
              return self.sendMessage(to,"⟬ʀᴇsᴘᴏɴ ᴇʀʀᴏʀ⟭\n"+str(e))
          
    @loggedIn
    def gettimeline(self,to,text):
        try:
            name = '⟬ ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ ⟭'
            link = 'http://line.me/ti/p/M8k6NlQ_1J'
            icon = ''
            a ="╭⸻⟬ ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ ⟭\n" \
            +"│ᴄᴏᴍᴍᴀɴᴅ ꜰᴏʀ ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ ⵓ\n" \
            +"│  1˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇᴘᴘ\n"\
            +"│  2˳ "+wait["setkey"]+" ᴄᴇᴋ-ᴘᴘ\n" \
            +"│  3˳ "+wait["setkey"]+" ᴍʏ-ᴘᴘ\n" \
            +"│  4˳ "+wait["setkey"]+" sᴛᴇᴀʟᴘᴘ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"│  5˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇᴄᴏᴠᴇʀ\n" \
            +"│  6˳ "+wait["setkey"]+" ᴄᴇᴋ-ᴄᴏᴠᴇʀ\n" \
            +"│  7˳ "+wait["setkey"]+" ᴍʏ-ᴄᴏᴠᴇʀ\n" \
            +"│  8˳ "+wait["setkey"]+" sᴛᴇᴀʟᴄᴏᴠᴇʀ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"│  9˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇᴠᴘ\n" \
            +"│  10˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇᴠᴘꜰʀᴏᴍ: ⌜ʟɪɴᴋ ʏᴏᴜᴛᴜʙᴇ⌟\n" \
            +"│  11˳ "+wait["setkey"]+" ᴄᴇᴋ-ᴠᴘ\n"\
            +"│  12˳ "+wait["setkey"]+" ᴍʏ-ᴠᴘ\n" \
            +"│  13˳ "+wait["setkey"]+" sᴛᴇᴀʟᴠᴘ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"│  14˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇɴᴀᴍᴇ\n" \
            +"│  15˳ "+wait["setkey"]+" ᴄᴇᴋ-ɴᴀᴍᴇ\n" \
            +"│  16˳ "+wait["setkey"]+" ᴍʏ-ɴᴀᴍᴇ\n" \
            +"│  17˳ "+wait["setkey"]+" sᴛᴇᴀʟɴᴀᴍᴇ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"│  18˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇʙɪᴏ\n" \
            +"│  19˳ "+wait["setkey"]+" ᴄᴇᴋ-ʙɪᴏ\n" \
            +"│  20˳ "+wait["setkey"]+" sᴛᴇᴀʟʙɪᴏ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"╰⸻⟬ ꜰɪɴɪsʜ ⟭⸺"
            self.sendMessageWithContent(to, a, name, link, icon)
        except Exception as e:
              return self.sendMessage(to,"⟬ʀᴇsᴘᴏɴ ᴇʀʀᴏʀ⟭\n"+str(e))
          
    @loggedIn
    def getgrup(self,to,text):
        try:
            name = '⟬ ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ ⟭'
            link = 'http://line.me/ti/p/M8k6NlQ_1J'
            icon = ''
            a ="╭⸻⟬ ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ ⟭\n" \
            +"│ᴄᴏᴍᴍᴀɴᴅ ꜰᴏʀ ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ ⵓ\n" \
            +"│  1˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇᴘᴘ\n"\
            +"│  2˳ "+wait["setkey"]+" ᴄᴇᴋ-ᴘᴘ\n" \
            +"│  3˳ "+wait["setkey"]+" ᴍʏ-ᴘᴘ\n" \
            +"│  4˳ "+wait["setkey"]+" sᴛᴇᴀʟᴘᴘ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"│  5˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇᴄᴏᴠᴇʀ\n" \
            +"│  6˳ "+wait["setkey"]+" ᴄᴇᴋ-ᴄᴏᴠᴇʀ\n" \
            +"│  7˳ "+wait["setkey"]+" ᴍʏ-ᴄᴏᴠᴇʀ\n" \
            +"│  8˳ "+wait["setkey"]+" sᴛᴇᴀʟᴄᴏᴠᴇʀ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"│  9˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇᴠᴘ\n" \
            +"│  10˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇᴠᴘꜰʀᴏᴍ: ⌜ʟɪɴᴋ ʏᴏᴜᴛᴜʙᴇ⌟\n" \
            +"│  11˳ "+wait["setkey"]+" ᴄᴇᴋ-ᴠᴘ\n"\
            +"│  12˳ "+wait["setkey"]+" ᴍʏ-ᴠᴘ\n" \
            +"│  13˳ "+wait["setkey"]+" sᴛᴇᴀʟᴠᴘ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"│  14˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇɴᴀᴍᴇ\n" \
            +"│  15˳ "+wait["setkey"]+" ᴄᴇᴋ-ɴᴀᴍᴇ\n" \
            +"│  16˳ "+wait["setkey"]+" ᴍʏ-ɴᴀᴍᴇ\n" \
            +"│  17˳ "+wait["setkey"]+" sᴛᴇᴀʟɴᴀᴍᴇ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"│  18˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇʙɪᴏ\n" \
            +"│  19˳ "+wait["setkey"]+" ᴄᴇᴋ-ʙɪᴏ\n" \
            +"│  20˳ "+wait["setkey"]+" sᴛᴇᴀʟʙɪᴏ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"╰⸻⟬ ꜰɪɴɪsʜ ⟭⸺"
            self.sendMessageWithContent(to, a, name, link, icon)
        except Exception as e:
              return self.sendMessage(to,"⟬ʀᴇsᴘᴏɴ ᴇʀʀᴏʀ⟭\n"+str(e))
          
    @loggedIn
    def getmedia(self,to,text):
        try:
            name = '⟬ ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ ⟭'
            link = 'http://line.me/ti/p/M8k6NlQ_1J'
            icon = ''
            a ="╭⸻⟬ ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ ⟭\n" \
            +"│ᴄᴏᴍᴍᴀɴᴅ ꜰᴏʀ ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ ⵓ\n" \
            +"│  1˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇᴘᴘ\n"\
            +"│  2˳ "+wait["setkey"]+" ᴄᴇᴋ-ᴘᴘ\n" \
            +"│  3˳ "+wait["setkey"]+" ᴍʏ-ᴘᴘ\n" \
            +"│  4˳ "+wait["setkey"]+" sᴛᴇᴀʟᴘᴘ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"│  5˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇᴄᴏᴠᴇʀ\n" \
            +"│  6˳ "+wait["setkey"]+" ᴄᴇᴋ-ᴄᴏᴠᴇʀ\n" \
            +"│  7˳ "+wait["setkey"]+" ᴍʏ-ᴄᴏᴠᴇʀ\n" \
            +"│  8˳ "+wait["setkey"]+" sᴛᴇᴀʟᴄᴏᴠᴇʀ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"│  9˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇᴠᴘ\n" \
            +"│  10˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇᴠᴘꜰʀᴏᴍ: ⌜ʟɪɴᴋ ʏᴏᴜᴛᴜʙᴇ⌟\n" \
            +"│  11˳ "+wait["setkey"]+" ᴄᴇᴋ-ᴠᴘ\n"\
            +"│  12˳ "+wait["setkey"]+" ᴍʏ-ᴠᴘ\n" \
            +"│  13˳ "+wait["setkey"]+" sᴛᴇᴀʟᴠᴘ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"│  14˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇɴᴀᴍᴇ\n" \
            +"│  15˳ "+wait["setkey"]+" ᴄᴇᴋ-ɴᴀᴍᴇ\n" \
            +"│  16˳ "+wait["setkey"]+" ᴍʏ-ɴᴀᴍᴇ\n" \
            +"│  17˳ "+wait["setkey"]+" sᴛᴇᴀʟɴᴀᴍᴇ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"│  18˳ "+wait["setkey"]+" ᴄʜᴀɴɢᴇʙɪᴏ\n" \
            +"│  19˳ "+wait["setkey"]+" ᴄᴇᴋ-ʙɪᴏ\n" \
            +"│  20˳ "+wait["setkey"]+" sᴛᴇᴀʟʙɪᴏ: @⌜ᴍᴇɴᴛɪᴏɴ⌟\n" \
            +"╰⸻⟬ ꜰɪɴɪsʜ ⟭⸺"
            self.sendMessageWithContent(to, a, name, link, icon)
        except Exception as e:
              return self.sendMessage(to,"⟬ʀᴇsᴘᴏɴ ᴇʀʀᴏʀ⟭\n"+str(e))
          
    @loggedIn
    def backupData(self):
        with open('public.json', 'w') as fp:
            json.dump(wait, fp, sort_keys=True, indent=4)
          
    @loggedIn
    def backupRead(self):
        with open('publicRead.json', 'w') as fp:
            json.dump(wait2, fp, sort_keys=True, indent=4)
          
    @loggedIn
    def backupMedia(self):
        with open('media.json', 'w') as fp:
            json.dump(media, fp, sort_keys=True, indent=4)
          
    @loggedIn
    def backupAudio(self):
        with open('audio.json', 'w') as fp:
            json.dump(audios, fp, sort_keys=True, indent=4)

    @loggedIn
    def liststicker(self,to,text):
        if wait["Sticker"] == {}:
            self.sendMessage(to, " 「 Sticker List 」\nNo Sticker")
        else:
            num=1
            msgs=" 「 Sticker List 」\nSticker List:"
            for a in wait["Sticker"]:
                msgs+="\n%i. %s" % (num, a)
                num=(num+1)
            msgs+="\n\nTotal Sticker List: %i" % len(wait["Sticker"])
            self.sendMessage(to, msgs)
    def addSticker(self,to,text):
        wait["Sticker"][text] = '%s' % text
        wait["Img"] = '%s' % text
        wait["Addsticker"] = True
        self.backupData()
        self.sendMessage(to, " 「 STICKER 」\nSend the sticker")
        
    def addsticker(self,to,text):
        if wait["Addsticker"] == True:
            try:
                wait["Sticker"][wait["Img"]] = text
                self.sendMessage(to, " 「 STICKER 」\nSTKID: "+text['STKID']+"\nSTKPKGID: "+text['STKPKGID']+"\nSTKVER: "+text['STKVER'])
                self.sendMessage(to,".")
            except Exception as e:
                self.sendMessage(to,"「 Auto Respond 」\n"+str(e))
            wait["Img"] = {}
            wait["Addsticker"] = False
            self.backupData()
            
    def sendtikel(self,to,text):
        try:
            self.sendMessage(to,text=None,contentMetadata=text, contentType=7)
        except:# Exception as e:
            pass#self.sendMessage(to,"「 Auto Respond 」\n"+str(e))
    @loggedIn
    def primbon(self,to):     
        headers = {}
        headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
        page = requests.get("http://www.primbon.com/kecocokan_nama_pasangan.php?nama1=Sriyanto&nama2=Tyass&proses=+Submit%21+",headers = headers)#("https://www.deviantart.com/?q={}".format(text), headers = headers)
        soup = BeautifulSoup(page.content, "html5lib")
        for content in soup.findAll("div",{"id":"container"}):
        #for video in links:
          for dataText in content.findAll("div",{"id":"body"}):
            for delt in dataText.findAll("a"):#("div",{"class":"small"}):#("table", {"class":"linksisip"}):
              delt.decompose()
            for delText in dataText.findAll("b"):#("div",{"class":"small"}):#("table", {"class":"linksisip"}):
              delText.decompose()
            for delText1 in dataText.findAll("br"):#("a",{"href":"kecocokan_nama_pasangan.htm"},{"class":"button"}):#,{"class":"button"}):
              delText1.decompose()
            for delText2 in dataText.findAll("script"):#("div",{"class":"small"}):#("table", {"class":"linksisip"}):
              delText2.decompose()
            for delText3 in dataText.findAll("center"):#("div",{"class":"small"}):#("table", {"class":"linksisip"})
              delText3.decompose()
          text=dataText.text
          hasil=text.replace("\n","")
          self.sendText(to,hasil)
    
    
    @loggedIn
    def LineToday(self,to,text):
        headers = {}
        headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
        page = requests.get("https://today.line.me/ID/pc", headers = headers)
        soup = BeautifulSoup(page.content, "html5lib")
        data = soup.findAll("li", {"class":"swiper-slide"})
        hasil = "--[Line Today]--\n"
        no = 0
        for data in data:
            no += 1
            title = data.a["title"]
            hasil += "\n"+str(no)+"  "+str(title)
        self.sendText(to,hasil)
        
    @loggedIn
    def LineTodayData(self,to,text,first):
        start = time.time()
        headers = {}
        headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
        page = requests.get("https://today.line.me/ID/pc", headers = headers)
        soup = BeautifulSoup(page.content, "html5lib")
        data = soup.findAll("li", {"class":"swiper-slide"})
        elapsed_time = time.time() - start
        try:
            url = data[first - 1]
            link = url.a['href']
            page = requests.get(link, headers = headers)
            soup = BeautifulSoup(page.content, "html5lib")
            for data in soup.findAll("article" ,{"class":"article-content news-content"}):
                head = data.text.replace("\n","")
            #print(berita)
            self.sendText(to,head)
        except Exception as e:
            self.sendMessage(to,"「 Auto Respond 」\n"+str(e))

          
    @loggedIn
    def listpict(self,to,text):
        if wait["Images"] == {}:
            self.sendMessage(to, " 「 Picture List 」\nNo Picture")
        else:
            num=1
            msgs=" 「 Picture List 」\nPicture List:"
            for a in wait["Images"]:
                msgs+="\n%i. %s" % (num, a)
                num=(num+1)
            msgs+="\n\nTotal Picture List: %i" % len(wait["Images"])
            self.sendMessage(to, msgs)
            
    @loggedIn
    def listvideo(self,to,text):
        if wait["Video"] == {}:
            self.sendMessage(to, " 「 VIDEO LIST 」\nNo Video")
        else:
            num=1
            msgs=" 「 VIDEO LIST 」\nVideo List:"
            for a in wait["Video"]:
                msgs+="\n%i. %s" % (num, a)
                num=(num+1)
            msgs+="\n\nTotal Video List: %i" % len(wait["Video"])
            self.sendMessage(to, msgs)
            
            
            
            
    @loggedIn
    def smule1(self,to,text):
        r = requests.get("https://www.smule.com/"+text+"/performances/json")
        data = r.text
        data = json.loads(data)
        if data['list']:
            no = 0
            a = " 「 Music 」\nType: Music List\n\n"
            for music in data['list']:
                no += 1
                a += "\n   " + str(no) + ". " + str(music["title"])
            self.sendMessage(to,a)
            
    @loggedIn
    def smule1data(self,to,text,first):
        start = time.time()
        r = requests.get("https://www.smule.com/"+text+"/performances/json")
        data = r.text
        data = json.loads(data)
        elapsed_time = time.time() - start
        try:
            music = data["list"][first - 1]
            a = " 「 SMULE 」\nType: Detail Record"
            a += "\n  Owner OC: " + str(music['owner']['handle'])
            a += "\n  Title : " + str(music["title"])
            a += "\n  Bio Message : " + str(music["message"])
            a += "\n  created  : " + str(music["created_at"][:10])
            a += "\n  Listen : " + str(music["stats"]["total_listens"])
            a += "\n  Love : " + str(music["stats"]["total_loves"])
            a += "\n  Comment : " + str(music["stats"]["total_comments"])
            image = music['cover_url']
            key = music['key']
            #self.sendImageWithURL(to,image)
            self.sendMessage(to,a)

            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            page = requests.get("http://www.singsmule.net//p/"+key+".html",headers = headers)
            soup = BeautifulSoup(page.content, "html5lib")
            try:
                data = soup.findAll("ul",{"class":"sm2-playlist-bd"})
                for info in data:
                    mp3 = info.a['href']
                self.sendText(to,mp3)
                #self.sendAudioWithURL(to,mp3)
            except:
                hasil = soup.findAll("div",{"class":"embed-responsive embed-responsive-16by9"})
                for video in hasil:
                    mp4 = video.source["src"]
                self.sendText(to,mp4)
                #self.sendVideoWithURL(to,mp4)
        except Exception as e:
 ##         #  print(e)
            return self.sendMessage(to,str(e))#"Sorry BOZ..\nUntuk video belum bisa nampilin.🙏🙏🙏")

        
    @loggedIn
    def smule(self,to,text):
#text = "___Sriyanto_Sk8"
        website = requests.get("https://www.smule.com/"+text)
        data = BeautifulSoup(website.content, "lxml")
        for getInfoSmule in data.findAll("script", {"type":"text/javascript"})[1]:
   # print(getInfoSmule)
            getJsonSmule = re.search(r'DataStore.Pages.Profile\s*=\s*(\{.+\})\s*;', getInfoSmule).group(1)
    #print(getJsonSmule)
            res = json.loads(getJsonSmule)
            for smuleProfile in res:
                ids = res['user']['handle']
                name = res['user']['first_name']+" "+res['user']['last_name']
                status = res['user']['blurb']
                followers = res['user']['followers']
                following = res['user']['followees']
                recording = res['user']['num_performances']
                vip = res['user']['is_vip']
            hasil = ids + name + status + followers + following + recording #+ vip
        self.sendMessage(to,hasil)
        print(ids)
        print(name)
        print(status)
        print(followers)
        print(following)
        print(recording)
        print(vip)

        
    @loggedIn
    def smulee(self,to,text):
        with requests.session() as web:
            web.headers["user-agent"] = random.choice(wait["userAgent"])
            r = web.get("https://ari-api.herokuapp.com/smule?url="+text)
            data = r.text
            data = json.loads(data)
            if data["result"] != {}:
                url = data["result"]["link"]
                lagu = self.downloadFileURL(url)
                judul = data["result"]["title"]
                image = data["result"]["cover"]
                self.sendMessage(to,'JUDUL : '+judul)
                self.sendImageWithURL(to,image)
            if data['result']['type'] == 'video':
                self.sendVideoWithURL(to,url)
            else:
                self.sendAudio(to,lagu)
                
    @loggedIn
    def youtubeMp4(self,to,text):
        with requests.session() as web:
            web.headers["user-agent"] = random.choice(wait["userAgent"])
            r = web.get("http://207.148.109.52:5000/youtube/?apikey=wrk&url="+ text)
            data = r.text
            data = json.loads(data)
            video = data["mp4"]["720p"]
            self.sendVideoWithURL(to, video)
    @loggedIn
    def deviantlist(self,to,text,mid):
        self.sendMessage(to, "Loading Data...")
        big = text.upper()
        r = requests.get("https://www.deviantart.com/oauth2/token?grant_type=client_credentials&client_id=7178&client_secret=d6e59d074e9d6c38e5b7b83f5bfb7c00")
        token = r.text
        token = json.loads(token)
        channel = str(token['access_token'])
        r = requests.get("https://www.deviantart.com/api/v1/oauth2/browse/popular?q="+text+"&timerange=1month&limit=100&mature_content=true&access_token="+channel)
        data = r.text
        data = json.loads(data)
        if data['results'] != []:
            no = 0
            a= " 「 DEVIANT SEARCH "+big+" 」\nType: Search Image"
            for music in data['results']:
                no += 1
                a+= "\n" + str(no) + ". " + music['title']
            b= "Untuk melihat detail,\nKetik %s deviant-image: %s|[nomer]" %(wait["setkey"], str(text))
            self.roman(to,mid,a+"\nHai...",",\n"+b,"「 DEVIANT SEARCH 」",'http://line.me/ti/p/M8k6NlQ_1J','http://goo.gl/iZqff6')
        else:
            self.sendMessage(to,"「 Image 」\nStatus: Error\n" + str(text)+" nothing in image")
            
    @loggedIn
    def deviantdata(self,to,text,first):
        start = time.time()
        r = requests.get("https://www.deviantart.com/oauth2/token?grant_type=client_credentials&client_id=7178&client_secret=d6e59d074e9d6c38e5b7b83f5bfb7c00")
        token = r.text
        token = json.loads(token)
        channel = str(token['access_token'])
        r = requests.get("https://www.deviantart.com/api/v1/oauth2/browse/popular?q="+text+"&timerange=1month&limit=100&mature_content=true&access_token="+channel)
        data = r.text
        data = json.loads(data)
        elapsed_time = time.time() - start
        try:
            music = data['results'][first - 1]
            gtime = music['published_time']
            b = music['url']
            name = '[ CLICK to detail ]'
            icon= 'http://goo.gl/iZqff6'
            try:
                self.sendImageWithURL1(to,music['content']['src'],name,b,icon)
            except:
                self.sendImageWithURL1(to,music['preview']['src'],name,b,icon)
            a=" 「 Image 」\nType: Search Image\nTitle: "+music['title']
            a+="\nCategory: "+music['category']
            a+="\nTotal Favourites: "+str(music['stats']['favourites'])
            a+="\nTotal Comments: "+str(music['stats']['comments'])
            a+="\nCreated at: "+str(timeago.format(gtime))
            self.sendMessageWithContent(to,a,'「 DEVIANT-Image 」',music['preview']['src'],'http://goo.gl/iZqff6')
        except Exception as e:
            self.sendMessage(to,"「 Auto Respond 」\n"+str(e))

    @loggedIn
    def searchimage(self,to,text):
        url = "http://rahandiapi.herokuapp.com/imageapi?key=betakey&q="+text
        with requests.session() as web:
            web.headers["User-Agent"] = random.choice(wait["userAgent"])
            r = web.get(url)
            data = r.text
            data = json.loads(data)
            if data["result"] != []:
                start = time.time()
                items = data["result"]
                path = random.choice(items)
                a = items.index(path)
                b = len(items)
                self.sendMessage(to,"「 Google Image 」\nType : Search Image\nTime taken : %seconds" % (start))
                self.sendImageWithURL(to, str(path))
            else:self.sendMessage(to,"Maaf APInya KOIT")
                
    @loggedIn
    def Image(self, to, text):
        try:
            url = 'https://www.google.com/search?espv=2&biw=1366&bih=667&tbm=isch&oq=kuc&aqs=mobile-gws-lite.0.0l5&q=' + text
            raw_html = (self.download_page(url))
            items = []
            items = items + (self._images_get_all_items(raw_html))
            path = random.choice(items)
            name = '[ GOOGLE IMAGE ]'
            link = path
            icon = 'https://goo.gl/b5Hcsu'
            self.sendImageWithURL1(to,path,name,link,icon)
        except Exception as e:
            self.sendMessage(to,"「 Auto Respond 」\n"+str(e))
            

    @loggedIn
    def wallp(self,to,text,mid):
        try:
            big = text.upper()
            nama = "「 WALLPAPER HD "+big+" 」"
            link = 'http://line.me/ti/p/M8k6NlQ_1J'
            icon = 'http://goo.gl/ir4tjK'
            self.sendMessage(to, "Loading Data...")
            r = requests.get("https://apiz.eater.host/wallp/"+text)
            data = r.text
            data = json.loads(data)
            no=0
            hasil="「 WALLPAPER HD "+big+" 」\n\n"
            for roman in data["result"]:
                no+=1
                hasil+="{}. {}\n".format(str(no), str(roman["judul"]))
                ret_="\nSelanjutnya ketik :\n%s wallpaperhd: %s|[nomor]\nUntuk melihat detail image" %(wait["setkey"], str(text))
            self.roman(to,mid,str(hasil)+'\nHai...',',\n'+ret_,nama,link,icon)
        except Exception as e:
            return self.sendMessage(to,"Type: Search Music"+str(e))
          
    @loggedIn
    def wallpdata(self,to,text,first):
        link = 'http://line.me/ti/p/M8k6NlQ_1J'
        icon = 'http://goo.gl/eJwS5X'
        start = time.time()
        r = requests.get("https://apiz.eater.host/wallp/"+text)
        data = r.text
        data = json.loads(data)
        elapsed_time = time.time() - start
        try:
            gambar = data["result"][first - 1]
            walpp = str(gambar["link"])
            self.sendImageWithURL1(to, walpp,'[WALPAPER HD]',link,icon)
        except Exception as e:
            return self.sendMessage(to,"Type: Search Music"+str(e))

    @loggedIn
    def cooltext(self,to,text):
        try:
            nomer = ["1","2","3","4","5","6","7"]
            pilih = random.choice(nomer)
            url = ("https://farzain.com/api/cooltext.php?text="+text+"&apikey=FtBmmPOJZEfHESe4cqiUEtgTo&type="+pilih)
            self.sendImageWithURL(to, url)
        except Exception as e:
            return self.sendMessage(to,"⟬ʀᴇsᴘᴏɴ ᴇʀʀᴏʀ⟭\n"+str(e))
          
    @loggedIn
    def instagram(self,to,text,cc):
        shield = text.split(" ")
        roman = text.replace(shield[0] + " ","")
        ambrose = roman.split("|")
        seth = str(ambrose[0])
        story = "    [ POST INSTAGRAM ]"
        no = 0
        website = requests.get("https://www.instagram.com/"+seth)
        data = BeautifulSoup(website.content, "lxml")
        if len(ambrose) == 1:
            for getInfoInstagram in data.findAll("script", {"type":"text/javascript"})[3]:
                getJsonInstagram = re.search(r'window._sharedData\s*=\s*(\{.+\})\s*;', getInfoInstagram).group(1)
                data = json.loads(getJsonInstagram)
                hasil = []
                for instagramProfile in data["entry_data"]["ProfilePage"]:
                    username = instagramProfile["graphql"]["user"]["username"]
                    name = instagramProfile["graphql"]["user"]["full_name"]
                    picture = instagramProfile["graphql"]["user"]["profile_pic_url_hd"]
                    biography = instagramProfile["graphql"]["user"]["biography"]
                    followers = instagramProfile["graphql"]["user"]["edge_followed_by"]["count"]
                    following = instagramProfile["graphql"]["user"]["edge_follow"]["count"]
                    private = instagramProfile["graphql"]["user"]["is_private"]
                    ret_ = "╭ㅡㅡㅡㅡㅡㅡㅡ\n│"
                    ret_ += "\n│ ᴜsᴇʀɴᴀᴍᴇ ⵓ "+str(username)
                    ret_ += "\n│ ɴᴀᴍᴇ          ⵓ "+str(name)
                    ret_ += "\n│ ʙɪᴏ             ⵓ "+str(biography)
                    ret_ += "\n│ ꜰᴏʟʟᴏᴡᴇʀs ⵓ "+str(followers)
                    ret_ += "\n│ ꜰᴏʟʟᴏᴡɪɴɢ ⵓ "+str(following)
                    ret_ += "\n│ ᴘʀɪᴠᴀᴛᴇ      ⵓ "+str(private)
                    ret_ += "\n│\n╰⸻⸻⸻"
                name = "❮ɪɢ " + username + "❯"
                link = "https://www.instagram.com/"+seth
                iconlink = 'http://goo.gl/yAz8E6'
                self.flexMessage(to,cc,"INSTAGRAM",name,ret_,str(picture),link,str(picture))

              #  self.sendMessage(to,ret_,contentMetadata = {'AGENT_ICON': iconlink, 'AGENT_NAME': 'Instagram.', 'AGENT_LINK': link})
               # self.sendImageWithURL1(to, str(picture), name , str(picture), iconlink)
                for data in instagramProfile['graphql']['user']['edge_owner_to_timeline_media']['edges']:
                    for dataa in data['node']['edge_media_to_caption']['edges']:
                        text = dataa['node']['text']
                        no += 1
                        story += "\n"+str(no)+". "+str(text)
                self.sendMessage(to,story)

        elif len(ambrose) == 2:
            try:
                first = int(ambrose[1])
                for getInfoInstagram in data.findAll("script", {"type":"text/javascript"})[3]:
                    getJsonInstagram = re.search(r'window._sharedData\s*=\s*(\{.+\})\s*;', getInfoInstagram).group(1)
                    data = json.loads(getJsonInstagram)
                    for instagramProfile in data["entry_data"]["ProfilePage"]:
                        a = instagramProfile['graphql']['user']['edge_owner_to_timeline_media']['edges'][first - 1]
                        pict = a['node']['thumbnail_src']
                    self.sendImageWithURL(to,pict)
            except Exception as e:
                return self.sendMessage(to, "「 Auto Respond 」\n"+str(e))


    @loggedIn
    def snapgram(self,to,text):
        shield = text.split(" ")
        roman = text.replace(shield[0] + " ","")
        ambrose = roman.split("|")
        seth = str(ambrose[0])
        website = requests.get("https://ninja-copy.com/instagram?q="+seth)
        data = BeautifulSoup(website.content, "lxml")
        for getInfoIG in data.findAll("script", {"type":"text/javascript"})[1]:
            getJsonIG = re.search(r'window.__NUXT__\s*=\s*(\{.+\})\s*;', getInfoIG).group(1)
            res = json.loads(getJsonIG)
            if len(ambrose) == 1:
                for story in res['data']:
                    ret_ = "╭ㅡ [INSTAGRAM] ㅡ\n│"
                    ret_ += "\n│ ᴜsᴇʀɴᴀᴍᴇ ⵓ "+ story['currentUser']['username']
                    ret_ += "\n│ ɴᴀᴍᴇ          ⵓ "+story['currentUser']['full_name']
                    ret_ += "\n│ ʙɪᴏ             ⵓ "+story['currentUser']['biography']
                    ret_ += "\n│\n╰⸻[ FINISH ]⸻"
                    image = story['currentUser']['profile_photo']
                self.sendMessage(to,ret_)
                self.sendImageWithURL(to,image)
            elif len(ambrose) == 2:
                try:
                    first = int(ambrose[1])
                    for info in res['data']:
                        story = info['previewPostsArray'][first - 1]
                        image = story['thumbnail']
                    #    video = story['source_url']
                    self.sendImageWithURL(to,image)
                  #  self.sendVideoWithURL(to,video)
                except Exception as e:
                    return self.sendMessage(to, "「 Auto Respond 」\n"+str(e))

    @loggedIn
    def kodewilayah(self,to,mid):
        ret_ = "「 Daftar KODE WILAYAH 」\n\n"
        ret_ += "248 = Alternatif - Cibubur\n119 = Ancol - bandara\n238 = Asia afrika - Bandung\n169 = Asia afrika - Hang lekir"
        ret_ += "\n276 = Asia afrika - Sudirman\n295 = Bandengan - kota\n294 = Bandengan - Selatan\n255 = Boulevard Barat raya"
        ret_ += "\n102 = Buncit raya\n272 = Bundaran - HI\n93 = Cideng barat\n289 = Cikini raya\n242 = Ciledug raya - Cipulir"
        ret_ += "\n175 = Ciloto - Puncak\n142 = Daan mogot - Grogol\n143 = Daan mogot - Pesing\n338 = Dewi sartika - Cawang"
        ret_ += "\n124 = DI Panjaitan - By pass\n123 = DI Panjaitan - Cawang\n13 = Dr Satrio - Casablanca\n105 = Dr Satrio - Karet"
        ret_ += "\n245 = Dukuh atas - MRT Jakarta\n334 = Fachrudin raya\n252 = Fatmawati - Blok A\n253 = Fatmawati - Cipete raya"
        ret_ += "\n203 = Flyover Daan mogot\n336 = Flyover Jati baru\n172 = Flyover Senen - Kramat\n77 = Gunung sahari"
        ret_ += "\n137 = Hasyim Ashari\n273 = Jalan MH Thamrin\n327 = Jalan RS Fatmawati\n292 = Jl. Otista 3\n333 = Jl. Panjang - Kebon jeruk"
        ret_ += "\n226 = JORR - Bintaro\n227 = JORR - Fatmawati\n173 = Kramat raya - Senen\n117 = Kyai Caringin - Cideng\n126 = Letjen Suprapto - Senen"
        ret_ += "\n204 = Mangga besar\n319 = Margaguna raya\n326 = Margonda raya\n310 = Mas Mansyur - Karet\n309 = Mas Mansyur - Tn. Abang"
        ret_ += "\n64 = Matraman\n140 = Matraman - Salemba\n284 = Metro Pdk. Indah\n191 = MT Haryono - Pancoran\n160 = Pancoran barat"
        ret_ += "\n331 = Pejompongan - Slipi\n332 = Pejompongan - Sudirman\n312 = Perempatan pramuka\n171 = Permata hijau - Panjang\n99 = Petojo Harmoni"
        ret_ += "\n223 = Pramuka - Matraman\n222 = Pramuka raya\n314 = Pramuka raya - jl. Tambak\n313 = Pramuka - Salemba raya\n130 = Puncak raya KM84"
        ret_ += "\n318 = Radio dalam raya\n328 = RS Fatmawati - TB\n274 = Senayan city\n132 = Slipi - Palmerah\n133 = Slipi - Tomang"
        ret_ += "\n162 = S Parman - Grogol\n324 = Sudirman - Blok M\n18 = Sudirman - Dukuh atas\n325 = Sudirman - Semanggi\n112 = Sudirman - Setiabudi"
        ret_ += "\n246 = Sudirman - Thamrin\n320 = Sultan agung - Sudirman\n100 = Suryo pranoto\n220 = Tanjung duren\n301 = Tol kebon jeruk"
        ret_ += "\n41 = Tomang/Simpang\n159 = Tugu Pancoran\n145 = Warung jati - Pejaten\n205 = Yos Sudarso - Cawang\n206 = Yos Sudarso - Tj. Priuk"
        res = "Untuk melihat cctv,\nKetik lihat (kode wilayah)"
        nama = '「 KODE WILAYAH 」'
        link = 'http://line.me/ti/p/M8k6NlQ_1J'
        icon = 'http://goo.gl/iZLK4r'
        self.roman(to, mid,''+ret_+'\n\nHai..,','\n'+res,nama,link,icon)

    @loggedIn
    def lewatmana(self,to,text,mid):
        with requests.session() as s:
            s.headers['user-agent'] = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
            r = s.get("http://lewatmana.com/cam/"+text+"/bundaran-hi/")
            soup = BeautifulSoup(r.content, 'html5lib')
            try:
                nama = '「 INFO CCTV 」'
                link = 'http://line.me/ti/p/M8k6NlQ_1J'
                icon = 'http://goo.gl/iZLK4r'
                ret_ = "「 INFO CCTV 」\nDaerah "
                ret_ += soup.select("[class~=cam-viewer-title]")[0].text
                ret_ += "\nCctv update per 5 menit"
                vid = soup.find('source')['src']
                ret = "Untuk melihat wilayah lainnya, Ketik [kode wilayah]"
                self.sendVideoWithURL(to, vid)
                self.roman(to,mid,ret_+"\nHai.., ",ret,nama,link,icon)
            except:
                self.sendMessage(to, "Data cctv tidak ditemukan!")
                
    def lagu123(self,to,text):
        header = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36"}
        website = "http://lagu123.mobi/search.html?q="+text
        data = BeautifulSoup(urllib.request.urlopen(urllib.request.Request(website, headers = header)), "lxml")
        dataLagu = []
        hasil = ' Tes Scrap Music '
        no = 0
        for index in data.findAll("div",{"class":"detail-thumb"}):
            link = "http://lagu123.mobi/"+index.a['href']
            image = index.img['src']
            title = index.img['alt']
            dataLagu.append({"title": title, "url":link,"image":image})
        result = {
        		"code": 200,
        		"result": dataLagu
        	}
        for shield in result['result']:
            no += 1
            hasil += "\n"+str(no)+". "+str(shield["title"])
        self.sendMessage(to,hasil)
    
    def lagu123data(self,to,text,first):
        header = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36"}
        website = "http://lagu123.mobi/search.html?q="+text
        soup = BeautifulSoup(urllib.request.urlopen(urllib.request.Request(website, headers = header)), "lxml")
        data = soup.findAll("div",{"class":"detail-thumb"})
        start = time.time()
        elapsed_time = time.time() - start
        try:
            music = data[first - 1]
            c = music.a['href']
            header = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36"}
            website = "http://lagu123.mobi"+c#/348534710/lagu-nella-kharisma-ninja-opo-vespa-official-music-video-nagaswara-music-online-audio-convertercom.html"
            data = BeautifulSoup(urllib.request.urlopen(urllib.request.Request(website, headers = header)), "lxml")
            dataLagu = []
            creator = "safira"
            for html in data.findAll('div',{'class':'left-bar'}):
            	for info in html.findAll('div',{'class':'bh-info'}):
            		title = info.h2.text
            	for info2 in data.findAll('div',{'class':'bh-audio'}):
            		link = info2.audio.source['src']
            	for info3 in data.findAll('div',{'class':'bh-thumb detail-thumb'}):
            		image = info3.img['src']
            res = {"title": title, "url":website,"img":image,"download":link}
            if res not in dataLagu:
            	dataLagu.append(res)
            shield = {
            		"code": 200,
            		"result": res,
            		"creator": creator
            	}
            print(c)
            self.sendMessage(to,shield['result']['title']+"\n"+shield['result']['url'])
            self.sendImageWithURL(to,shield['result']['img'])
        except Exception as e:
            self.sendMessage(to," "+str(e))
            
    def deviantscrap(self,to,text):
        hasil = " TES SCRAP "
        no = 0
        if " " in text:
            text = text.replace(" ","%20")
        headers = {}
        headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
        page = requests.get("https://www.deviantart.com/?q={}".format(text), headers = headers)
        soup = BeautifulSoup(page.content, "html5lib")
        links = soup.findAll("span",{"class":"thumb wide"})
        dataimage = []
        for link in links:
            title = "Title : "+link.get("data-super-alt")
            no += 1
            hasil += "\n ["+str(no)+"]. "+str(title)
        self.sendMessage(to,hasil)
        
        
    def deviantscrapdata(self,to,text,first):
        if " " in text:
            text = text.replace(" ","%20")
        headers = {}
        headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
        page = requests.get("https://www.deviantart.com/?q={}".format(text), headers = headers)
        soup = BeautifulSoup(page.content, "html5lib")
        links = soup.findAll("span",{"class":"thumb wide"})
        start = time.time()
        elapsed_time = time.time() - start
        try:
            a = links[first - 1]
            c = a.get('href')
            page = requests.get(c,headers = headers)
            soup = BeautifulSoup(page.content, "html5lib")
            links = soup.findAll("a")
            for link in links:
                URL = link.get("href")
                Image = link.get("data-super-img")
                Desc = link.get("title")
                Title = link.get("data-super-alt")
                if URL and Image and Desc and Title:
                    hasil = "Title : {}".format(Title)
                    hasil += "Source : {}".format(URL)
                    hasil += "Image :{}".format(Image)
                    hasil += "Deskripsi : {}".format(Desc)
                    image = '{}'.format(Image)
            self.sendMessage(to,hasil)#+Description+a,"  [Cliks Detail]",URL,icon)
            self.sendImageWithURL1(to,image,'  [ DEVIANT ART ]',"","")
        except Exception as e:
            self.sendMessage(to," "+str(e))

    @loggedIn
    def getapk(self,to,text):
        try:
            with requests.session() as s:
                s.headers['user-agent'] = random.choice(wait["userAgent"])
                r = s.get("https://apkpure.com/id/search?q="+text)
                soup = BeautifulSoup(r.content, 'html5lib')
                data = soup.findAll('dl',attrs={'class':'search-dl'})
                self.sendMessage(to, data)
  #              num = 0
   #             ret_ = "「 Pencarian Aplikasi 」\n"
    #            for apk in data:
     #               num += 1
      #              link = "https://apkpure.com"+apk.find('a')['href']
       #             title = apk.find('a')['title']
        #            ret_ += "\n {}. {}".format(str(num), str(title))
         #       ret_ += "\n\n Total {} Result".format(str(len(data)))
          #      ret = "Selanjutnya ketik:\nGet-apk {} | angka".format(str(text))
           #     self.sendMessage(to, str(ret_))
            #    self.sendMessage(to, str(ret))
             #   self.sendMessage(to, str(link))
        except Exception as e:
            self.sendMessage(to," "+str(e))
            
    @loggedIn
    def getapkdata(self,to,text,first):
        start = time.time()
        elapsed_time = time.time() - start
        with requests.session() as s:
            s.headers['user-agent'] = random.choice(wait["userAgent"])
            r = s.get("https://apkpure.com/id/search?q="+text)#{}".format(str(search)))
            soup = BeautifulSoup(r.content, 'html5lib')
            data = soup.findAll('dl', attrs={'class':'search-dl'})
            try:
                apk = data[first - 1]
                c = apk.find('a')['href']
                print(c)
                with requests.session() as s:
                    s.headers['user-agent'] = random.choice(wait["userAgent"])
                    r = s.get("https://apkpure.com"+c+"/download?from=details")#.format(str(apk.find('a')['href'])))
                    soup = BeautifulSoup(r.content, 'html5lib')
                    data = soup.findAll('div', attrs={'class':'fast-download-box'})
                    for down in data:
                        load = down.select("a[href*=https://download.apkpure.com/]")[0]
                        file = load['href']
                        ret_ = "File info :\n"+down.find('span', attrs={'class':'file'}).text
                        with requests.session() as web:
                            web.headers["user-agent"] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
                            r = web.get("https://api-ssl.bitly.com/v3/shorten?access_token=497e74afd44780116ed281ea35c7317285694bf1&longUrl={}".format(urllib.parse.quote(file)))
                            data = r.text
                            data = json.loads(data)
                            ret_ += "\nLink Download :\n"+data["data"]["url"]
                        self.sendMessage(to, str(ret_))
            except Exception as e:
                self.sendMessage(to," "+str(e))

    @loggedIn
    def porn(self,to,text,mid):
        shield = text.split(" ")
        roman = text.replace(shield[0] + " ","")
        ambrose = roman.split("|")
        seth = str(ambrose[0])
        big = seth.upper()
        link = 'http://line.me/ti/p/M8k6NlQ_1J'
        icon = 'http://goo.gl/tFxVqJ'
        r = requests.get("https://api.avgle.com/v1/search/"+seth+"/1?limit=10")
        data = json.loads(r.text)
        no = 0
        hasil = '「 18+ '+big+' 」\n'
        if len(ambrose) == 1:
            for aa in data["response"]["videos"]:
                no += 1
                hasil += "\n"+str(no)+". "+str(aa["title"])+"\nDurasi : "+str(aa["duration"])
                ret_ = "\nUntuk melihat detail nya,\nKetik %s xxxsearch: %s|[nomer]" %(wait["setkey"], str(text))
            self.roman(to,mid,hasil+"\n\nHai.. ",","+ret_,'「 18+ '+big+' 」',link,icon)
        elif len(ambrose) == 2:
            try:
                first = int(ambrose[1])
                b = data["response"]["videos"][first - 1]
                c = str(b["vid"])
                d = requests.get("https://api.avgle.com/v1/video/"+str(c))
                data1 = json.loads(d.text)
                hasil = "Judul "+str(data1["response"]["video"]["title"])
                hasil += "\n\nDurasi : "+str(data1["response"]["video"]["duration"])
                hasil += "\nKualitas HD : "+str(data1["response"]["video"]["hd"])
                hasil += "\nDitonton "+str(data1["response"]["video"]["viewnumber"])
                hasil += "\nLink video : "+str(data1["response"]["video"]["video_url"])
                hasil += "\nLink embed : "+str(data1["response"]["video"]["embedded_url"])
                hasil += "\n\nKalau tidak bisa jangan lupa pakai vpn kesayangan anda"
                anuanu = str(data1["response"]["video"]["preview_url"])
                path = self.downloadFileURL(anuanu)
                self.sendMessageWithContent(to,hasil,'[ XXX ]',link,icon)
                self.sendImageWithContent(to,path,'[ XXX ]',link,icon)
            except Exception as e:
                self.sendMessage(to," "+str(e))
    @loggedIn
    def wikipedia(self,to,text,mid):
        shield = text.split(" ")
        roman = text.replace(shield[0] + " ","")
        ambrose = roman.split("|")
        seth = str(ambrose[0])
        link = 'http://line.me/ti/p/M8k6NlQ_1J'
        icon = 'http://goo.gl/TzHrJG'
        start = time.time()
        elapsed_time = time.time() - start
        wiki = WikiApi()
        wiki = WikiApi({'locale' : 'id'})
        result = wiki.find(seth)
        if len(ambrose) == 1:
            if result != []:
                no = 0
                a= " 「 Wikipedia 」\nType: Search Wikipedia"
                for music in result:
                    no += 1
                    a+= "\n   " + str(no) + ". " + music
                b = "\nUntuk melihat detail nya,\nKetik %s wikisearch: %s|[nomer]" %(wait["setkey"], str(seth))
                self.roman(to,mid,a+'\n\nHai.. ',','+b,'[ WIKIPEDIA ]',link,icon)
            else:
                return self.sendMessage(to,"Type: Search Wiki"+str(seth)+" not found")
        elif len(ambrose) == 2:
            try:
                first = int(ambrose[1])
                article = wiki.get_article(result[first - 1])
                a = " 「 Wikipedia 」\nType: Search Wiki\nTitle: " + article.heading
                a += "\n\nSummary:\n" + article.summary
                b = article.url
                self.sendMessageWithContent(to,a+'\nTaken: %.10f\nSUKSES' % (elapsed_time/4),'[ Clik to Detail ]',b,icon)
            except Exception as e:
                return self.sendMessage(to,"Type: Search Wiki"+str(e))

    @loggedIn
    def musiclist(self,to,text,mid):
        link = 'http://line.me/ti/p/M8k6NlQ_1J'
        icon = 'http://goo.gl/gFuSv5'
        r = requests.get("http://api.ntcorp.us/joox/search?q="+text)
        data = r.text
        data = json.loads(data)
        if data['result'] != []:
            no = 0
            a = " 「 Music 」\nType: Music List"
            for music in data['result']:
                no += 1
                a += "\n   " + str(no) + ". " + str(music["single"]) + " by " + str(music["artist"])
            b = "\nUntuk melihat detail nya,\nKetik %s music: %s|[nomer]" %(wait["setkey"], str(text))
            return self.roman(to,mid,a+'\n\nHai.. ',','+b,'[ SEARCH MUSIC ]',link,icon)
        else:
            return self.sendMessage(to,"Search "+str(text)+", not found")
    @loggedIn
    def musicdata(self,to,text,first):
        link = 'http://line.me/ti/p/M8k6NlQ_1J'
        icon = 'http://goo.gl/gFuSv5'
        start = time.time()
        r = requests.get("http://api.ntcorp.us/joox/search?q="+text)
        data = r.text
        data = json.loads(data)
        elapsed_time = time.time() - start
        try:
            music = data["result"][first - 1]
            a = " 「 Music 」\nType: Search Music"
            a += "\n  Single : " + str(music["single"])
            a += "\n  Artist : " + str(music["artist"])
            a += "\n  Album  : " + str(music["album"])
            a += "\n  Played : " + str(music["played"])+'\n'
            path = "http://api.ntcorp.us/joox/d/mp3/" + str(music["sid"])
            self.sendMessageWithContent(to,a+'Taken: %.10f\nStatus: SUCCESS' % (elapsed_time/2),'LOADING..... ',link,icon)
            self.sendAudioWithURL(to,path)
        except Exception as e:
            return self.sendMessage(to,"Type: Search Music"+str(e))

    @loggedIn
    def ituneslist(self,to,text, mid):
        link = 'http://line.me/ti/p/M8k6NlQ_1J'
        icon = 'http://goo.gl/mKGqe8'
        start = time.time()
        r = requests.get("https://itunes.apple.com/search?term="+text)
        data = r.text
        data = json.loads(data)
        elapsed_time = time.time() - start
        if data['results'] != []:
            no = 0
            a = " 「 Itunes 」\nType: Music List"
            for music in data['results']:
                no += 1
                a += "\n   " + str(no) + ". " + str(music["trackName"]) + " by " + str(music["artistName"])
            b = "\nUntuk melihat detail nya,\nKetik %s itunespreview: %s|[nomer]" %(wait["setkey"], str(text))
            self.roman(to,mid,a+'\n\nHai.. ',','+b,'  [MUSIC-Itunes]',link,icon)
        else:
            self.sendMessage(to, "Type: Search \nDefinition "+str(text)+" not found")
                        
    @loggedIn         
    def itunesdata(self,to,text,first):
        link = 'http://line.me/ti/p/M8k6NlQ_1J'
        icon = 'http://goo.gl/mKGqe8'
        start = time.time()
        r = requests.get("https://itunes.apple.com/search?term="+text)
        data = r.text
        data = json.loads(data)
        elapsed_time = time.time() - start
        try:
            music = data["results"][first - 1]
            a = " 「 Music 」\nType: Search Music"
            try:
                a += "\n  Single : " + str(music["trackName"])
            except:
                a += "\n  Single : Nothing"
            a += "\n  Artist : " + str(music["artistName"])
            a += "\n  Album  : " + str(music["collectionName"])+'\n'
            path = music['previewUrl']
            path1 = music['artworkUrl100']
            path2 = music['trackViewUrl']
            self.sendImageWithURL1(to,path1,'  Clik to detail',path2,icon)
            self.sendMessageWithContent(to,a+'Taken: %.10f\nStatus : SUCCESS' % (elapsed_time/2),'  LOADING....',link,icon)
            self.sendAudioWithURL(to,path)
        except Exception as e:
            return self.sendMessage(to,"Type: Search Music\n"+str(e))

    @loggedIn
    def stickerline(self,text):
        separate = msg.text.split(" ")
        search = msg.text.replace(separate[0] + " ","")
        cond = search.split("|")
        key = str(cond[0])
        caps = key.upper()
        with requests.session() as web:
            web.headers["User-Agent"] = random.choice(wait["userAgent"])
            r = web.get("https://leert.corrykalam.gq/lstickers.php?search={}".format(urllib.parse.quote(key)))
            data = r.text
            data = json.loads(data)
            no = 0
            hasil ="「 RESULT STICKER "+caps+" 」\n\n"
            if len(cond) == 1:
                for roman in data["items"]:
                    no += 1
                    hasil +="{}. {}\n".format(str(no), str(roman["title"]))
                for ambrose in data["facets"]:
                    hasil +="\nType : "+str(ambrose["type"])
                    hasil +="\nJumlah : "+str(ambrose["count"])
                    ret = "\nselanjutnya ketik,sticker "+key+"|[number]\nUntuk melihat detail nya"
                self.sendMessage(to, str(hasil)+ret)
            elif len(cond) == 2:
                no = int(cond[1])
                if no <= len(data["items"]):
                    gambar = data["items"][no - 1]
                    hsl = "Judul : " +str(gambar["title"])
                    hsl +="\nType : " +str(gambar["type"])
                    hsl +="\nJenis : " +str(gambar["subtype"])
                    hsl +="\nCreator : "+str(gambar["authorName"])
                    hsl +="\nJenis Sticker : "+str(gambar["stickerResourceType"])
                    hsl +="\nURL : https://store.line.me"+str(gambar["productUrl"])
                    hsl +="\nHarga : "+str(gambar["price"])
                    path = str(gambar["listIcon"]["src"])
                self.sendMessage(to,str(hsl))
                self.sendImageWithURL(to,path)

    @loggedIn
    def temaline(self,to,text):
        separate = text.split(" ")
        search = text.replace(separate[0] + " ","")
        cond = search.split("|")
        key = str(cond[0])
        caps = key.upper()
        with requests.session() as web:
            web.headers["User-Agent"] = random.choice(wait["userAgent"])
            r = web.get("http://leert.corrykalam.gq/ltheme.php?search={}".format(urllib.parse.quote(key)))
            data = r.text
            data = json.loads(data)
            no = 0
            hasil ="「 RESULT TEMA "+caps+" 」\n\n"
            if len(cond) == 1:
                for roman in data["items"]:
                    no += 1
                    hasil +="{}. {}\n".format(str(no), str(roman["title"]))
                for ambrose in data["facets"]:
                    hasil +="\nType : "+str(ambrose["type"])
                    hasil +="\nJumlah : "+str(ambrose["count"])
                ret = "\nselanjutnya ketik,tema "+key+"|[number]\nUntuk melihat detail nya"
                self.sendMessage(to, str(hasil)+ret)#+str(ret)+res)
            elif len(cond) == 2:
                no = int(cond[1])
                if no <= len(data["items"]):
                    gambar = data["items"][no - 1]
                    hsl = "Judul : " +str(gambar["title"])
                    hsl +="\nType : " +str(gambar["type"])
                    hsl +="\nJenis : " +str(gambar["subtype"])
                    hsl +="\nCreator : "+str(gambar["authorName"])
                                    #hsl +="\nJenis Sticker : "+str(gambar["stickerResourceType"])
                    hsl +="\nURL : https://store.line.me"+str(gambar["productUrl"])
                    hsl +="\nHarga : "+str(gambar["price"])
                    path = str(gambar["listIcon"]["src"])
                self.sendMessage(to,str(hsl))
                self.sendImageWithURL(to,path)

      
      
    @loggedIn
    def GroupPost(self,to):
        data = self.getGroupPost(to)
        if data['result'] != []:
            try:
                no = 0
                a = "╭────〔 ɢ̲̅ʀ̲̅ᴏ̲̅ᴜ̲̅ᴘ̲̅ 〕────\n│ᴛʏᴘᴇ ⵓ ɢᴇᴛ ɴᴏᴛᴇ ♪˳\n│═════════════════\n"
                for i in data['result']['feeds']:
                    no += 1
                    gtime = i['post']['postInfo']['createdTime']
                    try:
                        c = str(i['post']['userInfo']['nickname'])
                    except:
                        c = "Tidak Diketahui"
                    a +="│  "+ str(no) +"˳ ᴘᴇɴᴜʟɪs ⵓ "+c
                    try:
                        g= str(i['post']['contents']['text'])
                    except:
                        g="None"
                    a +="\n│     ᴅᴇsᴄʀɪᴘᴛɪᴏɴ ⵓ "+g
                    a +="\n│     ᴛᴏᴛᴀʟ ʟɪᴋᴇ ⵓ "+str(i['post']['postInfo']['likeCount'])
                    a +="\n│     ᴄʀᴇᴀᴛᴇᴅ ᴀᴛ ⵓ "+str(timeago.format(datetime.now(),gtime/1000)) + "\n│════════════════════\n"
                a +="│sᴛᴀᴛᴜs ⵓ sᴜᴄᴄᴇs ɢᴇᴛ "+str(data['result']['homeInfo']['postCount'])+" ɴᴏᴛᴇ˳"
                a += "\n│\n│ᴜsᴀɢᴇ ⵓ %s get note num" %(wait["setkey"])
                self.sendMessage(to,a)
            except Exception as e:
                return self.sendMessage(to,"「 Auto Respond 」\n"+str(e))
              
    @loggedIn
    def getGroupPostdetail(self,to,text,first):
        data = self.getGroupPost(to)
        try:
            music = data['result']['feeds'][first - 1]
            try:
                c = str(music['post']['userInfo']['nickname'])
            except:
                c = "Tidak Diketahui"
            a ="\n   Penulis : "+c
            try:
                g= str(music['post']['contents']['text'])
            except:
                g="None"
            a +="\n   Total Like: "+str(music['post']['postInfo']['likeCount'])
            a +="\n   Total Comment: "+str(music['post']['postInfo']['commentCount'])
            gtime = music['post']['postInfo']['createdTime']
            a +="\n   Created at: "+str(timeago.format(datetime.now(),gtime/1000))
            a +="\n\nDescription: "+g
            try:
                for c in music['post']['contents']['media']:
                    params = {'userMid': mid, 'oid': c['objectId']}
                    path = self.server.urlEncode(self.server.LINE_OBS_DOMAIN, '/myhome/h/download.nhn', params)
                self.sendMessage(to," 「 Groups 」\nType: Get Note"+a)
                if c['type'] == 'PHOTO':
                    self.sendImageWithURL(to,path)
                else:
                    pass
                if c['type'] == 'VIDEO':
                    self.sendVideoWithURL(to,path)
                else:
                    pass
            except:
                self.sendMessage(to,"╭────〔 ɢ̲̅ʀ̲̅ᴏ̲̅ᴜ̲̅ᴘ̲̅ 〕────\n│ᴛʏᴘᴇ ⵓ ɢᴇᴛ ɴᴏᴛᴇ ♪˳\n│═════════════════\n"+a)
        except Exception as e:
            return self.sendMessage(to,"「 Auto Respond 」\n"+str(e))
          
    @loggedIn
    def mytimeline(self,to,mid):
        data = self.getHomeProfile(mid)
        if data['result'] != []:
            try:
                no = 0
                a = " 「 Timeline Results 」\nPenulis: "+str(data['result']['homeInfo']['userInfo']['nickname'])
                for i in data['result']['feeds']:
                    no += 1
                    gtime = i['post']['postInfo']['createdTime']
                    try:
                        g= str(i['post']['contents']['text'])
                    except:
                        g="None"
                    a +="\n" + str(no) + ". Status : "+g
                    a +="\nTotal Like: "+str(i['post']['postInfo']['likeCount'])
                    a +="\nTotal Comment: "+str(i['post']['postInfo']['commentCount'])
                    a +="\nCreated at: "+str(timeago.format(datetime.now(),gtime/1000)) + "\n"
                a +="\n\nTotal Status: "+str(data['result']['homeInfo']['postCount'])
                a += "\nType %smy-timeline|「number」" %(wait["setkey"])
                return self.sendMessage(to,a)
            except Exception as e:
                return self.sendMessage(to,"「 Auto Respond 」\n"+str(e))
          
    @loggedIn
    def gettimeline(self,to,mid):
        data = self.getHomeProfile(mid)
        if data['result'] != []:
            try:
                no = 0
                a = " 「 Timeline Results 」\nPenulis: "+str(data['result']['homeInfo']['userInfo']['nickname'])
                for i in data['result']['feeds']:
                    no += 1
                    gtime = i['post']['postInfo']['createdTime']
                    try:
                        g= str(i['post']['contents']['text'])
                    except:
                        g="None"
                    a +="\n" + str(no) + ". Status : "+g
                    a +="\nTotal Like: "+str(i['post']['postInfo']['likeCount'])
                    a +="\nTotal Comment: "+str(i['post']['postInfo']['commentCount'])
                    a +="\nCreated at: "+str(timeago.format(datetime.now(),gtime/1000)) + "\n"
                a +="\n\nTotal Status: "+str(data['result']['homeInfo']['postCount'])
                a += "\nType %sget-timeline 「mention」|「number」" %(wait["setkey"])
                return self.sendMessage(to,a)
            except Exception as e:
                return self.sendMessage(to,"「 Auto Respond 」\n"+str(e))
              

    @loggedIn
    def getTimeLine(self,to,mid,text,first):
        data = self.getHomeProfile(mid)
        try:
            music = data['result']['feeds'][first - 1]
            try:
                h = str(data['result']['homeInfo']['userInfo']['nickname'])
            except:
                h = "Tidak Ketahui"
            a = "│ᴀᴜᴛʜᴏʀ ⵓ "+h
            try:
                g= str(music['post']['contents']['text'])
            except:
                g="None"
            a +="\n│sᴛᴀᴛᴜs ⵓ "+g
            a +="\n│ᴛᴏᴛᴀʟ ʟɪᴋᴇ ⵓ "+str(music['post']['postInfo']['likeCount'])
            a +="\n│ᴛᴏᴛᴀʟ ᴄᴏᴍᴍᴇɴᴛ ⵓ "+str(music['post']['postInfo']['commentCount'])
            gtime = music['post']['postInfo']['createdTime']
            a +="\n│ᴄʀᴇᴀᴛᴇᴅ ᴀᴛ ⵓ "+str(timeago.format(datetime.now(),gtime/1000))
            a +="\n│ʟɪɴᴋ ⵓ line://home/post?userMid="+str(data['result']['homeInfo']['userInfo']['writerMid'])+"&postId="+str(music['post']['postInfo']['postId'])
            try:
                for c in music['post']['contents']['media']:
                    params = {'userMid': mid, 'oid': c['objectId']}
                    path = self.server.urlEncode(self.server.LINE_OBS_DOMAIN, '/myhome/h/download.nhn', params)
                self.sendMessage(to,"╭⸺⟬ɢᴇᴛ ᴛɪᴍᴇʟɪɴᴇ⟭⸺\n│ᴛɪᴍᴇʟɪɴᴇ ʀᴇsᴜʟᴛ ɴᴏ ⵓ "+ str(text)+"\n│\n"+a+"\n╰⸻⸺⟬ꜰɪɴɪsʜ⟭⸺")
                if c['type'] == 'PHOTO':
                    self.sendImageWithURL(to,path)
                else:
                    pass
                if c['type'] == 'VIDEO':
                    self.sendVideoWithURL(to,path)
                else:
                    pass
            except:
                self.sendMessage(to,"╭⸺⟬ɢᴇᴛ ᴛɪᴍᴇʟɪɴᴇ⟭⸺\n│ᴛɪᴍᴇʟɪɴᴇ ʀᴇsᴜʟᴛ ɴᴏ ⵓ "+ str(text)+"\n│\n"+a+"\n╰⸻⸺⟬ꜰɪɴɪsʜ⟭⸺")
        except Exception as e:
            self.sendMessage(to,"「 Auto Respond 」\n"+str(e))

    @loggedIn
    def sendMessageWithContent1(self, to, text, name, link, icon):
        return self.sendMessage(to, text, {'AGENT_NAME': name,'AGENT_LINK': link,'AGENT_ICON': icon})

    @loggedIn
    def google_url_shorten(self, url):
        req_url = 'https://www.googleapis.com/urlshortener/v1/url?key=AIzaSyAzrJV41pMMDFUVPU0wRLtxlbEU-UkHMcI'
        payload = {'longUrl': url}
        headers = {'content-type': 'application/json'}
        r = requests.post(req_url, data=json.dumps(payload), headers=headers)
        resp = json.loads(r.text)
        return resp['id'].replace("https://","")
      
#Template
    @loggedIn
    def template(self,link,data):
        url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
        headers = {'Cookie':'cc={}'.format(str(link))}
        headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 6.0.1; Redmi 3S Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/46.0.2490.76 Mobile Safari/537.36 Line/8.8.3'
        headers['Content-Type'] = 'application/json'
        headers['Accept-Encoding'] = 'gzip, deflate'
        headers['Accept-Language'] = 'id,en-US;q=0.8'
        headers['Connection'] = 'keep-alive'
        return requests.post(url, data=json.dumps(data), headers=headers)

    @loggedIn
    def carousel(self,to,link,link1,link2,arg,arg1,arg2,arg3):
        url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
        to = to
        data ={
          "cc": link,
          "to": to,
          "messages":[
            {
              "type":"template",
              "altText":arg,
              "template":{
                "imageAspectRatio": "square",
                "imageSize": "contain",
                "imageAspectRatio": "square",
                "imageSize": "contain",
                "type":"carousel",
                "columns": [
                  {
                    "thumbnailImageUrl":link1,
                    "title":arg1,
                    "text":arg2,
                    "defaultAction": {
                      "type": "uri",
                      "label": "View detail",
                      "uri": link2
                    },
                    "actions":[
                      {
                        "type": "uri",
                        "label":arg3,
                        "uri": link2
                      },
                      {
                        "type": "uri",
                        "label":arg3,
                        "uri": link2
                      }
                    ]
                  },
                  {
                    "thumbnailImageUrl":link1,
                    "title":arg1,
                    "text":arg2,
                    "defaultAction": {
                      "type": "uri",
                      "label": "View detail",
                      "uri": link2
                    },
                    "actions":[
                      {
                        "type": "uri",
                        "label":arg3,
                        "uri": link2
                      },
                      {
                        "type": "uri",
                        "label":arg3,
                        "uri": link2
                      }
                    ]
                  }
                ]
              }
            }
          ]
        }
        headers = {'Cookie':'cc={}'.format(str(link))}
        headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 6.0.1; Redmi 3S Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/46.0.2490.76 Mobile Safari/537.36 Line/8.8.3'
        headers['Content-Type'] = 'application/json'
        headers['Accept-Encoding'] = 'gzip, deflate'
        headers['Accept-Language'] = 'id,en-US;q=0.8'
        headers['Connection'] = 'keep-alive'
        return requests.post(url, data=json.dumps(data), headers=headers)

    @loggedIn
    def url_shorten(self, to, url):
        req_url = 'https://www.googleapis.com/urlshortener/v1/url?key=AIzaSyAzrJV41pMMDFUVPU0wRLtxlbEU-UkHMcI'
        payload = {'longUrl': url}
        headers = {'content-type': 'application/json'}
        r = requests.post(req_url, data=json.dumps(payload), headers=headers)
        resp = json.loads(r.text)
        return self.sendMessage(to,resp['id'].replace("https://",""))

    @loggedIn
    def download_page(self,url):
        version = (3,0)
        cur_version = sys.version_info
        if cur_version >= version:
            import urllib.request
            try:
                headers = {}
                headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
                req = urllib.request.Request(url, headers = headers)
                resp = urllib.request.urlopen(req)
                respData = str(resp.read())
                return respData
            except Exception as e:
                print(str(e))
                
    @loggedIn
    def _images_get_next_item(self,s):
        start_line = s.find('rg_di')
        if start_line == -1:    
            end_quote = 0
            link = "no_links"
            return link, end_quote
        else:
            start_line = s.find('"class="rg_meta"')
            start_content = s.find('"ou"',start_line+1)
            end_content = s.find(',"ow"',start_content+1)
            content_raw = str(s[start_content+6:end_content-1])
            return content_raw, end_content
          
    @loggedIn
    def _images_get_all_items(self,page):
        items = []
        while True:
            item, end_content = self._images_get_next_item(page)
            if item == "no_links":
                break
            else:
                items.append(item)      
                time.sleep(0.1)        
                page = page[end_content:]
        return items
      
    @loggedIn
    def templatemusic(self,img,text,stext):
        a = self.profile.userid
        contentMetadata={
        'subText': stext,
        'countryCode': 'ID',
        'a-packageName': 'com.spotify.music',
        'previewUrl': img, 'text': text,
        'linkUri': 'line://ti/p/~{}'.format(a),
        'id': 'mt000000000a6b79f9',
        'i-installUrl': 'line://ti/p/~{}'.format(a)
        , 'type': 'mt', 'a-installUrl': 'line://ti/p/~{}'.format(a), 'i-linkUri': 'line://ti/p/~{}'.format(a), 'a-linkUri': 'line://ti/p/~{}'.format(a)}
        return contentMetadata

    @loggedIn
    def myticket(self,to):
        ticket = self.getUserTicket()
        userid = ticket.id
        return self.sendMessage(to,"http://line.me/ti/p/"+str(userid))

    @loggedIn
    def sendSticker(self, to, packageId, stickerId):
        contentMetadata = {
            'STKVER': '100',
            'STKPKGID': packageId,
            'STKID': stickerId
        }
        return self.sendMessage(to, '', contentMetadata, 7)
        
    @loggedIn
    def sendContact(self, to, mid):
        contentMetadata = {'mid': mid}
        return self.sendMessage(to, '', contentMetadata, 13)

    @loggedIn
    def sendGift(self, to, productId, productType):
        if productType not in ['theme','sticker']:
            raise Exception('Invalid productType value')
        contentMetadata = {
            'MSGTPL': str(randint(0, 12)),
            'PRDTYPE': productType.upper(),
            'STKPKGID' if productType == 'sticker' else 'PRDID': productId
        }
        return self.sendMessage(to, '', contentMetadata, 9)

    @loggedIn
    def sendMessageAwaitCommit(self, to, text, contentMetadata={}, contentType=0):
        msg = Message()
        msg.to, msg._from = to, self.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in self._messageReq:
            self._messageReq[to] = -1
        self._messageReq[to] += 1
        return self.talk.sendMessageAwaitCommit(self._messageReq[to], msg)

    @loggedIn
    def flexMessage(self,gid,cc,arg,arg1,result,URLicon,URLklik,URLimage):
        data = {
          "cc":cc,
          "to": gid,
          "messages": [{"type": "flex","altText": arg,"contents":{"type": "bubble",
                "styles": {"footer": {"separatorColor": "#0000FF","separator": True},
                   "body": {"separatorColor": "#0000FF","separator": True}},
                "footer": {"type": "box","layout": "vertical",
                  "contents": [{"type": "box","layout": "vertical",
                      "contents": [{"type": "box","layout": "baseline",
                          "contents": [{"type": "icon","size": "xl","url": URLicon},{
                              "type": "text","size": "md","text": arg1,"color": "#aaaaaa","margin": "xxl","align": "start",
                              "action": {"type": "uri","label": arg1,"uri": URLklik}}]}]}]},
                "body": {"type": "box","layout": "vertical", 
                  "contents": [{"type": "text","text": arg1,"color": "#000080","size": "xl","weight": "bold"},{
                      "type": "text","text": result,"wrap": True,"color": "#000000","size": "xxs"}]},
                "hero": {"type": "image","url": URLimage,"size": "full","aspectMode": "fit"}}}]}
        self.template(cc,data)

      
    @loggedIn
    def unsendMessage(self, messageId):
        self._unsendMessageReq += 1
        return self.talk.unsendMessage(self._unsendMessageReq, messageId)

    @loggedIn
    def requestResendMessage(self, senderMid, messageId):
        return self.talk.requestResendMessage(0, senderMid, messageId)

    @loggedIn
    def respondResendMessage(self, receiverMid, originalMessageId, resendMessage, errorCode):
        return self.talk.respondResendMessage(0, receiverMid, originalMessageId, resendMessage, errorCode)

    @loggedIn
    def removeMessage(self, messageId):
        return self.talk.removeMessage(messageId)
    
    @loggedIn
    def removeAllMessages(self, lastMessageId):
        return self.talk.removeAllMessages(0, lastMessageId)

    @loggedIn
    def removeMessageFromMyHome(self, messageId):
        return self.talk.removeMessageFromMyHome(messageId)

    @loggedIn
    def destroyMessage(self, chatId, messageId):
        return self.talk.destroyMessage(0, chatId, messageId, sessionId)
    
    @loggedIn
    def sendChatChecked(self, consumer, messageId):
        return self.talk.sendChatChecked(0, consumer, messageId)

    @loggedIn
    def sendEvent(self, messageObject):
        return self.talk.sendEvent(0, messageObject)

    @loggedIn
    def getLastReadMessageIds(self, chatId):
        return self.talk.getLastReadMessageIds(0, chatId)

    @loggedIn
    def getPreviousMessagesV2WithReadCount(self, messageBoxId, endMessageId, messagesCount=50):
        return self.talk.getPreviousMessagesV2WithReadCount(messageBoxId, endMessageId, messagesCount)

    """Object"""

    @loggedIn
    def sendImage(self, to, path,icon):
        metadata = {'AGENT_NAME': '⟬ ɪᴍᴀɢᴇ ⟭', 'AGENT_LINK': 'http://line.me/ti/p/M8k6NlQ_1J', 'AGENT_ICON':icon}
        objectId = self.sendMessage(to=to, text=None,contentMetadata=metadata, contentType = 1).id
        return self.uploadObjTalk(path=path, type='image', returnAs='bool', objId=objectId)
    
    @loggedIn
    def sendImageWithContent(self, to, path, name, link, iconlink):
        metadata = {'AGENT_NAME': name, 'AGENT_LINK': link, 'AGENT_ICON': iconlink}
        objectId = self.sendMessage(to=to, text=None, contentMetadata=metadata, contentType=1).id
        return self.uploadObjTalk(path=path, type='image', returnAs='bool', objId=objectId)

    @loggedIn
    def sendImageWithURL1(self, to, url, name, link, iconlink):
        path = self.downloadFileURL(url, 'path')
        return self.sendImageWithContent(to, path, name, link, iconlink)
        return self.deleteFile(path)

    @loggedIn
    def sendImageWithURL(self, to, url):
        path = self.downloadFileURL(url, 'path')
        return self.sendImage(to, path)
        return self.deleteFile(path)
    @loggedIn
    def sendGIF(self, to,path):
        return self.uploadObjTalk(path=path, type='gif', returnAs='bool', to=to)
    
    @loggedIn
    def sendGIFWithURL(self, to, url):
        path = self.downloadFileURL(url, 'path')
        return self.sendGIF(to, path)
        return self.deleteFile(path)

    @loggedIn
    def sendVideo(self, to, path):
        objectId = self.sendMessage(to=to, text=None, contentMetadata={'VIDLEN': '60000','DURATION': '60000'}, contentType = 2).id
        return self.uploadObjTalk(path=path, type='video', returnAs='bool', objId=objectId)

    @loggedIn
    def sendVideoWithURL(self, to, url):
        path = self.downloadFileURL(url, 'path')
        return self.sendVideo(to, path)
        return self.deleteFile(path)

    @loggedIn
    def sendAudio(self, to, path):
        objectId = self.sendMessage(to=to, text=None, contentType = 3).id
        return self.uploadObjTalk(path=path, type='audio', returnAs='bool', objId=objectId)

    @loggedIn
    def sendAudioWithURL(self, to, url):
        path = self.downloadFileURL(url, 'path')
        return self.sendAudio(to, path)
        return self.deleteFile(path)

    @loggedIn
    def sendFile(self, to, path, file_name=''):
        if file_name == '':
            file_name = ntpath.basename(path)
        file_size = len(open(path, 'rb').read())
        objectId = self.sendMessage(to=to, text=None, contentMetadata={'FILE_NAME': str(file_name),'FILE_SIZE': str(file_size)}, contentType = 14).id
        return self.uploadObjTalk(path=path, type='file', returnAs='bool', objId=objectId)

    @loggedIn
    def sendFileWithURL(self, to, url, fileName=''):
        path = self.downloadFileURL(url, 'path')
        return self.sendFile(to, path, fileName)
        return self.deleteFile(path)

    """Contact"""
        
    @loggedIn
    def blockContact(self, mid):
        return self.talk.blockContact(0, mid)

    @loggedIn
    def unblockContact(self, mid):
        return self.talk.unblockContact(0, mid)

    @loggedIn
    def findAndAddContactByMetaTag(self, userid, reference):
        return self.talk.findAndAddContactByMetaTag(0, userid, reference)

    @loggedIn
    def findAndAddContactsByMid(self, mid):
        return self.talk.findAndAddContactsByMid(0, mid, 0, '')

    @loggedIn
    def findAndAddContactsByEmail(self, emails=[]):
        return self.talk.findAndAddContactsByEmail(0, emails)

    @loggedIn
    def findAndAddContactsByUserid(self, userid):
        return self.talk.findAndAddContactsByUserid(0, userid)

    @loggedIn
    def findContactsByUserid(self, userid):
        return self.talk.findContactByUserid(userid)

    @loggedIn
    def findContactByTicket(self, ticketId):
        return self.talk.findContactByUserTicket(ticketId)

    @loggedIn
    def getAllContactIds(self):
        return self.talk.getAllContactIds()

    @loggedIn
    def getBlockedContactIds(self):
        return self.talk.getBlockedContactIds()

    @loggedIn
    def getContact(self, mid):
        return self.talk.getContact(mid)

    @loggedIn
    def getContacts(self, midlist):
        return self.talk.getContacts(midlist)

    @loggedIn
    def getFavoriteMids(self):
        return self.talk.getFavoriteMids()

    @loggedIn
    def getHiddenContactMids(self):
        return self.talk.getHiddenContactMids()

    @loggedIn
    def tryFriendRequest(self, midOrEMid, friendRequestParams, method=1):
        return self.talk.tryFriendRequest(midOrEMid, method, friendRequestParams)

    @loggedIn
    def makeUserAddMyselfAsContact(self, contactOwnerMid):
        return self.talk.makeUserAddMyselfAsContact(contactOwnerMid)

    @loggedIn
    def getContactWithFriendRequestStatus(self, id):
        return self.talk.getContactWithFriendRequestStatus(id)

    @loggedIn
    def reissueUserTicket(self, expirationTime=100, maxUseCount=100):
        return self.talk.reissueUserTicket(expirationTime, maxUseCount)
    
    @loggedIn
    def cloneContactProfile(self, mid):
        contact = self.getContact(mid)
        profile = self.profile
        profile.shieldName = contact.shieldName
        profile.shieldmsgStat = contact.shieldmsgStat
        profile.shieldpictStat = contact.shieldpictStat
        if self.getProfileCoverId(mid) is not None:
            self.updateProfileCoverById(self.getProfileCoverId(mid))
        self.updateProfileAttribute(8, profile.shieldpictStat)
        return self.updateProfile(profile)
    
    @loggedIn
    def clone(self, mid):
        contact = self.getContact(mid)
        profile = self.profile
        profile.shieldmsgStat = contact.shieldmsgStat
        profile.shieldpictStat = contact.shieldpictStat
        return self.updateProfile(profile)

    """Group"""

    @loggedIn
    def getChatRoomAnnouncementsBulk(self, chatRoomMids):
        return self.talk.getChatRoomAnnouncementsBulk(chatRoomMids)

    @loggedIn
    def getChatRoomAnnouncements(self, chatRoomMid):
        return self.talk.getChatRoomAnnouncements(chatRoomMid)

    @loggedIn
    def createChatRoomAnnouncement(self, chatRoomMid, type, contents):
        return self.talk.createChatRoomAnnouncement(0, chatRoomMid, type, contents)

    @loggedIn
    def removeChatRoomAnnouncement(self, chatRoomMid, announcementSeq):
        return self.talk.removeChatRoomAnnouncement(0, chatRoomMid, announcementSeq)

    @loggedIn
    def getGroupWithoutMembers(self, groupId):
        return self.talk.getGroupWithoutMembers(groupId)
    
    @loggedIn
    def findGroupByTicket(self, ticketId):
        return self.talk.findGroupByTicket(ticketId)

    @loggedIn
    def acceptGroupInvitation(self, groupId):
        return self.talk.acceptGroupInvitation(0, groupId)

    @loggedIn
    def acceptGroupInvitationByTicket(self, groupId, ticketId):
        return self.talk.acceptGroupInvitationByTicket(0, groupId, ticketId)

    @loggedIn
    def cancelGroupInvitation(self, groupId, contactIds):
        return self.talk.cancelGroupInvitation(0, groupId, contactIds)

    @loggedIn
    def createGroup(self, name, midlist):
        return self.talk.createGroup(0, name, midlist)

    @loggedIn
    def getGroup(self, groupId):
        return self.talk.getGroup(groupId)

    @loggedIn
    def getGroups(self, groupIds):
        return self.talk.getGroups(groupIds)

    @loggedIn
    def getGroupsV2(self, groupIds):
        return self.talk.getGroupsV2(groupIds)

    @loggedIn
    def getCompactGroup(self, groupId):
        return self.talk.getCompactGroup(groupId)

    @loggedIn
    def getCompactRoom(self, roomId):
        return self.talk.getCompactRoom(roomId)

    @loggedIn
    def getGroupIdsByName(self, groupName):
        gIds = []
        for gId in self.getGroupIdsJoined():
            g = self.getCompactGroup(gId)
            if groupName in g.name:
                gIds.append(gId)
        return gIds

    @loggedIn
    def getGroupIdsInvited(self):
        return self.talk.getGroupIdsInvited()

    @loggedIn
    def getGroupIdsJoined(self):
        return self.talk.getGroupIdsJoined()

    @loggedIn
    def updateGroupPreferenceAttribute(self, groupMid, updatedAttrs):
        return self.talk.updateGroupPreferenceAttribute(0, groupMid, updatedAttrs)

    @loggedIn
    def inviteIntoGroup(self, groupId, midlist):
        return self.talk.inviteIntoGroup(0, groupId, midlist)

    @loggedIn
    def kickoutFromGroup(self, groupId, midlist):
        return self.talk.kickoutFromGroup(0, groupId, midlist)

    @loggedIn
    def leaveGroup(self, groupId):
        return self.talk.leaveGroup(0, groupId)

    @loggedIn
    def rejectGroupInvitation(self, groupId):
        return self.talk.rejectGroupInvitation(0, groupId)

    @loggedIn
    def reissueGroupTicket(self, groupId):
        return self.talk.reissueGroupTicket(groupId)

    @loggedIn
    def updateGroup(self, groupObject):
        return self.talk.updateGroup(0, groupObject)

    """Room"""

    @loggedIn
    def createRoom(self, midlist):
        return self.talk.createRoom(0, midlist)

    @loggedIn
    def getRoom(self, roomId):
        return self.talk.getRoom(roomId)

    @loggedIn
    def inviteIntoRoom(self, roomId, midlist):
        return self.talk.inviteIntoRoom(0, roomId, midlist)

    @loggedIn
    def leaveRoom(self, roomId):
        return self.talk.leaveRoom(0, roomId)

    """Call"""
        
    @loggedIn
    def acquireCallTalkRoute(self, to):
        return self.talk.acquireCallRoute(to)
      
    @loggedIn
    def acquireVideoCallTalkRoute(self, to):
        return self.talk.acquireVideoCallRoute(to)
    
    """Report"""

    @loggedIn
    def reportSpam(self, chatMid, memberMids=[], spammerReasons=[], senderMids=[], spamMessageIds=[], spamMessages=[]):
        return self.talk.reportSpam(chatMid, memberMids, spammerReasons, senderMids, spamMessageIds, spamMessages)
        
    @loggedIn
    def reportSpammer(self, spammerMid, spammerReasons=[], spamMessageIds=[]):
        return self.talk.reportSpammer(spammerMid, spammerReasons, spamMessageIds)