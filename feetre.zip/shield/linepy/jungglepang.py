# -*- coding: utf-8 -*-
from datetime import datetime
from .channel import Channel
import json, time, base64, requests

def loggedIn(func):
    def checkLogin(*args, **kwargs):
        if args[0].isLogin:
            return func(*args, **kwargs)
        else:
            args[0].callback.other('You want to call the function, you must login to LINE')
    return checkLogin
    
class Jungglepang(Channel):

    def __init__(self):
        Channel.__init__(self, self.channel, self.server.CHANNEL_ID['LINE_JUNGGLEPANG'], False)
        self.jpang = self.getChannelResult()
        self.__loginJungglepang()
        
    def __loginJungglepang(self):
        self.setJungglepangHeadersWithDict({
            'Content-Type': 'application/json',
            'User-Agent': self.USER_AGENT,
            'X-Line-Mid': self.profile.mid,
            'X-Line-Carrier': self.CARRIER,
            'X-Line-Application': self.APP_NAME,
            'X-Line-ChannelToken': self.jpang.channelAccessToken
        })
        self.profileDetail = self.getProfileDetail()

