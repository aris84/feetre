# -*- coding: utf-8 -*-
from linepy import *
from datetime import datetime
from time import sleep
from threading import Thread
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
import time, random, sys, json, codecs, glob, re, string, os, requests, subprocess, six, ast, pytz, urllib, urllib.parse, timeago
from gtts import gTTS
from collections import OrderedDict
from googletrans import Translator
from wikiapi import WikiApi


botStart = time.time()

shield = LINE()
#shield = LINE("EvGQl0RmFtTihJt7waa3.f852bSbAmEvC+mS1shZ78W.BWkTaf/FWnJVb2J0V1NkAIS5wgRXtIvGS2bxnFLfwnE=")
#shield = LINE("MGgp")#bee ios
shield.log("Auth Token : " + str(shield.authToken))
shield.log("Timeline Token : " + str(shield.tl.channelAccessToken))
channel = Channel(shield, shield.server.CHANNEL_ID['LINE_JUNGGLEPANG'])
channelToken = channel.getChannelResult()
token = str(shield.authToken)
cc = channelToken.token
print(cc)


#replyer = shield.Simplify(shield,datas=datas)
shieldMID = shield.profile.mid
shieldProfile = shield.getProfile()
lineSettings = shield.getSettings()
oepoll = OEPoll(shield)
master = ['u17ce7606c05a31e55cfccb35487cfbf3']
carousel = "Ami3keOlkrn0MDbJMOa2xEp+x4cuzCN9CXJonMlNsQKtrpoJzn5ICmGCcfeQORlVae3VY5VhTU3pm1zaJl80bOnYHRNxmN0iLB5m5RiIHiy+xL0hxRAsyTC92XWbNPGaLaQ+UUbJVo4wWMUnqYc/HDU74Sdzx8/Mq/K1YbAxunDzUyZCRcGX51bp4MRQ+802l1Dfxw5VMw49uhFkrZc/c++99v/gh7AP+IHKR8qkgctHub3rqMoyDFsCtaHUjyjI+cocNAbyn12Sp6kphX5msZ3bHtJfyvQ9StP7T4v60qaHEsQzyneQm6stAZjLkHb+PP/wEHrX7CT0dIaDB+/Uyw=="
#carousel = "xJYS3PQmVPS8kDeqN0UKKCTErQiL4mIxlDvyd5mCrVU4Zp+t25Hn65MS7lEVzmEf/iWZe4brDR/ybAskfJplqNHxWbDcnW2un95xQS0F/41QhDZRe+fhFFANM4KybgPE5EItpk1wo7vLrF6n80lRz3TILLClqXIjg3zQAj2u2T+MZ4LT8Jdfm+04340A/iFqqjPQUP6/U7F0oXs2VdFIxCJItnoAU/5KXE3HL+pJnv0mN8zHk5+ESzMSImhyGrqc15ZJ68/0/Amwy46C5ugyoqookxI4/Oh+Iu+tjT0VtP3GTYWLDFE7W+VA+z1XghGyFKlvsw0qLIxc4z/Zmy5jnZckDyyLdp7oRuHZOcFVEkY="


with open('1.json', 'r') as fp:
    wait = json.load(fp)
with open('2.json', 'r') as fp:
    wait2 = json.load(fp)
with open('3.json', 'r') as fp:
    prevents = json.load(fp)
with open('media.json', 'r') as fp:
    videos = json.load(fp)
    
read = {
    "readPoint": {},
    "readMember": {},
    "readTime": {},
    "ROM": {}
}

botStart = time.time()
msg_dict = {}
myProfile = {
	"shieldName": "",
	"shieldmsgStat": "",
	"shieldpictStat": ""
}
myProfile["shieldName"] = shieldProfile.shieldName
myProfile["shieldmsgStat"] = shieldProfile.shieldmsgStat
myProfile["shieldpictStat"] = shieldProfile.shieldpictStat

if wait["rebort"] == True:
    shield.sendMessage(wait["restartPoint"], "Bot Diaktifkan Kembali...!!!!")
    wait["rebort"] = False
    wait["restartPoint"] = ""
    with open('1.json', 'w') as fp:
        json.dump(wait, fp, sort_keys=True, indent=4)

try:
    with open("Log_data.json","r",encoding="utf_8_sig") as f:
        msg_dict = json.loads(f.read())
except:
    print("Couldn't read Log data")

def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = shield.genOBSParams({'oid': shieldMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4', 'name': 'Hello_World.mp4'})
        data = {'params': obs_params}
        r_vp = shield.server.postContent('{}/talk/vp/upload.nhn'.format(str(shield.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        shield.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile %s"%str(e))

### KUMPULAN DEF ###
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')
def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)

def restartBot():
    print (">BOTSHIELD SELFBOT TELAH DI RESTART<")
    backupData()
    time.sleep(1)
    python = sys.executable
    os.execl(python, python, *sys.argv)
    
def backupDaata():
    try:
        backup = settings
        f = codecs.open('temp.json','w','utf-8')
        json.dump(backup, f, sort_keys=False, indent=4, ensure_ascii=True)
        backup = prevents
        f = codecs.open('prevent.json','w','utf-8')
        json.dump(backup, f, sort_keys=False, indent=4, ensure_ascii=True)
        backup = read
        f = codecs.open('read.json','w','utf-8')
        json.dump(backup, f, sort_keys=False, indent=4, ensure_ascii=True)
        return False
    except Exception as error:
        logError(error)
        return False
def backupData():
    with open('1.json', 'w') as fp:
        json.dump(wait, fp, sort_keys=True, indent=4)
        
def backupRead():
    with open('2.json', 'w') as fp:
        json.dump(wait2, fp, sort_keys=True, indent=4)
        
def backupLimit():
    with open('3.json', 'w') as fp:
        json.dump(prevents, fp, sort_keys=True, indent=4)

def backupVideo():
    with open('media.json', 'w') as fp:
        json.dump(videos, fp, sort_keys=True, indent=4)

def logError(text):
    shield.log("TERJADI ERROR : " + str(text))
    time_ = datetime.now()
    with open("error.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
    
def command(text):
    pesan = text.lower()
    if wait["setkey"] == True:
        if pesan.startswith(wait["setkey"]):
            cmd = pesan.replace(wait["setkey"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
    

def BotShield(op):
    print("[ {} ] {}".format(str(op.type), OpType._VALUES_TO_NAMES[op.type]))
    try:
        if op.type == 55:
            try:
                if op.param1 in wait2["readPoint"]:
                    wait2['ROM'][op.param1][op.param2] = op.param2
                    wait2['setTime'][op.param1][op.param2] = op.createdTime
                    backupRead()
                else:
                   pass
            except:
                pass
             
        if op.type == 0:
            return
        if op.type == 26 or op.type == 25:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
                if msg.toType == 0:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if msg.contentType == 0:
                    if text is None:
                        return
                    else:
                        text = command(text)
                        if receiver in prevents["temp_flood"]:
                            if prevents["temp_flood"][receiver]["expire"] == True:
                                if text.lower() == "open":
                                    prevents["temp_flood"][receiver]["expire"] = False
                                    prevents["temp_flood"][receiver]["time"] = time.time()
                                    backupLimit()
                                    shield. sendMessage(to,"Bot Active Again 🍁")
                                return
                            elif time.time() - prevents["temp_flood"][receiver]["time"] <= 5:
                                prevents["temp_flood"][receiver]["flood"] += 1
                                if prevents["temp_flood"][receiver]["flood"] >= 15:
                                    prevents["temp_flood"][receiver]["flood"] = 0
                                    prevents["temp_flood"][receiver]["expire"] = True
                                    backupLimit()
                                    ma = shield. getProfile()
                                    text = "Selfbot Silent On 30 seconds 🍁\nFor Activated Use 'Open' Command! 🍁"
                                    name = "==[ Spam Detected ]=="
                                    url = "https://line.me/ti/p/~" + shield.profile.userid
                                    iconlink = 'http://dl.profile.line-cdn.net/{}'.format(str(ma.shieldpictStat))
                                  #  sendMentionV10(msg.to, str(text), str(name), str(url), str(iconlink))
                                    shield. sendMessage(to,text)
                            else:
                                prevents["temp_flood"][receiver]["flood"] = 0
                                prevents["temp_flood"][receiver]["time"] = time.time()
                                backupLimit()
                        else:
                            prevents["temp_flood"][receiver] = {
    	                        "time": time.time(),
    	                        "flood": 0,
    	                        "expire": False
                            }
                            backupLimit()
                if msg.contentType == 0:
                    if msg.text is None:
                        return
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if shield.getProfile().mid in mention["M"]:
                                if to not in wait['ROM']:
                                    wait['ROM'][to] = {}
                                if msg._from not in wait['ROM'][to]:
                                    wait['ROM'][to][msg._from] = {}
                                if 'msg.id' not in wait['ROM'][to][msg._from]:
                                    wait['ROM'][to][msg._from]['msg.id'] = []
                                if 'waktu' not in wait['ROM'][to][msg._from]:
                                    wait['ROM'][to][msg._from]['waktu'] = []
                                wait['ROM'][to][msg._from]['msg.id'].append(msg.id)
                                wait['ROM'][to][msg._from]['waktu'].append(msg.createdTime)
                              #  self.autoresponuy(msg,wait)
                                break

        if op.type == 5:
            if wait["autoAdd"] == True:
                roman = shield.getContact(op.param1)
                shield.findAndAddContactsByMid(roman.mid)
                contact = shield.getContact(master)
                name = '  < AUTO ADD >'
                icon = "http://dl.profile.line-cdn.net/" + contact.shieldpictStat
                shield.roman(op.param1, op.param1,"Hai","\n\n{}".format(str(wait["addMessage"])),name,icon)
                
        if op.type == 13:
            if shieldMID in op.param3:
                if wait["autoJoin"] == True:
                    if wait["limits"]["on"] == True:
                        contact = shield.getContact(master)
                        name = ' <Add My Creator>'
                        icon = "http://dl.profile.line-cdn.net/" + contact.shieldpictStat
                        G = shield.getGroup(op.param1)
                        if len(G.members) <= wait["limits"]["members"]:
                            shield.acceptGroupInvitation(op.param1)
                            shield.sendText(op.param1,"Maaf jumlah member\n " + str(G.shieldName) + " kurang dari " + str(wait["limits"]["members"]))
                            shield.leaveGroup(op.param1)
                        else:
                            shield.acceptGroupInvitation(op.param1)
                            shield.roman(op.param1, op.param2,"hai ","\nterima kasih sudah diinvite...\nKetik < help > untuk menggunakan bot ini..!!",name,icon)
        if op.type == 24:
            if settings["autoLeave"] == True:
                shield.leaveRoom(op.param1)

        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != shield.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
#            if msg.contentType == 7:
 #               sid = msg.contentMetadata['STKID']
  #              data = {
   #               "cc":carousel,"to": to,
    #              "messages": [{"type": "template",
     #               "altText": "Sticker",
      #                "baseSize": {"height": 1040,"width": 1040}, 
       #             "template": {"type": "image_carousel",
        #              "columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/ANDROID/sticker.png".format(sid),
         #               "action": {"type": "uri","uri": "http://line.me/ti/p/M8k6NlQ_1J",
          #                "area": {"x": 520,"y": 0,"width": 520,"height": 1040}
           #             }
#                      }]
 #                   }
  #                }]
   #             }
    #            shield.template(carousel,data)

            if msg.contentType == 16:
                mid = msg._from
                #url = msg.contentMetadata("line://home/post?userMid="+mid+"&postId="+"new_post")
                url = msg.contentMetadata["postEndUrl"]
                shield.suka(url[25:58], url[66:], likeType=1001)
                shield.ngomong(url[25:58], url[66:],wait['comment'])
                shield.roman(to,sender,'Hai kak ','\nSudah aq like ya..!｡^‿^｡','Clik to add (ノ^_^)ノ','http://line.me/ti/p/M8k6NlQ_1J','http://goo.gl/3T9HJg')
            if 'MENTION' in msg.contentMetadata.keys() != None:
                if receiver in wait["shieldDetectMention"]:
                    contact = "u17ce7606c05a31e55cfccb35487cfbf3"
                    mention = eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                        if mention['M'] in master:
                          data ={"cc": carousel,"to": receiver,
                            "messages":[{"type":"template","altText":"MEMEK LOE.!",
                                "template":{"type":"carousel","imageAspectRatio": "square","imageSize": "cover",
                                  "columns": [{"thumbnailImageUrl": "https://obs.line-scdn.net/{}".format(shield.getContact(sender).shieldpictStat),"title":"{}".format(shield.getContact(sender).shieldName),"text":"Jones Loe Tag mulu..!!",
                                      "defaultAction": {"type": "uri","label": "View detail","uri": "https://obs.line-scdn.net/{}".format(shield.getContact(sender).shieldpictStat)},
                                      "actions":[{"type": "uri","label": "Contact Creator","uri": "line://ti/p/~aries_jabrik"},{
                                        "type": "uri","label": "Leave Chat","uri": "line://nv/chat"}]},{
                                      "thumbnailImageUrl": "https://obs.line-scdn.net/{}".format(shield.getContact(contact).shieldpictStat),"title":"{}".format(shield.getContact(contact).shieldName),"text":"This is My Creator.",
                                      "defaultAction": {"type": "uri","label": "View detail","uri": "line://ti/p/~aries_jabrik"},
                                      "actions":[{"type": "uri","label": "My Contact","uri": "line://ti/p/~aries_jabrik"},{
                                          "type": "uri","label": "Chat With My","uri": "line://ti/p/M8k6NlQ_1J"}]}]}},{
                                "type": "template","altText": "Sticker",
                                  "baseSize": {"height": 1040,"width": 1040}, 
                                    "template": {"type": "image_carousel",
                                      "columns": [{"imageUrl": "https://4.bp.blogspot.com/-J0yVohdH6-E/W1kphnE7lzI/AAAAAAALjko/4N5P8rXrao0vZAweSLaN7A42ugUnidS9wCLcBGAs/s1600/AS0004251_13.gif",
                                        "action": {"type": "uri","uri": "http://line.me/ti/p/M8k6NlQ_1J",
                                          "area": {"x": 520,"y": 0,"width": 520,"height": 1040}}}]}}]}      
                          shield.template(carousel,data)

        if op.type == 25:# or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            #sendText = sendMessage
            if msg.toType == 0:
                if sender != shield.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 16:
                mid = msg._from
                #url = msg.contentMetadata("line://home/post?userMid="+mid+"&postId="+"new_post")
                url = msg.contentMetadata["postEndUrl"]
                shield.suka(url[25:58], url[66:], likeType=1001)
                shield.ngomong(url[25:58], url[66:],wait['comment'])
                shield.roman(receiver,sender,'Hai kak ','\nSudah aq like ya..!｡^‿^｡','Clik to add (ノ^_^)ノ','http://line.me/ti/p/M8k6NlQ_1J','http://goo.gl/3T9HJg')

            elif msg.contentType == 7:
                if to in wait["stickerOn"]:
                    stk_id = msg.contentMetadata['STKID']
                    stk_ver = msg.contentMetadata['STKVER']
                    pkg_id = msg.contentMetadata['STKPKGID']
                    with requests.session() as s:
                        s.headers['user-agent'] = 'Mozilla/5.0'
                        r = s.get("https://store.line.me/stickershop/product/{}/id".format(urllib.parse.quote(pkg_id)))
                        soup = BeautifulSoup(r.content, 'html5lib')
                        data = soup.select("[class~=mdBtn01Txt]")[0].text
                        if data == 'Lihat Produk Lain':
                            ret_ = "「 Sticker Info 」"
                            ret_ += "\n• STICKER ID : {}".format(stk_id)
                            ret_ += "\n• STICKER PACKAGES ID : {}".format(pkg_id)
                            ret_ += "\n• STICKER VERSION : {}".format(stk_ver)
                            ret_ += "\n• STICKER URL : line://shop/detail/{}".format(pkg_id)
                            shield.sendMessage(msg.to, str(ret_))
                            query = int(stk_id)
                            if type(query) == int:
                                data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                                path = shield.downloadFileURL(data)
                                shield.sendImage(msg.to,path)
                        else:
                            ret_ = "「 Sticker Info 」"
                            ret_ += "\n• PRICE : "+soup.findAll('p', attrs={'class':'mdCMN08Price'})[0].text
                            ret_ += "\n• AUTHOR : "+soup.select("a[href*=/stickershop/author]")[0].text
                            ret_ += "\n• STICKER ID : {}".format(str(stk_id))
                            ret_ += "\n• STICKER PACKAGES ID : {}".format(str(pkg_id))
                            ret_ += "\n• STICKER VERSION : {}".format(str(stk_ver))
                            ret_ += "\n• STICKER URL : line://shop/detail/{}".format(str(pkg_id))
                            ret_ += "\n• DESCRIPTION :\n"+soup.findAll('p', attrs={'class':'mdCMN08Desc'})[0].text
                            shield.sendMessage(msg.to, str(ret_))
                            query = int(stk_id)
                            if type(query) == int:
                                data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                                path = shield.downloadFileURL(data)
                                shield.sendImage(msg.to,path)

            elif msg.contentType == 7:
                stk_id = msg.contentMetadata['STKID']
                stk_ver = msg.contentMetadata['STKVER']
                pkg_id = msg.contentMetadata['STKPKGID']
                number = str(stk_id) + str(pkg_id)
                if sender not in wait['owner']:
                  if sender in prevents['limit']:
                    if number in prevents['limit'][sender]['stick']:
                        if prevents ['limit'][sender]['stick'][number] >= 3:
                            prevents ['limit'][sender]['stick']['react'] = False
                            shield.sendMessage(to,'[ Detect Spam Sticker ]')
                        else:
                            prevents ['limit'][sender]['stick'][number] += 1
                            prevents ['limit'][sender]['stick']['react'] = True
                    else:
                        try:
                            del prevents['limit'][sender]['stick']
                        except:
                            pass
                        prevents['limit'][sender]['stick'] = {}
                        prevents['limit'][sender]['stick'][number] = 1
                        prevents['limit'][sender]['stick']['react'] = True
                else:
                    prevents['limit'][sender] = {}
                    prevents['limit'][sender]['stick'] = {}
                    prevents['limit'][sender]['text'] = {}
                    prevents['limit'][sender]['stick'][number] = 1
                    prevents['limit'][sender]['stick']['react'] = True
                    backupLimit()
                if prevents['limit'][sender]['stick']['react'] == False:
                    return

                text = msg.contentMetadata
                shield.addsticker(to,text)
            if msg.contentType == 2:
                if sender in wait["owner"]:
                    contact = shield.getProfile()
                    pict = 'http://dl.profile.line-cdn.net/'+ contact.shieldpictStat
                    path = shield.downloadFileURL(pict)
                    if wait["ChangeVP"] == True:
                        path1 = shield.downloadObjectMsg(msg_id)
                        wait["ChangeVP"] =False
                        changeVideoAndPictureProfile(path, path1)
                        shield.sendMessage(to, "╭⸻⟬ ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ ⟭⸻\n│ᴛʏᴘᴇ ⵓ ᴄʜᴀɴɢᴇᴅ ᴠɪᴅᴇᴏ ᴘʀᴏꜰɪʟᴇ ♪˳\n│sᴛᴀᴛᴜs ⵓ sᴜᴄᴄᴇss\n╰⸻ㅡ⟬ ꜰɪɴɪsʜ ⟭⸻")

            if msg.contentType == 1:
                if sender in wait["owner"]:
                    if wait["ChangePP"] == True:
                        path = shield.downloadObjectMsg(msg_id)
                        wait["ChangePP"] = False
                        shield.updateProfilePicture(path)
                        shield.sendMessage(to, "╭⸻⟬ ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ ⟭⸻\n│ᴛʏᴘᴇ ⵓ ᴄʜᴀɴɢᴇᴅ ɪᴍᴀɢᴇᴅ ᴘʀᴏꜰɪʟᴇ ♪˳\n│sᴛᴀᴛᴜs ⵓ sᴜᴄᴄᴇss\n╰⸻ㅡ⟬ ꜰɪɴɪsʜ ⟭⸻")

                if wait["Addimage"] == True:
                    try:
                        shield.downloadObjectMsg(msg_id,'path','dataSeen/%s.jpg' % wait["Img"])
                        shield.sendMessage(to, " 「 IMAGE 」\nType: Add Picture\nStatus: Success Add Picture♪")
                    except Exception as e:
                        shield.sendMessage(to,"「 Auto Respond 」\n"+str(e))
                    wait["Img"] = {}
                    wait["Addimage"] = False
                    backupData()
            if msg.contentType == 2:
                if wait["Addvideoo"]["status"] == True:
                    path = shield.downloadObjectMsg(msg.id)
                    videos[wait["Addvideoo"]["name"]] = str(path)
                    backupVideo()
                    shield.sendMessage(msg.to, "Berhasil menambahkan video {}".format(str(wait["Addvideoo"]["name"])))
                    wait["Addvideoo"]["status"] = False                
                    wait["Addvideoo"]["name"] = ""
                    backupData()
                    
                                                        
            if msg.contentType == 0:
                if text is None:
                    return
                if sender in wait['creator']:
                    for video in videos:
                       if text.lower() == video:
                          shield.sendVideo(msg.to, videos[video])
                          
                    if text.lower() == "/tes":
                        contentMetadata = {'ALT_TEXT': 'Pler :v', 
                                'BOT_CHECK': '1',
                                'BACKGROUND_COLOR': 'FFFFFFFF',
                                'USE_FULL_WIDTH': 'False',
                                'WIDTH_DIP': '260',
                                'USE_HORIZONTAL_SCROLL': 'false',
                                'HTML_CONTENT': '<!DOCTYPE html>\n<html>\n<head>',
                                'USE_ROUND_CORNER': 'true'
                        }
                        shield.sendMessage(to, 'test', contentMetadata, 4)

                    if text.lower() == "changepp":
                        wait["ChangePP"] = True
                        shield.sendMessage(to, "〃ᴘʟᴇᴀsᴇ sᴇɴᴅ ɪᴍᴀɢᴇ ♪〃˳")

                    elif text.lower() == "changecover":
                        wait["ChangeCV"] = True
                        shield.sendMessage(to, "〃ᴘʟᴇᴀsᴇ sᴇɴᴅ ɪᴍᴀɢᴇ ♪〃˳")

                    elif text.lower() == "changevp":
                        wait["ChangeVP"] = True
                        shield.sendMessage(to, "〃ᴘʟᴇᴀsᴇ sᴇɴᴅ ᴠɪᴅᴇᴏ ♪〃˳")

                    elif msg.text.lower().startswith("changevpfrom: "):
                        sep = msg.text.split(" ")
                        query = text.replace(sep[0] + " ","")
                        with requests.session() as web:
                            web.headers["user-agent"] = random.choice(wait["userAgent"])
                            r = web.get("http://leert.corrykalam.gq/yt.php?url={}".format(urllib.parse.quote(query)))
                            data = r.text
                            data = json.loads(data)
                            video = data["mp4"]["360"]
                        contact = shield.getProfile()
                        picture = "http://dl.profile.line-cdn.net/"+contact.shieldpictStat
                        path = shield.downloadFileURL(picture)
                        path1 = shield.downloadFileURL(video)
                        changeVideoAndPictureProfile(path, path1)
                        shield.sendMessage(msg.to, "╭⸻⟬ ɢᴇᴛ ᴘʀᴏꜰɪʟᴇ ⟭⸻\n│ᴛʏᴘᴇ ⵓ ᴄʜᴀɴɢᴇᴅ ᴠɪᴅᴇᴏ ᴘʀᴏꜰɪʟᴇ ♪˳\n│sᴛᴀᴛᴜs ⵓ sᴜᴄᴄᴇss\n╰⸻ㅡ⟬ ꜰɪɴɪsʜ ⟭⸻")
                    elif text.lower() == 'sp':
                        start = time.time()
                        shield.sendMessage(to, "processing......")
                        elapsed_time = time.time() - start
                        shield.sendMessage(to,format(str(elapsed_time)) + "second")    
                    elif text.lower() == "/cekmention":cekmention(to,wait)
                    elif text.lower() == 'key':mykey(shield,receiver)
                    elif text.lower() == 'key off':mykeyoff(shield,receiver)
                    elif text.lower() == 'key reset':mykeyreset(shield,receiver)
                    elif text.lower().startswith('key:'):keyset(shield,receiver,text)
                    elif text.lower() == wait["setkey"]+' list sticker' or text.lower() == wait["setkey"]+'list sticker':shield.liststicker(to,'')
                    elif text.lower() == wait["setkey"]+' list pict' or text.lower() == wait["setkey"]+'list pict':shield.listpict(to,'')
                    elif text.lower() == '.':restart_program()
                    elif text.lower() == wait["setkey"]+'gcreator' or text.lower() == wait["setkey"]+' gcreator':shield.gcreator(receiver)
                    elif text.lower() == wait["setkey"]+' stickeron' or text.lower() == wait["setkey"]+'stickeron':stickeron(receiver,"")
                    elif text.lower() == wait["setkey"]+' stickeroff' or text.lower() == wait["setkey"]+'stickeroff':stickeroff(receiver,"")
                    elif text.lower() == wait["setkey"]+' tes' or text.lower() == wait["setkey"]+'tes':mute(receiver,"")
                    elif text.lower() == wait["setkey"]+' tesoff' or text.lower() == wait["setkey"]+'tesoff':unmute(receiver,"")
                    elif text.lower() == wait["setkey"]+'info-group':shield.infogroup(receiver)
                    elif text.lower() == wait["setkey"]+'list-member':shield.listmember(receiver)
                    elif text.lower() == 'help':shield.help(receiver,'')
                    elif text.lower() == wait["setkey"]+'get profile':shield.getprofile(receiver,'')
                    elif text.lower() == wait["setkey"]+'primbon':shield.primbon(receiver)
                    elif text.lower() == wait["setkey"]+'speed':shield.speed(receiver,'')
                    elif text.lower() == wait["setkey"]+'myticket':shield.myticket(receiver)
                    elif text.lower() == wait["setkey"]+'list-group':shield.listgroup(receiver,'')
                    elif text.lower() == wait["setkey"]+'cekmid':shield.sendMessage(receiver,"[MID]\n" +  shieldMID)
                    elif text.lower() == wait["setkey"]+'cek-name':shield.name(receiver,shieldMID)
                    elif text.lower() == wait["setkey"]+'cek-mid':shield.sendMessage(receiver, shieldMID)
                    elif text.lower() == wait["setkey"]+'cek-bio':shield.bio(receiver,shieldMID)
                    elif text.lower() == wait["setkey"]+'cek-pp':shield.pp(receiver, shieldMID)
                    elif text.lower() == wait["setkey"]+'cek-vp':shield.vp(receiver, shieldMID)
                    elif text.lower() == wait["setkey"]+'cek-cover':shield.cover(receiver, shieldMID)
                    elif text.lower() == wait["setkey"]+'my-pp':shield.pp(receiver, sender)
                    elif text.lower() == wait["setkey"]+'my-mid':shield.sendMessage(receiver, sender)
                    elif text.lower() == wait["setkey"]+'my-name':shield.name(receiver, sender)
                    elif text.lower() == wait["setkey"]+'my-bio':shield.bio(receiver, sender)
                    elif text.lower() == wait["setkey"]+'my-cover':shield.cover(receiver, sender)
                    elif text.lower() == wait["setkey"]+'pict-group':shield.pg(receiver, receiver)
                    elif text.lower() == wait["setkey"]+'my-vp':shield.vp(receiver, sender)
                                        
                    elif text.lower() == 'tes template':
                        link = "Ami3keOlkrn0MDbJMOa2xEp+x4cuzCN9CXJonMlNsQKtrpoJzn5ICmGCcfeQORlVae3VY5VhTU3pm1zaJl80bOnYHRNxmN0iLB5m5RiIHiy+xL0hxRAsyTC92XWbNPGaLaQ+UUbJVo4wWMUnqYc/HDU74Sdzx8/Mq/K1YbAxunDzUyZCRcGX51bp4MRQ+802l1Dfxw5VMw49uhFkrZc/c++99v/gh7AP+IHKR8qkgctHub3rqMoyDFsCtaHUjyjI+cocNAbyn12Sp6kphX5msZ3bHtJfyvQ9StP7T4v60qaHEsQzyneQm6stAZjLkHb+PP/wEHrX7CT0dIaDB+/Uyw=="
                        link1 = "https://obs.line-scdn.net/0hGgGOiV7zGEh6NjV5Au9nH3F1FCRJXgNIWAgLfgliR3hfU1wYTldea14_TntfVFlK"
                        link2 = "line://ti/p/~aries-jabrix"
                        shield.template(msg.to,link,link1,link2,"[TES]","tes","jabrix tes template","baru tes")

                    elif text.lower() == 'tes magic':
                        url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                        to = msg.to
                        data ={
                          "cc": "Ami3keOlkrn0MDbJMOa2xEp+x4cuzCN9CXJonMlNsQKtrpoJzn5ICmGCcfeQORlVae3VY5VhTU3pm1zaJl80bOnYHRNxmN0iLB5m5RiIHiy+xL0hxRAsyTC92XWbNPGaLaQ+UUbJVo4wWMUnqYc/HDU74Sdzx8/Mq/K1YbAxunDzUyZCRcGX51bp4MRQ+802l1Dfxw5VMw49uhFkrZc/c++99v/gh7AP+IHKR8qkgctHub3rqMoyDFsCtaHUjyjI+cocNAbyn12Sp6kphX5msZ3bHtJfyvQ9StP7T4v60qaHEsQzyneQm6stAZjLkHb+PP/wEHrX7CT0dIaDB+/Uyw==",
                          "to": to,
                          "messages":[
                            {
                              "type":"template",
                              "altText": "BUKA WOY",
                              "template":{
                                "type": "buttons",
                                "thumbnailImageUrl":"https://obs.line-scdn.net/0hGgGOiV7zGEh6NjV5Au9nH3F1FCRJXgNIWAgLfgliR3hfU1wYTldea14_TntfVFlK",
                                "title":"TES DULU",
                                "text":"ini percobaan",
                                "actions":[
                                  {
                                    "type": "uri",
                                    "label": "tes",
                                    "uri": "line://ti/p/~aries"
                                  }
                                ]
                              }
                            }
                          ]
                        } 
                        headers = {'Cookie':'cc=Ami3keOlkrn0MDbJMOa2xEp+x4cuzCN9CXJonMlNsQKtrpoJzn5ICmGCcfeQORlVae3VY5VhTU3pm1zaJl80bOnYHRNxmN0iLB5m5RiIHiy+xL0hxRAsyTC92XWbNPGaLaQ+UUbJVo4wWMUnqYc/HDU74Sdzx8/Mq/K1YbAxunDzUyZCRcGX51bp4MRQ+802l1Dfxw5VMw49uhFkrZc/c++99v/gh7AP+IHKR8qkgctHub3rqMoyDFsCtaHUjyjI+cocNAbyn12Sp6kphX5msZ3bHtJfyvQ9StP7T4v60qaHEsQzyneQm6stAZjLkHb+PP/wEHrX7CT0dIaDB+/Uyw'}
                        headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 6.0.1; Redmi 3S Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/46.0.2490.76 Mobile Safari/537.36 Line/8.8.3'
                        headers['Content-Type'] = 'application/json'
                        headers['Accept-Encoding'] = 'gzip, deflate'
                        headers['Accept-Language'] = 'id,en-US;q=0.8'
                        headers['Connection'] = 'keep-alive'
                        return requests.post(url, data=json.dumps(data), headers=headers)
                        
                                
                                
                    elif text.lower() == 'tes carousel':
                        url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                      #  url = "https://api.line.me/v2/bot/message/push"
                        to = msg.to
                        data ={
                          "cc": "Ami3keOlkrn0MDbJMOa2xEp+x4cuzCN9CXJonMlNsQKtrpoJzn5ICmGCcfeQORlVae3VY5VhTU3pm1zaJl80bOnYHRNxmN0iLB5m5RiIHiy+xL0hxRAsyTC92XWbNPGaLaQ+UUbJVo4wWMUnqYc/HDU74Sdzx8/Mq/K1YbAxunDzUyZCRcGX51bp4MRQ+802l1Dfxw5VMw49uhFkrZc/c++99v/gh7AP+IHKR8qkgctHub3rqMoyDFsCtaHUjyjI+cocNAbyn12Sp6kphX5msZ3bHtJfyvQ9StP7T4v60qaHEsQzyneQm6stAZjLkHb+PP/wEHrX7CT0dIaDB+/Uyw",
                          "to": to,
                          "messages":[
                            {
                              "type":"template",
                              "altText":"[TES..!!!]",
                              "template":{
                                "type":"carousel",
                                "imageAspectRatio": "square",
                                "imageSize": "cover",
                                "columns": [
                                  {
                                    "thumbnailImageUrl":"https://obs.line-scdn.net/{}".format(shield.getContact(shieldMID).shieldpictStat),
                                    "title":"{}".format(shield.getProfile().shieldName),
                                    "text":"tes",
                                    "defaultAction": {
                                      "type": "uri",
                                      "label": "View detail",
                                      "uri": "line://ti/p/~aries-jabrix"
                                    },
                                    "actions":[
                                      {
                                        "type":"message",
                                        "label":"Yes",
                                        "text":"Yes"
                                      },
                                      {
                                        "type": "uri",
                                        "label": "tes",
                                        "uri": "line://ti/p/~aries"
                                      }
                                    ]
                                  },
                                  {
                                    "thumbnailImageUrl":"https://obs.line-scdn.net/0hGgGOiV7zGEh6NjV5Au9nH3F1FCRJXgNIWAgLfgliR3hfU1wYTldea14_TntfVFlK",
                                    "title":"{}".format(shield.getProfile().shieldName),
                                    "text":"jabrix tes template",
                                    "defaultAction": {
                                      "type": "uri",
                                      "label": "View detail",
                                      "uri": "line://ti/p/~aries-jabrix"
                                    },
                                    "actions":[
                                      {
                                        "type": "uri",
                                        "label": "baru tes",
                                        "uri": "line://ti/p/~aries-jabrix"
                                      },
                                      {
                                        "type": "uri",
                                        "label": "tes",
                                        "uri": "line://ti/p/~aries"
                                      }
                                    ]
                                  }
                                ]
                              }
                            }
                          ]
                        }
                        headers = {'Cookie':'cc=Ami3keOlkrn0MDbJMOa2xEp+x4cuzCN9CXJonMlNsQKtrpoJzn5ICmGCcfeQORlVae3VY5VhTU3pm1zaJl80bOnYHRNxmN0iLB5m5RiIHiy+xL0hxRAsyTC92XWbNPGaLaQ+UUbJVo4wWMUnqYc/HDU74Sdzx8/Mq/K1YbAxunDzUyZCRcGX51bp4MRQ+802l1Dfxw5VMw49uhFkrZc/c++99v/gh7AP+IHKR8qkgctHub3rqMoyDFsCtaHUjyjI+cocNAbyn12Sp6kphX5msZ3bHtJfyvQ9StP7T4v60qaHEsQzyneQm6stAZjLkHb+PP/wEHrX7CT0dIaDB+/Uyw'}
                        headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 6.0.1; Redmi 3S Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/46.0.2490.76 Mobile Safari/537.36 Line/8.8.3'
                        headers['Content-Type'] = 'application/json'
                        headers['Accept-Encoding'] = 'gzip, deflate'
                        headers['Accept-Language'] = 'id,en-US;q=0.8'
                        headers['Connection'] = 'keep-alive'
                        return requests.post(url, data=json.dumps(data), headers=headers)
                        
                    elif text.lower() == 'tes help':
                        url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                        to = msg.to
                        data ={
                          "cc": "Ami3keOlkrn0MDbJMOa2xEp+x4cuzCN9CXJonMlNsQKtrpoJzn5ICmGCcfeQORlVae3VY5VhTU3pm1zaJl80bOnYHRNxmN0iLB5m5RiIHiy+xL0hxRAsyTC92XWbNPGaLaQ+UUbJVo4wWMUnqYc/HDU74Sdzx8/Mq/K1YbAxunDzUyZCRcGX51bp4MRQ+802l1Dfxw5VMw49uhFkrZc/c++99v/gh7AP+IHKR8qkgctHub3rqMoyDFsCtaHUjyjI+cocNAbyn12Sp6kphX5msZ3bHtJfyvQ9StP7T4v60qaHEsQzyneQm6stAZjLkHb+PP/wEHrX7CT0dIaDB+/Uyw",
                          "to": to,
                          "messages":[
                            {
                              "type": "flex",
                              "altText": "HELP MESSAGE",
                              "contents": {
                                "type": "bubble",
                                "header": {
                                  "type": "box",
                                  "layout": "vertical",
                                  "contents": [
                                    {
                                      "type": "text",
                                      "text": "Help Message",
                                      "size": "xl",
                                      "weight": "bold",
                                      "color": "#FF0013"
                                    }
                                  ]
                                },
                                "body": {
                                  "type": "box",
                                  "layout": "vertical",
                                  "contents": [
                                    {
                                      "type": "text",
                                      "text": "⟬ ʜᴇʟᴘ ⟭",
                                      "size": "md",
                                      "align": "center",
                                      "color": "#0014E8"
                                    },
                                    {
                                      "type": "text",
                                      "text": "╭ᴄᴏᴍᴍᴀɴᴅ ꜰᴏʀ sᴇʟꜰʙᴏᴛ",
                                    },
                                    {
                                      "type": "text",
                                      "text": "│  1˳ ʜᴇʟᴘ",
                                    },
                                    {
                                      "type": "text",
                                      "text": "│  2˳ "+wait["setkey"]+" ᴋᴇʏ",
                                    },
                                    {
                                      "type": "text",
                                      "text": "│  3˳ "+wait["setkey"]+" ʀᴇsᴛᴀʀᴛ",
                                    },
                                    {
                                      "type": "text",
                                      "text": "│  4˳ "+wait["setkey"]+" sᴘᴇᴇᴅ",
                                    },
                                    {
                                      "type": "text",
                                      "text": "╰⸻⟬ ꜰɪɴɪsʜ ⟭⸺",
                                    }
                                  ]
                                },
                                "footer": {
                                 "type": "box",
                                  "layout": "vertical",
                                  "contents": [
                                    {
                                      "type": "spacer",
                                      "size": "xl"
                                    },
                                    {
                                      "type": "button",
                                      "action": {
                                        "type": "uri",
                                        "label": "Chat With Creator",
                                        "uri": "http://line.me/ti/p/M8k6NlQ_1J"
                                      },
                                      "style": "primary",
                                      "color": "#00FF0D"
                                    }
                                  ]
                                }
                              }
                            }
                          ]
                        }
                        headers = {'Cookie':'cc=Ami3keOlkrn0MDbJMOa2xEp+x4cuzCN9CXJonMlNsQKtrpoJzn5ICmGCcfeQORlVae3VY5VhTU3pm1zaJl80bOnYHRNxmN0iLB5m5RiIHiy+xL0hxRAsyTC92XWbNPGaLaQ+UUbJVo4wWMUnqYc/HDU74Sdzx8/Mq/K1YbAxunDzUyZCRcGX51bp4MRQ+802l1Dfxw5VMw49uhFkrZc/c++99v/gh7AP+IHKR8qkgctHub3rqMoyDFsCtaHUjyjI+cocNAbyn12Sp6kphX5msZ3bHtJfyvQ9StP7T4v60qaHEsQzyneQm6stAZjLkHb+PP/wEHrX7CT0dIaDB+/Uyw'}
                        headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 6.0.1; Redmi 3S Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/46.0.2490.76 Mobile Safari/537.36 Line/8.8.3'
                        headers['Content-Type'] = 'application/json'
                        headers['Accept-Encoding'] = 'gzip, deflate'
                        headers['Accept-Language'] = 'id,en-US;q=0.8'
                        headers['Connection'] = 'keep-alive'
                        return requests.post(url, data=json.dumps(data), headers=headers)

                            
                    elif text.lower() == wait["setkey"]+'/mentionall':shield.mentionall(receiver,master,"Mention Member")
                                                
                    elif text.lower() == 'wkwkwk':
                        try:
                            data = {
                                "cc":carousel,
                                "to": to,
                                "messages": [{
                                    "type": "template",
                                    "altText": "Sticker",
                                    "baseSize": { #
                                        "height": 1040, #
                                        "width": 1040 #
                                    }, #
                                    "template": {
                                        "type": "image_carousel",
                                        "imageAspectRatio": "square",
                                        "imageSize": "cover",
                                        "columns": [{
                                            "imageUrl": "https://2.bp.blogspot.com/-lP71q0rCv-U/Ww9ezM99IdI/AAAAAAALa90/aZGYqhHLrdwqojv3KlLz-wpbAwL65rJcQCLcBGAs/s1600/AS0004037_04.gif",
                                            "action": {
                                                "type": "uri",
                                                "uri": "http://line.me/ti/p/M8k6NlQ_1J",
                                                "area": {
                                                    "x": 520,
                                                    "y": 0,
                                                    "width": 520,
                                                    "height": 1040
                                                }
                                            }
                                        }]
                                    }
                                }]
                            }
                            shield.template(carousel,data)
                        except Exception as e:
                            shield.sendMessage(to,"「 Auto Respond 」\n"+str(e))

                    elif text.lower() == 'restart':
                        shield.sendMessage(receiver,"╭⸻⟬ RESTART ⟭⸻\n│TYPE ⵓ Restart Programs ♪˳\n│\n│RESTARTING˳˳˳˳˳˳˳˳˳˳˳˳\n╰⸻⸻⸻⸻")
                        wait["restartPoint"] = msg.to
                        wait["rebort"] = True
                        backupData()
                        restart_program()

                    elif text.lower().startswith(wait["setkey"]+'stealpp '):
                        if 'MENTION' in msg.contentMetadata.keys()!=None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for ls in lists:shield.pp(receiver,ls)
                            
                    elif text.lower().startswith(wait["setkey"]+'stealmid '):
                        if 'MENTION' in msg.contentMetadata.keys()!=None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for ls in lists:shield.sendMessage(receiver,ls)

                    elif text.lower().startswith(wait["setkey"]+'stealvp '):
                        if 'MENTION' in msg.contentMetadata.keys()!=None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for ls in lists:shield.vp(receiver,ls)
                            

                    elif text.lower().startswith(wait["setkey"]+'stealname '):
                        if 'MENTION' in msg.contentMetadata.keys()!=None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for ls in lists:shield.name(receiver,ls)
                            

                    elif text.lower().startswith(wait["setkey"]+'stealbio '):
                        if 'MENTION' in msg.contentMetadata.keys()!=None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for ls in lists:shield.bio(receiver,ls)
                            

                    elif msg.text.lower().startswith(wait["setkey"]+"stealcover "):
                        if shield != None:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:shield.cover(receiver,ls)
                                  

        
                    elif text in wait["Sticker"]:
                        try:
                            shield.sendMessage(to,text=None,contentMetadata=wait['Sticker'][text.lower()], contentType=7)
                        except Exception as e:
                            shield.sendMessage(to,"「 Auto Respond 」\n"+str(e))

                    elif text.lower().startswith(wait["setkey"]+'add stick'):
                        separate = text.split("er ")
                        text = text.replace(separate[0]+"er ","")
                        shield.addSticker(to,text)
                    
                    elif text.lower().startswith(wait["setkey"]+'del sti'):
                        separate = text.split("cker ")
                        text = text.replace(separate[0]+"cker ","")
                        del wait["Sticker"][text]
                        backupData()
                        shield.sendMessage(to," 「 IMAGE 」\nSukses Delete Stiker %s" % str(text))

                    elif text.lower() in wait["Images"]:
                        try:
                            shield.sendImage(to, wait["Images"][text.lower()])
                        except Exception as e:
                            shield.sendMessage(to,"「 Auto Respond 」\n"+str(e))

                    elif text.lower().startswith(wait["setkey"]+'add pi'):
                        separate = text.split("ct ")
                        text = text.replace(separate[0]+"ct ","")
                        wait["Images"][text] = 'dataSeen/%s.jpg' % text
                        wait["Img"] = '%s' % text
                        wait["Addimage"] = True
                        backupData()
                        shield.sendMessage(to, " 「 IMAGE 」\nSend a Picture to save")
                    elif text.lower().startswith(wait["setkey"]+'del pic'):
                        separate = text.split("t ")
                        text = text.replace(separate[0]+"t ","")
                        del wait["Images"][text]
                        backupData()
                        path = os.remove("dataSeen/%s.jpg" % str(text))
                        shield.sendMessage(to," 「 IMAGE 」\nSukses Delete dataSeen/%s.jpg" % str(text))
                    elif text.lower().startswith(wait["setkey"]+"add video "):
                        sep = text.split(" ")
                        name = text.replace(sep[0] + " ","")
                        name = name.lower()
                        if name not in videos:
                            wait["Addvideoo"]["status"] = True
                            wait["Addvideoo"]["name"] = str(name.lower())
                            videos[str(name.lower())] = ""
                            backupData()
                            backupVideo()
                            shield.sendMessage(msg.to, "Silahkan kirim videonya...") 
                        else:
                            shield.sendMessage(msg.to, "Video itu sudah dalam list") 
                                
                    elif text.startswith(wait["setkey"]+"dellvideo "):
                        sep = text.split(" ")
                        name = text.replace(sep[0] + " ","")
                        name = name.lower()
                        if name in videos:
                            shield.deleteFile(videos[str(name.lower())])
                            del videos[str(name.lower())]
                            backupVideo()
                            shield.sendText(msg.to, "Berhasil menghapus video {}".format( str(name.lower())))
                        else:
                            shield.sendText(msg.to, "Video itu tidak ada dalam list") 
                                 
                    elif text.lower() == wait["setkey"]+"listvideo":
                        no = 0
                        ret_ = "「 Daftar Video 」\n\n"
                        for video in videos:
                            no += 1
                            ret_ += str(no) + ". " + video.title() + "\n"
                        ret_ += "\nTotal「{}」Videos".format(str(len(videos)))
                        shield.sendMessage(to, ret_)
                        shield.sendMessage(msg.to,"Jika ingin play video nya,\nSilahkan ketik nama - judul\nBisa juga ketik namanya saja")
                        
                    elif text.lower() == wait["setkey"]+' list protect' or text.lower() == wait["setkey"]+'list protect':
                        gid = shield.getGroupIdsJoined()
                        ret = " 「 Groups 」\nList Protection groups:"
                        no = 0
                        total = len(gid)
                        for group in gid:
                            G = shield.getGroup(group)
                            member = len(G.shieldMemb)
                            no += 1
                            if group in wait["shieldprotect"]:
                                md="  「✭」 PROTECT KICK : ON\n"
                            else:
                                md="  「✭」 PROTECT KICK : OFF\n"
                            if group in wait["shieldurl"]:
                                md+="  「✭」 PROTECT URL : ON\n"
                            else:
                                md+="  「✭」 PROTECT URL : OFF\n"
                            if group in wait["autoCancel"]:
                                md+="  「✭」 PROTECT CANCEL : ON\n"
                            else:
                                md+="  「✭」 PROTECT CANCEL : OFF\n"
                            if group in wait["shieldmute"]:
                                md+="  「✭」 MUTE"
                            else:
                                md+="  「✭」 UN~MUTE"
                            ret += "\n" + str(no) + ". " + G.shieldName +"\n"+md
                        shield.sendMessage(receiver,ret)#"\n[Kick] [Link] [Invitation] [Mute] [1|ON] [0|OFF]")
                        

                    elif text.lower() == wait["setkey"]+"listprotect":
                        ma = ""
                        mb = ""
                        mc = ""
                        md = ""
                        me = ""
                        a = 0
                        gid = wait['shieldprotect']
                        if group in gid:
                            a = a + 1
                            end = '\n'
                            ma += str(a) + ". " +shield.getGroup(group).shieldName + "\n"
                        gid = wait["shieldurl"]
                        if group in gid:
                            a = a + 1
                            end = '\n'
                            mb += str(a) + ". " +shield.getGroup(group).shieldName + "\n"
                        gid = wait["autoCancel"]
                        if group in gid:
                            a = a + 1
                            end = '\n'
                            md += str(a) + ". " +shield.getGroup(group).shieldName + "\n"
                        gid = wait["shieldmute"]
                        if group in gid:
                            a = a + 1
                            end = '\n'
                            mc += str(a) + ". " +shield.getGroup(group).shieldName + "\n"
                        shield.sendMessage(msg.to,"「 Daftar Protection 」\n\n「✭」 PROTECT KICK :\n"+ma+"\n「✭」 PROTECT URL :\n"+mb+"\n「✭」 PROTECT JOIN :\n"+md+"\n「✭」 MUTE GROUP :\n"+mc)#+"\nTotal「%s」Grup diamankan" %(str(len(wait['shieldprotect'])+len(wait['shieldurl'])+len(wait['autoCancel'])+len(wait['shieldmute']))))

                    elif msg.text.lower().startswith(wait["setkey"]+"tr-en "):
                        sep = text.split(" ")
                        isi = text.replace(sep[0] + " ","")
                        translator = Translator()
                        hasil = translator.translate(isi, dest='en')
                        A = hasil.text
                        shield.sendMessage(msg.to, A)

                    elif text.lower().startswith(wait["setkey"]+"likestatus "):
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            for ls in lists:
                                typel = [1001,1002,1003,1004,1005,1006]
                                hasil = shield.getHomeProfile(mid=ls)
                                st = hasil['result']['feeds']
                                for i in range(len(st)):
                                    test = st[i]
                                    result = test['post']['postInfo']['postId']
                                    shield.suka(mid=ls, postId=result, likeType=random.choice(typel))
                                    shield.ngomong(str(ls), str(result),wait['comment'])
                                shield.sendMessage(to, 'ʟɪᴋᴇ ﹠ ᴄᴏᴍᴍᴇɴᴛ '+str(len(st))+'\nᴘᴏsᴛ ꜰʀᴏᴍ {}'.format(shield.getContact(ls).shieldName))

                            
                    elif text.lower() == wait["setkey"]+"likeme":
                        me = msg._from
                        typel = [1001,1002,1003,1004,1005,1006]
                        hasil = shield.getHomeProfile(mid=me)
                        st = hasil['result']['feeds']
                        for i in range(len(st)):
                            test = st[i]
                            result = test['post']['postInfo']['postId']
                            shield.suka(mid=me, postId=result, likeType=random.choice(typel))
                            shield.ngomong(str(sender), str(result), 'Auto Like Tes')
                        shield.sendMessage(to, 'ʟɪᴋᴇ ﹠ ᴄᴏᴍᴍᴇɴᴛ '+str(len(st))+'\nᴘᴏsᴛ ꜰʀᴏᴍ {}'.format(shield.getContact(me).shieldName))

                    elif text.lower().startswith(wait["setkey"]+'get-not'):
                        sep = msg.text.split("e")
                        roman = msg.text.replace(sep[0] + "e","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.GroupPost(to)
                        if len(ambrose) == 2:shield.getGroupPostdetail(msg.to,seth,int(ambrose[1]))

                    elif text.lower().startswith(wait["setkey"]+'my-timeli'):
                        sep = text.split("ne")
                        roman = text.replace(sep[0] + "ne","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.mytimeline(receiver, sender)
                        if len(ambrose) == 2:shield.getTimeLine(receiver, sender,seth,int(ambrose[1]))

                    elif text.lower().startswith(wait["setkey"]+'get-timeline'):
                        if 'MENTION' in msg.contentMetadata.keys()!=None:
                            key = eval(msg.contentMetadata["MENTION"])
                            key1 = key["MENTIONEES"][0]["M"]
                            sep = text.split(" ")
                            roman = text.replace(sep[0] + " ","")
                            ambrose = roman.split("|")
                            seth = str(ambrose[0])
                            if len(ambrose) == 1:shield.gettimeline(to, key1)
                            if len(ambrose) == 2:shield.getTimeLine(to, key1,seth,int(ambrose[1]))

                    elif text.lower() == wait["setkey"]+'lurk result' or text.lower() == wait["setkey"]+' lurk result':
                        if msg.to in wait2['readPoint']:
                            chiya = []
                            for rom in wait2["ROM"][to].items():
                                chiya.append(rom[1])
                            sidertag(to,'',chiya)
                            wait2['setTime'][to]  = {}
                            wait2['ROM'][to] = {}
                            backupRead()
                        else:
                            shield.sendMessage(to, " 「 Lurk 」\nLurk point not on♪")
                    elif text.lower() == wait["setkey"]+'lurk on' or text.lower() == wait["setkey"]+' lurk on':
                        tz = pytz.timezone("Asia/Jakarta")
                        timeNow = datetime.now(tz=tz)
                        day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                        hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                        bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                        hr = timeNow.strftime("%A")
                        bln = timeNow.strftime("%m")
                        for i in range(len(day)):
                            if hr == day[i]: hasil = hari[i]
                        for k in range(0, len(bulan)):
                            if bln == str(k): bln = bulan[k-1]
                        readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                        if msg.to in wait2['readPoint']:
                            shield.sendMessage(to, " 「 Lurk 」\nLurk already set♪")
                        else:
                            try:
                                del wait2['ROM'][msg.to]
                                del wait2['readPoint'][msg.to]
                                del wait2['setTime'][msg.to]
                            except:
                                pass
                            wait2['readPoint'][msg.to] = msg.id
                            wait2['setTime'][to]  = {}
                            wait2['ROM'][to] = {}
                            backupRead()
                            shield.sendMessage(to, " 「 Lurk 」\nLurk point set♪\n" +readTime)
                    elif text.lower() == wait["setkey"]+'lurk off' or text.lower() == wait["setkey"]+' lurk off':
                        if msg.to not in wait2['readPoint']:
                            shield.sendMessage(to, " 「 Lurk 」\nLurk already off♪")
                        else:
                            try:
                                del wait2['ROM'][msg.to]
                                del wait2['readPoint'][msg.to]
                                del wait2['setTime'][msg.to]
                                backupRead()
                            except:
                                pass
                            shield.sendMessage(to, " 「 Lurk 」\nLurk point off♪")
                    elif text.lower() == 'me':
                      a = shield.getContact(sender)
                      shield.sendContact(to,msg._from)
                      shield.sendMessage(to,a.shieldName,shield.templatemusic("http://dl.profile.line-cdn.net/"+a.shieldpictStat,a.shieldName if a.shieldName != '' else a.userid,a.shieldmsgStat if a.shieldmsgStat != '' else 'THIS MY CONTACT'),19)
                      data ={
                          "cc": carousel,
                          "to": to,
                          "messages":[
                            {
                              "type":"template",
                              "altText": "DETAIL CONTACT",
                              "template":{
                                "imageAspectRatio": "square",
                                "imageSize": "cover",
                                "type": "buttons",
                                "thumbnailImageUrl": "https://obs.line-scdn.net/{}".format(shield.getContact(sender).shieldpictStat),
                                "title":"{}".format(shield.getContact(sender).shieldName),
                                "text":"{}".format(shield.getContact(sender).shieldmsgStat),
                                "actions":[
                                  {
                                    "type": "uri",
                                    "label": "COVER IMAGE",
                                    "uri": "https://obs-sg.line-apps.com/myhome/c/download.nhn?oid=122e5b696910bffc98a3b906ff25c7ed&userid="+msg._from,
                                  },
                                  {
                                    "type": "uri",
                                    "label": "CREATOR",
                                    "uri": "line://ti/p/~aries_jabrik"
                                  },
                                  {
                                    "type": "uri",
                                    "label": "CITL DESIGN",
                                    "uri": "https://line.me/R/ti/p/%40inp9841n"
                                  }
                                ]
                              }
                            }
                          ]
                        }
                      shield.template(carousel,data)
                            
                    elif text.lower() == 'iklan':
                        data = {
                          "cc":carousel,
                          "to": to,
                          "messages": [{"type": "flex","altText": "ORDER WOY...!!!","contents": {"type":"carousel","contents": [{
                                    "type": "bubble",
                                    "header": {"type": "box","layout": "horizontal","contents": [{
                                          "type": "text","text": "OPEN","wrap": True,"weight": "bold","color": "#aaaaaa","size": "xl"}]},
                                    "hero": {"type": "image","url": "https://image.ibb.co/b9JR5p/20180811_194145.png","size": "full","aspectMode": "cover","action": {"type": "uri","uri": "http://line.me/ti/p/M8k6NlQ_1J"}},
                                    "body": {"type": "box","layout": "vertical","spacing": "xs","contents": [{
                                          "type": "text","text": "SELFTBOT PROTECT\n BY CITL DESIGN","wrap": True,"size": "lg","weight": "bold"},{
                                          "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                              "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                                  "type": "text","text": "SelfBot Only","weight": "bold","margin": "none","flex": 0}]}]},{
                                          "type": "text","text": "Rp120k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                          "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                              "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                                  "type": "text","text": "SelfBot 2 assist","weight": "bold","margin": "none","flex": 0}]}]},{
                                          "type": "text","text": "Rp170k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                          "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                              "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                                  "type": "text","text": "SelfBot 5 assist","weight": "bold","margin": "none","flex": 0}]}]},{
                                          "type": "text","text": "Rp300k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                          "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                              "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                                  "type": "text","text": "SelfBot 10 assist","weight": "bold","margin": "none","flex": 0}]}]},{
                                          "type": "text","text": "Rp400k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                      
                                          "type": "text","text": "-Note:\n  *Tambah Anti Js,Nego Via Pm\nCITL DESIGN:\nKreasi Tanpa Batas","wrap": True,"color": "#aaaaaa","size": "md"}]},
                                    "footer": {"type": "box","layout": "horizontal","contents": [{
                                          "type": "button","action": {"type": "uri","label": "Clik To Order","uri": "http://line.me/ti/p/M8k6NlQ_1J"}}]}},{
                                    "type": "bubble",
                                    "header": {"type": "box","layout": "horizontal","contents": [{
                                          "type": "text","text": "ORDER","wrap": True,"weight": "bold","color": "#aaaaaa","size": "xl"}]},
                                    "hero": {"type": "image","url": "https://image.ibb.co/b9JR5p/20180811_194145.png","size": "full","aspectMode": "cover","action": {"type": "uri","uri": "http://line.me/ti/p/M8k6NlQ_1J"}},
                                    "body": {"type": "box","layout": "vertical","spacing": "xs","contents": [{
                                          "type": "text","text": "BOT PROTECT\n BY CITL DESIGN","wrap": True,"size": "lg","weight": "bold"},{
                                          "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                              "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                                  "type": "text","text": "Owner 5 Bot","weight": "bold","margin": "none","flex": 0}]}]},{
                                          "type": "text","text": "Rp250k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                          "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                              "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                                  "type": "text","text": "Owner 10 Bot","weight": "bold","margin": "none","flex": 0}]}]},{
                                          "type": "text","text": "Rp450k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                          "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                              "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                                  "type": "text","text": "Admin 5 Bot","weight": "bold","margin": "none","flex": 0}]}]},{
                                          "type": "text","text": "Rp200k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                          "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                              "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                                  "type": "text","text": "Admin 10 Bot","weight": "bold","margin": "none","flex": 0}]}]},{
                                          "type": "text","text": "Rp350k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                  
                                          "type": "text","text": "-Note:\n  *Untuk Staff Bot,Nego Via Pm\nCITL DESIGN:\nKreasi Tanpa Batas","wrap": True,"color": "#aaaaaa","size": "md"}]},
                                    "footer": {"type": "box","layout": "horizontal","contents": [{
                                          "type": "button","action": {"type": "uri","label": "Clik To Order","uri": "http://line.me/ti/p/M8k6NlQ_1J"}}]}},{
                                    "type": "bubble",
                                    "header": {"type": "box","layout": "horizontal","contents": [{
                                          "type": "text","text": "BOT LINE","wrap": True,"weight": "bold","color": "#aaaaaa","size": "xl"}]},
                                    "hero": {"type": "image","url": "https://image.ibb.co/b9JR5p/20180811_194145.png","size": "full","aspectMode": "cover","action": {"type": "uri","uri": "http://line.me/ti/p/M8k6NlQ_1J"}},
                                    "body": {"type": "box","layout": "vertical","spacing": "xs","contents": [{
                                          "type": "text","text": "BOT PROTECT WITH ANTI JS\n BY CITL DESIGN","wrap": True,"size": "lg","weight": "bold"},{
                                          "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                              "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                                  "type": "text","text": "Owner 5 Bot","weight": "bold","margin": "none","flex": 0}]}]},{
                                          "type": "text","text": "Rp450k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                          "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                              "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                                  "type": "text","text": "Owner 10 Bot","weight": "bold","margin": "none","flex": 0}]}]},{
                                          "type": "text","text": "Rp700k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                          "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                              "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                                  "type": "text","text": "Admin 5 Bot","weight": "bold","margin": "none","flex": 0}]}]},{
                                          "type": "text","text": "Rp300k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                          "type": "box","layout": "vertical","spacing": "xs","contents": [{
                                              "type": "box","layout": "baseline","contents": [{"type": "icon","size": "3xl","url": "https://image.ibb.co/dx7dkp/20180811_205432.png"},{
                                                  "type": "text","text": "Admin 10 Bot","weight": "bold","margin": "none","flex": 0}]}]},{
                                          "type": "text","text": "Rp400k/Bln","wrap": True,"size": "md","align": "end","color": "#aaaaaa"},{
                                      
                                          "type": "text","text": "-Note:\n  *Untuk Staff Bot,Nego Via Pm\nCITL DESIGN:\nKreasi Tanpa Batas","wrap": True,"color": "#aaaaaa","size": "md"}]},
                                    "footer": {"type": "box","layout": "horizontal","contents": [{
                                          "type": "button","action": {"type": "uri","label": "Clik To Order","uri": "http://line.me/ti/p/M8k6NlQ_1J"}}]}}
                                ]
                              }
                            }
                          ]
                        }
                        shield.template(carousel,data)
                            
                            

#=================[[[[[[[[[[[[[[]]]]]]]]]]]]]]==================

                    elif wait["setkey"]+"mention:" in msg.text:
                        separate = text.split(" ")
                        number = text.replace(separate[0] + " ","")
                        group = shield.getGroup(to)
                        name = '⟬ᴍᴇɴᴛɪᴏɴ ʙʏ ɴᴜᴍʙᴇʀ⟭'
                        link = 'http://line.me/ti/p/M8k6NlQ_1J'
                        icon = 'http://dl.profile.line-cdn.net/' + group.shieldpictStat
                        nama = [contact.mid for contact in group.shieldMemb]
                        names = nama[int(number)-1]
                        zx = ''
                        zxc = ''
                        zx2 = []
                        xpesan = '╭───「 ᴍᴇɴᴛɪᴏɴ 」──\n│ᴛʏᴘᴇ ⵓ ᴍᴇɴᴛɪᴏɴ ʙʏ ɴᴜᴍʙᴇʀ\n│ᴛᴀʀɢᴇᴛ ⵓ '
                        pesan = ''
                        pesan2 = pesan+"@x \n"
                        xlen = str(len(zxc)+len(xpesan))
                        xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                        zx = {'S':xlen, 'E':xlen2, 'M':names}
                        zx2.append(zx)
                        zxc += pesan2
                        text = xpesan + zxc +"│sᴛᴀᴛᴜs ⵓ sᴜᴄᴄᴇs\n╰───「 ꜰɪɴɪsʜ 」──"
                        shield.sendMessage(to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)

                    elif wait["setkey"]+"mention-group:" in msg.text:
                        separate = text.split(" ")
                        number = text.replace(separate[0] + " ","")
                        ambrose = shield.getGroup(to)
                        groups = shield.getGroupIdsJoined()
                        try:
                            group = groups[int(number)-1]
                            G = shield.getGroup(group)
                            roman = G.id
                            name1 = '⟬ɢᴇᴛ ɢʀᴏᴜᴘ ꜰʀᴏᴍⵓ '+ambrose.shieldName+'⟭'
                            icon1 = 'http://dl.profile.line-cdn.net/'+ambrose.shieldpictStat
                            name = '[ᴍᴇɴᴛɪᴏɴ  ' + G.shieldName + ']'
                            link = 'http://line.me/ti/p/M8k6NlQ_1J'
                            icon = 'http://dl.profile.line-cdn.net/' + G.shieldpictStat
                            nama = [contact.mid for contact in G.shieldMemb]
                            nm1, nm2, nm3, nm4,  nm5, jml = [], [], [], [],  [], len(nama)
                            if jml <= 150:shield.mentionMembers(roman,nama,name,link,icon)
                            if jml > 150 and jml < 500:
                                for i in range(0, 150):
                                    nm1 += [nama[i]]
                                shield.mentionMembers(roman,nm1,name,link,icon)
                                for j in range(150,300):
                                     nm2 += [nama[j]]
                                shield.mentionMembers(roman,nm2,name,link,icon)
                                for k in range(298, len(nama)-2):
                                     nm3 += [nama[k]]
                                shield.mentionMembers(roman,nm3,name,link,icon)
                            shield.sendMessageWithContent(roman,"╭⸻⟬ ɢᴇᴛ ɢʀᴏᴜᴘ ⟭⸻\n│ᴛɪᴘᴇ ⵓ ᴍᴇɴᴛɪᴏɴ ɢʀᴜᴘ ʙʏ ɴᴜᴍʙᴇʀ ♪˳\n│ᴄᴏᴍᴍᴀɴᴅ ꜰʀᴏᴍ ɢʀᴏᴜᴘ ⵓ\n│  ☞ "+ambrose.shieldName+" ☜\n│sᴛᴀᴛᴜs ⵓ sᴜᴄᴄᴇs\n╰⸻⸺⟬ꜰɪɴɪsʜ⟭⸺",name1,link,icon1)
                            shield.sendMessage(to, 'sᴜᴋsᴇs ᴍᴇɴᴛɪᴏɴ ᴀʟʟ ᴍᴇᴍʙᴇʀ '+G.shieldName+' ♪˳')
                        except:
                            pass

                    elif text.lower() == wait["setkey"]+'mentionall':
                        group = shield.getGroup(to)
                        name = '[ᴍᴇɴᴛɪᴏɴ  ' + group.shieldName + ']'
                        link = 'http://line.me/ti/p/M8k6NlQ_1J'
                        icon = 'http://dl.profile.line-cdn.net/' + group.shieldpictStat
                        nama = [contact.mid for contact in group.shieldMemb]
                        nm1, nm2, nm3, nm4,  nm5, jml = [], [], [], [],  [], len(nama)
                        if jml <= 159:shield.mentionMembers(receiver,nama,name,link,icon)
                        if jml > 150 and jml < 500:
                            for i in range(0, 150):
                                nm1 += [nama[i]]
                            shield.mentionMembers(receiver,nm1,name,link,icon)
                            for j in range(150,300):
                                 nm2 += [nama[j]]
                            shield.mentionMembers(receiver,nm2,name,link,icon)
                            for k in range(298, len(nama)-2):
                                 nm3 += [nama[k]]
                            shield.mentionMembers(receiver,nm3,name,link,icon)
                    
                    elif text.lower().startswith(wait["setkey"]+'mentionname:'):
                        separate = text.split(" ")
                        texxt = text.replace(separate[0]+" ","")
                        group = shield.getGroup(to)
                        name = '⟬ᴍᴇɴᴛɪᴏɴ ʙʏ ɴᴀᴍᴇ⟭'
                        link = 'http://line.me/ti/p/M8k6NlQ_1J'
                        icon = 'http://dl.profile.line-cdn.net/' + group.shieldpictStat
                        wait["rbio"] = []
                        for s in group.shieldMemb:
                            if texxt in s.shieldName:
                               wait["rbio"].append(s.mid)
                        nama = wait["rbio"]
                        nm1, nm2, nm3, nm4,  nm5, jml = [], [], [], [],  [], len(nama)
                        if jml <= 150:shield.mentionName(msg.to,nama,name,link,icon)
                        if jml > 150 and jml < 500:
                            for i in range(0, 150):
                                nm1 += [nama[i]]
                            shield.mentionName(msg.to,nm1,name,link,icon)
                            for j in range(149, len(nama)-1):
                                   nm2 += [nama[j]]
                            shield.mentionName(msg.to,nm2,name,link,icon)
                        
                    elif wait["setkey"]+"infogroup: " in msg.text:
                        separate = text.split(" ")
                        number = text.replace(separate[0] + " ","")
                        shield.infoGroup(to,number)
                        
                        
                    elif text.lower().startswith(wait["setkey"]+'videocall'):
                      if msg.toType == 2:
                        separate = text.split(" ")
                        number = text.replace(separate[0] + " ","")
                        groups = shield.getGroupIdsJoined()
                        try:
                            G = groups[int(number)-1]
                            group = shield.getGroup(G)
                            members = [mem.mid for mem in group.shieldMemb]
                            jmlh = int(wait["spamcallvideo"])
                            #video = MediaType.VIDEO
                            shield.sendMessage(msg.to, "Succes {} Spam Call Grup".format(str(wait["spamcall"])))
                            if jmlh <= 1000:
                                for x in range(jmlh):
                                    try:
                                        shield.acquireGroupVideoCallRoute(G)
                                        shield.inviteIntoGroupVideoCall(G, contactIds=members)
                                    except Exception as e:
                                        shield.sendText(msg.to,str(e))
                            else:
                                shield.sendText(msg.to,"Jumlah melebihi batas")
                        except Exception as e:
                            shield.sendText(msg.to,str(e))

                        
                    elif text.lower().startswith(wait["setkey"]+'call'):
                      if msg.toType == 2:
                        separate = text.split(" ")
                        number = text.replace(separate[0] + " ","")
                        groups = shield.getGroupIdsJoined()
                        try:
                            G = groups[int(number)-1]
                            group = shield.getGroup(G)
                            members = [mem.mid for mem in group.shieldMemb]
                            jmlh = int(wait["spamcall"])
                            shield.sendMessage(msg.to, "Succes {} Spam Call Grup".format(str(wait["spamcall"])))
                            if jmlh <= 1000:
                                for x in range(jmlh):
                                    try:
                                        shield.acquireGroupCallRoute(G)
                                        shield.inviteIntoGroupCall(G, contactIds=members)
                                    except Exception as e:
                                        shield.sendText(msg.to,str(e))
                            else:
                                shield.sendText(msg.to,"Jumlah melebihi batas")
                        except Exception as e:
                            shield.sendText(msg.to,str(e))

                    elif text.lower() == 'spamvideocall':
                        if msg.toType == 2:
                            group = shield.getGroup(msg.to)
                            members = [mem.mid for mem in group.shieldMemb]
                            jmlh = int(wait["spamcallvideo"])
                          #  video = MediaType.VIDEO
                            shield.sendMessage(msg.to, "Succes {} Spam Call Grup".format(str(wait["spamcall"])))
                            if jmlh <= 1000:
                                for x in range(jmlh):
                                    try:
                                        shield.acquireGroupVideoCallRoute(msg.to)
                                        shield.inviteIntoGroupVideoCall(msg.to, contactIds=members)
                                    except Exception as e:
                                        shield.sendText(msg.to,str(e))
                            else:
                                shield.sendText(msg.to,"Jumlah melebihi batas")

                    elif text.lower() == 'spamcall':
                        if msg.toType == 2:
                            group = shield.getGroup(msg.to)
                            members = [mem.mid for mem in group.shieldMemb]
                            jmlh = int(wait["spamcall"])
                            shield.sendMessage(msg.to, "Succes {} Spam Call Grup".format(str(wait["spamcall"])))
                            if jmlh <= 1000:
                                for x in range(jmlh):
                                    try:
                                        shield.acquireGroupCallRoute(msg.to)
                                        shield.inviteIntoGroupCall(msg.to, contactIds=members)
                                    except Exception as e:
                                        shield.sendText(msg.to,str(e))
                            else:
                                shield.sendText(msg.to,"Jumlah melebihi batas")
                                
                    elif text.lower().startswith(wait["setkey"]+'jumlahvideocall '):
                        proses = text.split(" ")
                        strnum = text.replace(proses[0] + " ","")
                        num =  int(strnum)
                        wait["spamcallvideo"] = num
                        backupData()
                        shield.sendText(msg.to,"Total Spamcall Diubah Menjadi " +strnum)

                    elif text.lower().startswith(wait["setkey"]+'jumlahcall '):
                        proses = text.split(" ")
                        strnum = text.replace(proses[0] + " ","")
                        num =  int(strnum)
                        wait["spamcall"] = num
                        backupData()
                        shield.sendText(msg.to,"Total Spamcall Diubah Menjadi " +strnum)


###################---------------+++++***********

                    elif text.lower().startswith(wait["setkey"]+'instagram '):
                        sep = msg.text.split(" ")
                        roman = msg.text.replace(sep[0] + " ","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.ig(msg.to,seth)
                        if len(ambrose) == 2:shield.igdata(msg.to,seth,int(ambrose[1]))

                    elif text.lower().startswith(wait["setkey"]+'snapgram '):
                        sep = msg.text.split(" ")
                        roman = msg.text.replace(sep[0] + " ","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.igstory(msg.to,seth)
                        if len(ambrose) == 2:shield.igstorydata(msg.to,seth,int(ambrose[1]))
                          
                    elif text.lower().startswith(wait["setkey"]+'linetoday'):
                        sep = msg.text.split(" ")
                        roman = msg.text.replace(sep[0] + " ","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.LineToday(msg.to,seth)#,sender)
                        if len(ambrose) == 2:shield.LineTodayData(msg.to,seth,int(ambrose[1]))



                    elif text.lower() == wait["setkey"]+'kode wilayah':shield.kodewilayah(to,sender)
                    
                    elif text.lower().startswith(wait["setkey"]+"lihat "):
                        sep = msg.text.split(" ")
                        text = msg.text.replace(sep[0] + " ","")
                        shield.lewatmana(to,text,sender)
                    
                    elif text.lower().startswith(wait["setkey"]+"encode "):
                        sep = msg.text.split(" ")
                        text = msg.text.replace(sep[0] + " ","")
                        B64e(to,text)
                    
                    elif text.lower().startswith(wait["setkey"]+"decode "):
                        sep = msg.text.split(" ")
                        text = msg.text.replace(sep[0] + " ","")
                        B64d(to,text)
                    
                    elif text.lower().startswith(wait["setkey"]+"smule "):
                        sep = msg.text.split(" ")
                        search = msg.text.replace(sep[0] + " ","")
                        shield.smule(to,search)
                        

                    elif text.lower().startswith(wait["setkey"]+'smulerecord '):
                        sep = msg.text.split(" ")
                        roman = msg.text.replace(sep[0] + " ","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.smule1(msg.to,seth)#,sender)
                        if len(ambrose) == 2:shield.smule1data(msg.to,seth,int(ambrose[1]))

                    
                    elif text.lower().startswith(wait["setkey"]+"getyoutube "):#pakai link youtube
                        sep = msg.text.split(" ")
                        search = msg.text.replace(sep[0] + " ","")
                        shield.youtube(to,search)

                    elif text.lower().startswith(wait["setkey"]+"image "):
                        sep = msg.text.split(" ")
                        search = msg.text.replace(sep[0] + " ","")
                        shield.searchimage(to,search)
                        

                    elif text.lower().startswith(wait["setkey"]+"googleimage "):
                        sep = msg.text.split(" ")
                        search = msg.text.replace(sep[0] + " ","")
                        shield.Image(to,search)
                    
                    elif text.lower().startswith(wait["setkey"]+"short "):
                        sep = msg.text.split(" ")
                        search = msg.text.replace(sep[0] + " ","")
                        shield.url_shorten(to,search)

                    elif text.lower().startswith(wait["setkey"]+"cooltext "):
                        sep = msg.text.split(" ")
                        search = msg.text.replace(sep[0] + " ","")
                        shield.cooltext(to,search)

                    elif text.lower().startswith(wait["setkey"]+'deviantimage '):
                        sep = msg.text.split(" ")
                        roman = msg.text.replace(sep[0] + " ","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.deviantlist(msg.to,seth,sender)
                        if len(ambrose) == 2:shield.deviantdata(msg.to,seth,int(ambrose[1]))
                          
                    elif text.lower().startswith(wait["setkey"]+'deviant '):
                        sep = msg.text.split(" ")
                        roman = msg.text.replace(sep[0] + " ","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.deviantscrap(msg.to,seth)#,sender)
                        if len(ambrose) == 2:shield.deviantscrapdata(msg.to,seth,int(ambrose[1]))
                    
                    elif text.lower().startswith(wait["setkey"]+'walpaperhd '):
                        sep = msg.text.split(" ")
                        roman = msg.text.replace(sep[0] + " ","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.wallp(msg.to,seth,sender)
                        if len(ambrose) == 2:shield.wallpdata(msg.to,seth,int(ambrose[1]))

                    elif text.lower().startswith(wait["setkey"]+'xxxsearch '):
                        sep = msg.text.split(" ")
                        roman = msg.text.replace(sep[0] + " ","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.xxxlist(msg.to,seth,sender)
                        if len(ambrose) == 2:shield.xxxdata(msg.to,seth,int(ambrose[1]))
                    
                    elif text.lower().startswith(wait["setkey"]+'wikisearch '):
                        sep = msg.text.split(" ")
                        roman = msg.text.replace(sep[0] + " ","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.wikipedialist(msg.to,seth,sender)
                        if len(ambrose) == 2:shield.wikipedialistdata(msg.to,seth,int(ambrose[1]))

                    elif text.lower().startswith(wait["setkey"]+'itunespreview '):
                        sep = msg.text.split(" ")
                        roman = msg.text.replace(sep[0] + " ","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.ituneslist(msg.to,seth,sender)
                        if len(ambrose) == 2:shield.itunesdata(msg.to,seth,int(ambrose[1]))


                    elif text.lower().startswith(wait["setkey"]+'music '):
                        sep = msg.text.split(" ")
                        roman = msg.text.replace(sep[0] + " ","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.musiclist(msg.to,seth,sender)
                        if len(ambrose) == 2:shield.musicdata(msg.to,seth,int(ambrose[1]))
                          
                          
                    elif text.lower().startswith(wait["setkey"]+'msc '):
                        sep = msg.text.split(" ")
                        roman = msg.text.replace(sep[0] + " ","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.lagu123(msg.to,seth)#,sender)
                        if len(ambrose) == 2:shield.lagu123data(msg.to,seth,int(ambrose[1]))
                        
                    elif text.lower().startswith(wait["setkey"]+'apk: '):
                        sep = msg.text.split(" ")
                        roman = msg.text.replace(sep[0] + " ","")
                        ambrose = roman.split("|")
                        seth = str(ambrose[0])
                        if len(ambrose) == 1:shield.getapk(msg.to,seth)#,sender)
                        if len(ambrose) == 2:shield.getapkdata(msg.to,seth,int(ambrose[1]))
                          
                    elif text.startswith("detailstiker"):
                        txt = msg.text.split("|")
                        lk = "http://dl.stickershop.line.naver.jp/products/0/0/"+txt[1]+"/"+txt[2]+"/WindowsPhone/productInfo.meta"
                        r = requests.get("http://dl.stickershop.line.naver.jp/products/0/0/"+txt[1]+"/"+txt[2]+"/WindowsPhone/productInfo.meta")
                        #shield.sendText(to,lk)
                        data = r.text
                        data = json.loads(data)
                        for anu in data["stickers"]:
                            b = str(anu["id"])
                            a = "http://dl.stickershop.line.naver.jp/products/0/0/"+txt[1]+"/"+txt[2]+"/WindowsPhone/stickers/"+b+".png"
                            image = shield.downloadFileURL(a)
                            shield.sendImage(to,image)#.time.sleep(10)
                            #shield.sendText(to,a)

                    elif text.startswith("/sticker "):
                        separate = msg.text.split(" ")
                        search = msg.text.replace(separate[0] + " ","")
                        cond = search.split("|")
                        key = str(cond[0])
                        caps = key.upper()
                        with requests.session() as web:
                            web.headers["User-Agent"] = random.choice(wait["userAgent"])
                            r = web.get("https://leert.corrykalam.gq/lstickers.php?search={}".format(urllib.parse.quote(key)))
                            data = r.text
                            data = json.loads(data)
                            no = 0
                            hasil ="「 RESULT STICKER "+caps+" 」\n\n"
                            if len(cond) == 1:
                                for roman in data["items"]:
                                    no += 1
                                    hasil +="{}. {}\n".format(str(no), str(roman["title"]))
                                for ambrose in data["facets"]:
                                    hasil +="\nType : "+str(ambrose["type"])
                                    hasil +="\nJumlah : "+str(ambrose["count"])
                                    ret = "\nselanjutnya ketik,sticker "+key+"|[number]\nUntuk melihat detail nya"
                                shield.sendMessage(to, str(hasil)+ret)#+str(ret)+res)
                            elif len(cond) == 2:
                                no = int(cond[1])
                                if no <= len(data["items"]):
                                    gambar = data["items"][no - 1]
                                    hsl = "Judul : " +str(gambar["title"])
                                    hsl +="\nType : " +str(gambar["type"])
                                    hsl +="\nJenis : " +str(gambar["subtype"])
                                    hsl +="\nCreator : "+str(gambar["authorName"])
                                    hsl +="\nJenis Sticker : "+str(gambar["stickerResourceType"])
                                    hsl +="\nURL : https://store.line.me"+str(gambar["productUrl"])
                                    hsl +="\nHarga : "+str(gambar["price"])
                                    path = str(gambar["listIcon"]["src"])
                                shield.sendMessage(to,str(hsl))
                                shield.sendImageWithURL(to,path)
                                
                    elif text.lower().startswith("ss"):
                        try:
                            sep = text.split(" ")
                            text = text.replace(sep[0] + " ","")
                            r = requests.get("https://farzain.com/api/webcheck.php?q="+text+"&apikey=mrMnyR5kJQsfMCsxAIVdNo1k7")
                            data = r.text
                            data = json.loads(data)
                          #  shield.sendImageWithURL(to, data["result"])
                            shield.sendText(to,data["screenshot"])
                        except Exception as error:
                            shield.sendMessage(msg.to, str(e))

                    elif text.startswith(wait["setkey"]+"temaline "):
                        separate = msg.text.split(" ")
                        search = msg.text.replace(separate[0] + " ","")
                        cond = search.split("|")
                        key = str(cond[0])
                        caps = key.upper()
                        with requests.session() as web:
                            web.headers["User-Agent"] = random.choice(wait["userAgent"])
                            r = web.get("http://leert.corrykalam.gq/ltheme.php?search={}".format(urllib.parse.quote(key)))
                            data = r.text
                            data = json.loads(data)
                            no = 0
                            hasil ="「 RESULT TEMA "+caps+" 」\n\n"
                            if len(cond) == 1:
                                for roman in data["items"]:
                                    no += 1
                                    hasil +="{}. {}\n".format(str(no), str(roman["title"]))
                                for ambrose in data["facets"]:
                                    hasil +="\nType : "+str(ambrose["type"])
                                    hasil +="\nJumlah : "+str(ambrose["count"])
                                    ret = "\nselanjutnya ketik,tema "+key+"|[number]\nUntuk melihat detail nya"
                                shield.sendMessage(to, str(hasil)+ret)#+str(ret)+res)
                            elif len(cond) == 2:
                                no = int(cond[1])
                                if no <= len(data["items"]):
                                    gambar = data["items"][no - 1]
                                    hsl = "Judul : " +str(gambar["title"])
                                    hsl +="\nType : " +str(gambar["type"])
                                    hsl +="\nJenis : " +str(gambar["subtype"])
                                    hsl +="\nCreator : "+str(gambar["authorName"])
                                    #hsl +="\nJenis Sticker : "+str(gambar["stickerResourceType"])
                                    hsl +="\nURL : https://store.line.me"+str(gambar["productUrl"])
                                    hsl +="\nHarga : "+str(gambar["price"])
                                    path = str(gambar["listIcon"]["src"])
                                shield.sendMessage(to,str(hsl))
                                shield.sendImageWithURL(to,path)

    except Exception as error:
        logError(error)
        
def sidertag(to, text='', dataMid=[]):
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    hr = timeNow.strftime("%A")
    bln = timeNow.strftime("%m")
    for i in range(len(day)):
        if hr == day[i]: hasil = day[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') +"\n"+ timeNow.strftime('%H:%M:%S') + " WIB"
    now = datetime.now()
    arr = []
    list_text=' 「 Lurk 」\nLurkers: %i member'%(len(dataMid))
    if '[list]' in text.lower():
        i=0
        for l in dataMid:
            list_text+='\n@[list-'+str(i)+']'
            i=i+1
        text=text.replace('[list]', list_text)
    elif '[list-' in text.lower():
        text=text
    else:
        i=0
        no=0
        for l in dataMid:
            z = ""
            chiya = []
        for rom in wait2["setTime"][to].items():
            chiya.append(rom[1])
        for b in chiya:
            a = str(timeago.format(now,b/1000))
            no+=1
            list_text+='\n   '+str(no)+'. @[list-'+str(i)+']\n     「 '+a+" 」"
            i=i+1
        list_text +="\n\nData Rewrite:  \n"+ readTime
        text=text+list_text
    i=0
    for l in dataMid:
        mid=l
        name='@[list-'+str(i)+']'
        ln_text=text.replace('\n',' ')
        if ln_text.find(name):
            line_s=int( ln_text.index(name) )
            line_e=(int(line_s)+int( len(name) ))
        arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
        arr.append(arrData)
        i=i+1
    contentMetadata={'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
    shield.sendMessage(to, text, contentMetadata)
    
def stickeron(to,text):
    if to in wait["stickerOn"]:
        shield.sendMessage(to," 「 CEK STICKER 」\nCek Stiker sudah disetting diruangan ini..!")
    else:
        wait["stickerOn"].append(to)
      #  backupData()
        shield.sendMessage(to," 「 CEK STICKER 」\nCek Stiker disetting di ruangan ini!")
def stickeroff(to,text):
    if to not in wait["stickerOn"]:
        shield.sendMessage(to," 「 CEK STICKER 」\nCek Stiker sudah Off.")
    else:
        wait["stickerOn"].remove(to)
    #    backupData()
        shield.sendMessage(to," 「 CEK STICKER 」\nCek Stiker di-off kan di ruangan ini..!")
          
def mute(to,text):
    if to in wait["shieldDetectMention"]:
        shield.sendMessage(to,"test")
    else:
        wait["shieldDetectMention"].append(to)
        backupData()
        #shield.sendMessage(to," 「 Mute 」\nBot disetting diam di ruangan ini!")
def unmute(to,text):
    if to not in wait["shieldDetectMention"]:
        shield.sendMessage(to,"test")
    else:
        wait["shieldDetectMention"].remove(to)
        backupData()
        #shield.sendMessage(to," 「 Un-Mute 」\nBot diaktifkan kembali")

def B64e(to,url):
  	import base64
  	return shield.sendMessage(to,base64.b64encode(url.encode()).decode())

def B64d(to,url):
  	import base64
  	return shield.sendMessage(to,base64.b64decode(url.encode()).decode())

def delExpire():
    if prevents["temp_flood"] != {}:
        for tmp in prevents["temp_flood"]:
            if prevents["temp_flood"][tmp]["expire"] == True:
                if time.time() - prevents["temp_flood"][tmp]["time"] >= 3*10:
                    prevents["temp_flood"][tmp]["expire"] = False
                    prevents["temp_flood"][tmp]["time"] = time.time()
                    backupLimit()
                    try:
                        am = shield.getProfile()
                        text = "Bot Active Again 🍁"
                        name = "==[ Detected Flood ]=="
                        url = "https://line.me/ti/p/~" + shield.profile.userid
                        iconlink = "http://dl.profile.line-cdn.net/" + am.shieldpictStat
                        shield.sendText(tmp,text)
                    except Exception as error:
                        logError(error)
                        
def mykey(self, to):
    if wait["setkey"] == '':
        self.sendMessage(to,"╭⸺⟬ᴋᴇʏ ཿ「」⟭⸺\n│ʏᴏᴜʀ ᴋᴇʏ ཿ ᴅɪsᴀʙʟᴇᴅ ♪♪\n│ ᴋᴇʏཿ ➙sᴇᴛ ʏᴏᴜʀ ᴋᴇʏ\n│ ᴋᴇʏ ᴏꜰꜰ ➙ᴅɪsᴀʙʟᴇ ʏᴏᴜʀ ᴋᴇʏ\n│ ᴋᴇʏ ʀᴇsᴇᴛ ➙ʀᴇsᴇᴛ ʏᴏᴜʀ ᴋᴇʏ\n╰⸻⸺⟬ꜰɪɴɪsʜ⟭⸻⸺")
    else:
        self.sendMessage(to,"╭⸺⟬ᴋᴇʏ ཿ「"+wait["setkey"] +"」⟭⸺\n│ʏᴏᴜʀ ᴋᴇʏ ཿ " + wait["setkey"]  + "\n│ ᴋᴇʏཿ ➙sᴇᴛ ʏᴏᴜʀ ᴋᴇʏ\n│ ᴋᴇʏ ᴏꜰꜰ ➙ᴅɪsᴀʙʟᴇ ʏᴏᴜʀ ᴋᴇʏ\n│ ᴋᴇʏ ʀᴇsᴇᴛ ➙ʀᴇsᴇᴛ ʏᴏᴜʀ ᴋᴇʏ\n╰⸻⸺⟬ꜰɪɴɪsʜ⟭⸻⸺")
            
def mykeyoff(self,to):
    wait["setkey"] = ""
    backupData()
    self.sendMessage(to,"╭⸺⟬ᴋᴇʏ ཿ「」⟭⸺\n│ᴋᴇʏ sᴇᴛ ᴅɪsᴀʙʟᴇᴅ♪♪\n╰⼀⼀⟬ ꜰɪɴɪsʜ ⟭⼀⼀")
        
def mykeyreset(self,to):
    wait["setkey"] = "shield:"
    backupData()
    self.sendMessage(to,"╭⸺⟬ᴋᴇʏ ཿ「"+wait["setkey"]+"」⟭⸺\n│ᴋᴇʏ sᴇᴛ ᴛᴏ ཿ "+wait["setkey"]+"\n╰⼀⼀⟬ ꜰɪɴɪsʜ ⟭⼀⼀")

def keyset(self,to,text):
    separate = text.split(":")
    roman = text.replace(separate[0]+":","")
    a = wait["setkey"]
    wait["setkey"] = roman
    backupData()
    self.sendMessage(to,"╭⸺⟬ᴋᴇʏ ཿ「"+wait["setkey"]+"」⟭⸺\n│ᴛʏᴘᴇ     ཿ ᴄʜᴀɴɢᴇ ᴋᴇʏ\n│➛ꜰʀᴏᴍ ཿ "+a+"\n│➛ᴛᴏ      ཿ "+roman+"\n│sᴛᴀᴛᴜs ཿ sᴜᴄᴄᴇss\n╰⼀⼀⟬ ꜰɪɴɪsʜ ⟭⼀⼀")

def cekmention(to,wait):
    if to in wait['ROM']:
        moneys = {}
        msgas = ''
        for a in wait['ROM'][to].items():
            moneys[a[0]] = [a[1]['msg.id'],a[1]['waktu']] if a[1] is not None else idnya
        sort = sorted(moneys)
        sort.reverse()
        sort = sort[0:]
        msgas = ' 「 Mention Me 」'
        h = []
        no = 0
        for m in sort:
            has = ''
            nol = -1
            for kucing in moneys[m][0]:
                nol+=1
            #    has+= '\nline://nv/chatMsg?chatId={}&messageId={} {}'.format(to,kucing,humanize.naturaltime(datetime.fromtimestamp(moneys[m][1][nol]/1000)))
                has+= '\nline://nv/chatMsg?chatId={}&messageId={} {}'.format(to,kucing,timeago.format(datetime.now(),moneys[m][1][nol]/1000))
            h.append(m)
            no+=1
            if m == sort[0]:
                msgas+= '\n{}. @!{}x{}'.format(no,len(moneys[m][0]),has)
            else:
                msgas+= '\n\n{}. @!{}x{}'.format(no,len(moneys[m][0]),has)
        shield.sendMention(to, msgas,'', h)
        del wait['ROM'][to]
    else:
        try:
            msgas = 'Sorry @!In {} nothink get a mention'.format(shield.getGroup(to).name)
            shield.sendMention(to, msgas,' 「 Mention Me 」\n', [shield.getProfile().mid])
        except:
            msgas = 'Sorry @!In Chat @!nothink get a mention'
            shield.sendMention(to, msgas,' 「 Mention Me 」\n', [shield.getProfile().mid,to])

while True:
    delExpire()
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                BotShield(op)
                oepoll.setRevision(op.revision)
    except Exception as e:
        logError(e)
