from dit import LineBot
import json,threading,subprocess
def login(resp, auth):
    bot = LineBot(resp, auth)
w1 = login('protect/@Ặ̗ͫ͞l̘͚̝èsḧ̴̗̺́̋a̝̼̭.json',"EttFIXyOQuOa3wAprad2.Skq32mqBkuNH3J/isSmUaG.vpVwCR1pR7J6HTuHuG04TAoVCzELPzMA8jttprVJvXk=")