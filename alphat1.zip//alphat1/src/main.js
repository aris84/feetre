const LineAPI = require('./api');
const request = require('request');
const fs = require('fs');
const unirest = require('unirest');
const webp = require('webp-converter');
const path = require('path');
const rp = require('request-promise');
const config = require('./config');
const { Message, OpType, Location } = require('../curve-thrift/line_types');
//let exec = require('child_process').exec;

const myBot = ['u5ee3f8b1c2783990512a02c14d312c89','u88551cb4b9ab9508138d5d35da962c9c'];
var komenTL = "AutoLike by Aries_jabrix\nhttp://line.me/ti/p/M8k6NlQ_1J"; //Comment for timeline
var limitposts = '100'; //Output timeline post

class LINE extends LineAPI {
    constructor() {
        super();
		this.limitposts = limitposts; //Output timeline po
    ;}

    getOprationType(operations) {
    }

    poll(operation) {
        this.getOprationType(operation);
    }
	
	async aLike(){
		if(config.chanToken && config.doing == "no"){
			config.doing = "ya";
		    this._autoLike(config.chanToken,limitposts,komenTL);
      console.info(`[LIKE STATUS TL]`);
		}
	}
}

module.exports = new LINE();